# La Isla de los Dragoncitos (Forge 1.20.1)

Mod para Minecraft Forge 1.20.1 (Forge 47.2.0, Java 17).

## Qué añade
- **Islas flotantes** que aparecen en distintos lugares del mundo, casi siempre junto a un **río**: de la isla cae una **cascada** hasta el río y una **enredadera gigante** (raíces de manglar y musgo con lianas) sube desde el suelo hasta el borde. Se trepa por las lianas.
- Naturaleza preciosa: cerezos, robles, azaleas, flores, un **lago**, playa, lianas con bayas luminosas colgando por debajo, y una **plaza antigua** con pilares y arcos en ruinas y un **santuario** de piedra.
- **Dragoncitos** (rosa, verde, azul y rojo): no crecen, son cariñosos y vuelan con aleteos cortos.
  - Dales **carne** (vacuno, cerdo, cordero, pollo, conejo; cruda o cocinada) para domesticarlos (50 % de probabilidad por intento).
  - **Clic derecho** sobre uno tuyo: alterna entre *seguirte* y *quedarse quieto*. Con carne se cura.
- **Cofres** (en el santuario y junto a los pilares) con **escamas** de dragón verde, azul, roja y rosa y **manuscritos** con historias épicas de los antiguos dragones (son libros que se leen normal).
- **Estatua del Dragón** en el centro de cada isla:
  - Clic derecho en una estatua sin dueño: le pones **nombre** a la isla y pasa a ser **tuya**.
  - Solo tú y los jugadores a los que des permiso podéis **entrar, construir y destruir** (también protege contra explosiones y cubos de agua/lava). Quien no tenga permiso es devuelto al pie de la enredadera.
  - Desde la estatua puedes **teletransportarte a las otras islas** cuya estatua ya hayas usado.
  - El dueño gestiona los **permisos** (dar / quitar) desde el mismo menú de la estatua.

## Novedades 1.1.0
- **Islas todas distintas**: 6 estilos (Primavera, Nieve, Volcánica, Cristal, Jungla, Oasis) con su propio suelo, árboles, flora, piedra y ruinas; el bioma favorece uno pero puede salir cualquiera.
- **Tamaños de 11 a 46 de radio** (diminutas a gigantes), forma irregular/alargada, grosor y relieve variables.
- **Estructuras variables**: santuario, **torre en ruinas** (2 pisos con escalera y 2 cofres) o **nido de dragoncitos**; 5-12 pilares; lagos de distinto tamaño, **estanques** extra en islas grandes, **cráter de lava** en las volcánicas y **islotes flotantes** (algunos con cofre).
- Los dragoncitos de cada isla tienden al color de su estilo.
- **Escamas con utilidad**: clic derecho (rosa cura, verde hace florecer piedra/tierra, azul aliento de mar, roja protege del fuego); sobre tu dragoncito le cambian el color; los dragoncitos domados sueltan escamas de su color de vez en cuando.
- **Amuletos** (oro + escama): 2 efectos permanentes en el inventario. **Brújula de Dragón** (brújula + 4 escamas): señala la isla más cercana. **Bloques de escamas** decorativos que brillan.
- Las islas ya generadas en mundos antiguos se conservan tal cual; lo nuevo vale para islas nuevas.

## Novedades 1.2.0 (Dragones Antiguos)
- **Islas**: ahora hay islas simples (sin adornos), islas enormes (hasta radio ~64) con **Gran Templo** o **Ciudadela** (con altar y, a veces, un **huevo de dragón antiguo**), más islotes y estanques en las grandes.
- **Huevo de Dragón Antiguo** (fuego, hielo o tormenta): escondido en el suelo del mapa (muy raro, en un hueco con musgo) y en altares de islas grandes. Colócalo y eclosiona en ~5 min (más rápido junto a fuego/lava) en un dragón domado.
- **Dragón Antiguo**: modelo propio épico, ojos que brillan. Crece **según la comida** (carne; manzanas doradas) hasta un tamaño gigante. Sigue, se queda o deambula 32 bloques; te defiende con **fuego, hielo o rayo**. Los dragoncitos sienten adoración por él.
- **Montadragones** (silla + 4 escamas): clic derecho sobre tu dragón para montarlo. Mira arriba y avanza para despegar; mira abajo para aterrizar.
- **Báculo del Dragón**: guarda a tu dragón (clic derecho sobre él) y libéralo en un bloque.
- **/dragon**: menú clicable. Seguir, quedarse, deambular aquí, **explorar** (vuela o camina según estuviera), **isla cercana** (detecta islas aún no descubiertas), **ir <isla>** (vuelo automático a una isla con nombre), **apodar <nombre>** (renombra la isla donde estás), estado y mejoras. Si mueves el dragón con las teclas, recuperas el control (la cámara no cuenta).
- **Puntos draconianos**: +10 por cada isla de dragoncitos descubierta. Mejoras: fuerza (máx 200, 1 pto/nivel), velocidad (máx 20, 5), vida (máx 400, 0,5), escamas protectoras (máx 100, 1 pto cada una; cada escama reduce un golpe a la mitad y se gasta) y **vida compartida** (100 puntos exactos): vuestra vida se suma y es la misma para los dos; un corazón del color del dragón con el número sustituye la barra. Si uno muere, el otro también (tú reapareces, el dragón no).
- **Marca del Jinete**: al eclosionar tu primer dragón duplica tus ventajas (puntos, efectos de amuletos y escamas, vida aportada por el dragón).
- **Dragón del Agua** (el más raro y fuerte): su huevo está en el fondo de los océanos profundos. Nace con estadísticas más altas, **vuela bajo el agua a gran velocidad** y da **respiración acuática y visión nocturna** al jinete mientras está en el agua; respira bajo el agua y escupe chorros que empujan.
- La **Marca del Jinete** dura mientras viva el dragón que la despertó y duplica todas las ventajas, actuales y futuras (incluidas las mejoras del dragón y el desgaste de escamas).
- 18 **logros** nuevos.

## Novedades 1.4.0
- **La Crónica de los Jinetes del Alba**: una civilización de jinetes de dragones que desapareció. Ocho capítulos (de "El Primer Huevo" a la "Carta de Naru") en libros que aparecen en los cofres de las islas y de las ruinas, y en atriles dentro de los santuarios, torres, templos y ciudadelas.
- **Ruinas por el mundo**: Atalaya del Jinete (torre en ruinas), Cementerio de Dragones (esqueleto colosal y campamento de su jinete), Círculo del Alba (ofrendas de escamas y cofre escondido bajo el altar) y Pilar de las Profundidades (ruinas de prismarina en el océano profundo).
- **En las islas nuevas**: fósiles de dragón y atriles con la crónica.
- **Montura fija**: el Montadragones se queda puesto en el dragón (se ve la silla). Con la silla puesta, clic derecho con la mano vacía para montar; agachado + clic derecho con el Montadragones para quitarla.
- **Vuelo montado**: espacio para despegar y subir; avanzar mirando abajo desciende.
- **Navegación**: al explorar o ir a una isla el dragón esquiva bloques (sube, baja o rodea) y se libera si se atasca.
- **Cámara**: el jinete va sentado por encima del modelo, así que se ve bien por muy grande que sea el dragón.
- **Seguirte sin agobiar**: el dragón te acompaña en un anillo a cierta distancia, ya no se pega a tu cabeza.
- **Huevos**: iconos propios (ya no sale el bloque negro y violeta).
- **Vida compartida**: corazón grande y centrado, entre la armadura y la barra de experiencia, del color de tu dragón y con borde dorado; el número baja con el daño que reciba cualquiera de los dos.
- **Edulnari**: al morir, tu dragón deja una esencia con sus niveles y habilidades (sin tamaño ni escamas). Clic derecho con ella sobre un huevo de dragón antes de que eclosione y el nuevo dragón, del tipo del huevo, nace con esas mejoras.
- 3 logros nuevos (ruinas, primera página, cronista).

## Novedades 1.5.0
- **Nuevo diseño 3D de los dragones antiguos**: cada tipo (fuego, hielo, tormenta y agua) usa su propio modelo épico de unos 600-780 cubos, con textura propia y **capa que brilla en la oscuridad** (lava, rayos, cristales, bioluminiscencia y ojos).
- **Animaciones**: reposo, caminar, volar, planear y aliento; el dragón del agua además **nada** (`swim` / `swim_idle`) cuando está bajo el agua. La cabeza sigue hacia donde mira.
- Los modelos se dibujan con **GeckoLib** (el .jar de GeckoLib 4.4.9 o superior para 1.20.1 es necesario; se descarga solo al compilar y hay que tenerlo en la carpeta `mods` para jugar).
- Los archivos están en `assets/isladragoncitos/geo/entity`, `animations/entity` y `textures/entity` (`<tipo>_dragon.*`). El tamaño base se ajusta con `MODEL_SCALE` en `AncientDragonRenderer`.
- Los dragoncitos pequeños no cambian.

## Novedades 1.6.0 (menú del dragón)
- **Menú gráfico del dragón**: pulsa **G** (se puede cambiar en Controles) o escribe `/dragon`. Ya no hace falta usar comandos para mejorar a tu dragón.
- Colores y adornos según el elemento (fuego, hielo, tormenta o agua) y **vista previa del dragón** que te mira a ti.
- Pestaña **Mejoras**: barras de fuerza, velocidad, vida y escamas con botones **+1 / +10 / Máx** (se desactivan si no te llegan los puntos; el cursor te dice el coste) y botón para unir las vidas. El resultado se muestra en el propio menú.
- Pestaña **Órdenes**: seguir, quedarse, deambular, explorar, isla cercana y parar (la orden actual aparece resaltada).
- Pestaña **Viajes**: lista de tus islas, un clic y el dragón te lleva.
- El menú se actualiza solo al comprar o dar una orden. Los comandos siguen funcionando; el antiguo menú de texto ahora es `/dragon texto`.

## Comandos
- `/isladragoncitos release` (operadores): libera la isla reclamada más cercana (a menos de 24 bloques).
- `/locate structure isladragoncitos:isla` para encontrar una isla.
- Los operadores (nivel 2) no tienen restricciones de protección.

## Ajustar la frecuencia
`src/main/resources/data/isladragoncitos/worldgen/structure_set/islas.json`: `spacing` (distancia media entre intentos, en chunks) y `separation`.
Dentro de `IslaStructure.java`, `NO_RIVER_CHANCE` controla cuántas islas aparecen lejos de un río.

## Compilar con GitHub (sin instalar nada)
1. Sube a un repositorio **este .zip tal cual** (sin descomprimir) y el archivo `.github/workflows/build.yml`
   (créalo con *Add file → Create new file* escribiendo la ruta `.github/workflows/build.yml`).
2. GitHub descomprime el zip, compila y deja el `.jar` en **Actions → último run → Artifacts → mod-jar**.
3. Copia el `.jar` a la carpeta `mods` de Forge 1.20.1.

Compilar en local: `gradle build` (Gradle 8.1.1, JDK 17). El jar queda en `build/libs/`.

## 1.6.1
- Volver: si el dragon esta explorando o de viaje lejos de ti, sus chunks se mantienen cargados y al darle "Seguir" vuelve (si esta a mas de 90 bloques o tarda demasiado, se teletransporta junto a ti). Explorar tiene un limite de 600 bloques de distancia.
- Seguir como un lobo: te sigue hasta quedar a una distancia razonable (que crece con su tamano) y alli se detiene y se entretiene paseando por los alrededores, sin pegarse a ti y sin huir cuando te acercas.
- Cabeza: el giro de cabeza del modelo se normaliza y se acota, ya no da vueltas sin parar.
- Camara: el jinete se sienta por encima de todo el modelo y, en primera persona, el cuerpo del dragon grande que montas no se dibuja, asi la vista siempre esta despejada.

## 1.6.2 (dragon del agua nuevo y dragon de hielo epico)
- **Dragon del agua**: nuevo modelo 3D exclusivo inspirado en la babosa azul (*Glaucus atlanticus*): cuerpo plateado-azulado, cuello largo, antenas, cola que termina en un abanico de plumas y alas hechas de abanicos de plumas con puntas que brillan. Animaciones propias (reposo, caminar, volar, planear, nadar, aliento y mordisco).
- **Dragon de hielo**: nuevo modelo 3D epico basado en la ilustracion de referencia: cuerpo azul marino oscuro cubierto de escarcha, cuello en S con pinchos, cabeza con cuernos barridos hacia atras y ojos cian, cresta de cristales de hielo en el lomo y los hombros, nucleo luminoso en el pecho, cola con hoja de cristal y **alas enormes** de cuatro dedos con membranas azules, garra curva en la muneca y puntas que brillan en la oscuridad.
- Animaciones del dragon de hielo: reposo (respira con las alas plegadas), caminar, volar (aleteo escalonado: hombro, codo, muneca y dedos), planear, aliento y mordisco.
- Archivos: `ice_dragon.*` y `water_dragon.*` en `geo/entity`, `animations/entity` y `textures/entity` (la textura tiene su `_glowmask`).
- El tamano del dragon de hielo se ajusta con `ICE_MODEL_SCALE` en `AncientDragonRenderer` (0.8 por defecto); `MODEL_SCALE` sigue valiendo para todos.



## Novedades 1.7.0 (Sistema Maestro)
- **103 especies de dragón** (`DragonSpecies`): 60 elementos (Fuego, Tiempo, Vacío, Sol, Luna, Psique, Suerte, Leyenda, Gravedad…), 7 rarezas (Común a Divino), tamaño, vida y daño propios, una **pasiva** y un **ataque especial** por elemento. Los huevos sortean la especie según su rareza (los Ancestrales y Divinos solo salen por comando u ofrenda). El modelo 3D se toma del tipo base del elemento y se tiñe con su color.
- **50 habilidades draconianas** (`DraconicAbilities`): Dragon Nova (30 bloques, 200 de daño), Estasis Temporal, Implosión del Vacío, Llamarada Solar, Eclipse Lunar, Pozo de Gravedad, teletransportes, rayos, curas, escudos… Se aprenden con un **Manuscrito Draconiano** y puntos draconianos (hace falta la Marca del Jinete). **R** lanza, **V** cambia de habilidad. Nunca dañan a tu dragón ni a tus mascotas.
- **Árbol de la Vida**: estructura colosal con una cámara en la base y el **Corazón del Árbol de la Vida**. Con la vida unida a un dragón: **Marca Nivel 2** (vida compartida x2), +50 puntos y una habilidad al azar. Después, botín infinito (manzanas doradas, materiales, manuscritos y, a veces, cualquier objeto del juego).
- **Estructuras masivas**: Castillo del Dragón (murallas, 4 torres, torreón con altar y huevo), Cueva del Dragón (sala enorme, tesoro y nido con huevo), Santuario y Aldea de Adoradores.
- **Adoradores de los Dragones**: NPCs pacíficos; dales una escama y te dan esencia (y a veces un manuscrito).
- **Códice Dracónico**: enciclopedia interactiva; las especies se descubren al criarlas.
- **Materiales y crafteos legendarios**: Esencia de Dragón, Fragmento del Tiempo, Polvo Cósmico, Núcleo del Vacío, Copo Solar, Lágrima Lunar → Hoz de Cronos, Placa Omega, Corona de la Psique, Moneda de Fortuna.
- Comandos nuevos: `/dragon habilidades`, `/dragon habilidad <id>`, y (op o creativo) `/dragon puntos <n>`, `/dragon aprender <id>`, `/dragon manuscrito <id>`, `/dragon especie <id>`.
- Corregido: `ModItems` había perdido los objetos originales y `DraconicData` varios métodos; el `build.yml` ahora descomprime el zip y compila solo.

## Novedades 1.8.0 (Dragón Celeste)
- **Nuevo diseño 3D: la Serpiente Celeste** (modelo base *Celeste*, tipo 4). Es totalmente distinta a los otros cuatro dragones: **sin alas ni patas**, cuerpo largo y ondulante de serpiente (como un dragón de cielo oriental), cuello que se alza en arco, **cornamenta de cristal** ramificada, **bigotes largos** que ondean, melena y barba de cintas, **cintas flotantes** a los lados de la cola y una **aleta caudal en llama**.
- Lleva una **perla celestial flotante** delante de la boca con **dos anillos de runas** que giran, y **4 estrellas** que orbitan a su alrededor.
- Piel azul medianoche que se aclara hasta verde aurora en la cola, vientre perlado, líneas de aurora y estrellitas que brillan en la oscuridad (ojos, cristales, perla, cintas y anillos).
- Animaciones: quieto, caminar (reptando), volar, planear, nadar, nadar quieto, aliento (alza la cabeza y abre la boca) y mordisco.
- Especie nueva: **Aurora Wyrm** (`aurora_wyrm`, legendaria). Para probarla: `/dragon especie aurora_wyrm` con tu dragón cerca (necesita trucos activados).
- Archivos: `geo/entity/sky_dragon.geo.json`, `textures/entity/sky_dragon.png` (+ `_glowmask`) y `animations/entity/sky_dragon.animation.json`. El tamaño se ajusta con `SKY_MODEL_SCALE` en `AncientDragonRenderer`.

## 1.9.0 - Gran Arbol del Mundo, elfos, castillos y cuevas
- Estructura unica por mundo: `isladragoncitos:world_tree` (`/locate structure isladragoncitos:world_tree`).
- Castillos y cuevas: `castle_dragon`, `castle_elf`, `cave_hoard`, `cave_crystal`.
- Nueva raza: Elfo de Alfheim (huevo generador en la pestana creativa) y hojas doradas del arbol.

## 1.10.0 - Bestiario Draconiano
- **Bestiario Draconiano** (`bestiary`): te lo entregan **solo una vez al pisar el mundo** (a los 2 segundos de entrar), junto con el logro **El Bestiario de los Jinetes**. Si lo pierdes: `/dragon bestiario`, receta (libro + escama rosa) o pestaña creativa.
- Clic derecho para abrirlo. 10 secciones con pestañas, listas con rueda del ratón y selección por clic:
  - **Inicio** (cómo empezar y tu progreso), **Tipos** (Fuego, Hielo, Tormenta, Agua, Celeste y dragoncitos), **Dragones** (las 104 especies: rareza, probabilidad exacta en huevo, estadísticas, pasiva, ataque especial, cómo encontrarlo y subirlo; marca las que ya has criado), **Rarezas**, **Habilidades** (las 50, con coste, recarga, alcance, daño y si ya la conoces), **Subir nivel** (comida, puntos, mejoras, vida compartida, Marca del Jinete, Edulnari), **Dónde buscar** (todas las estructuras con su id para `/locate`), **Objetos**, **Criaturas** y **Controles**.
- Los textos y cifras salen de los datos reales del mod (especies, rarezas y habilidades), así que se actualizan solos si añades más.

## 1.11.0 - Dragón de Cristal y Dragón del Vacío
- **Dos modelos 3D nuevos** para el dragón antiguo: **Cristal** (tipo 5) y **Vacío** (tipo 6). Ya son **siete tipos** de dragón antiguo, cada uno con su modelo, textura y capa que brilla en la oscuridad.
- **Dragón de Cristal**: cuerpo de prismas facetados color cian, escamas de gema, **alas translúcidas** y un **núcleo luminoso** con **cuatro prismas de cristal** girando bajo el pecho. Aliento de esquirlas: ralentiza y deja **brillando** a los enemigos (partículas de crítico y campanilla de amatista); su pasiva da **regeneración** a su jinete y hace brillar a los enemigos cercanos. Especies: **Crystal Core**, **Quartz Beam** y **Prism Wing**.
- **Dragón del Vacío**: placas oscuras, **ojos de energía** y un **halo de ocho esquirlas flotantes** que gira a su alrededor. Aliento del vacío: **marchita** a los enemigos (Wither) y apaga el fuego (partículas de portal y lamento de almas); su pasiva marchita sin descanso a los enemigos cercanos. Especies: **Void Echo**, **Void Stalker**, **Void Emperor** y **Omega Dragon**.
- **Animaciones completas** para ambos: reposo, caminar, volar, planear, aliento y mordisco; la cabeza sigue hacia donde mira. Archivos en `geo/entity`, `animations/entity` y `textures/entity` (`crystal_dragon.*` y `void_dragon.*`, con `_glowmask`).
- **Huevos nuevos**: Huevo de Dragón Antiguo de **Cristal** y del **Vacío**, con bloque, objeto, icono propio, modelo, blockstate y loot table. Se consiguen en la pestaña creativa del mod (no se generan solos en el mundo). Al eclosionar sortean una especie de su tipo.
- **Bestiario, menú y corazón**: la sección Tipos del Bestiario y el Códice muestran los siete tipos; el menú del dragón (G) tiene tema y vista previa para Cristal y Vacío; el corazón de la vida compartida usa su color propio.
- **Más variedad natural**: los dragones antiguos que aparecen por el mundo ahora pueden ser de cualquiera de los siete tipos.
- El tamaño se ajusta con `CRYSTAL_MODEL_SCALE` (0,9) y `VOID_MODEL_SCALE` (0,85) en `AncientDragonRenderer`; el resto usa `MODEL_SCALE`.

## 1.12.0 - Dragón Solar, Caparazón, Lunar y Ancestral
- **Cuatro modelos 3D nuevos** para el dragón antiguo (unidos a Cristal y Vacío): ya son **once tipos**. Todos tienen su geo, textura con `_glowmask` y animaciones propias (reposo, caminar, volar, planear, aliento y mordisco; Caparazón, Lunar y Ancestral incluyen además clips de nado).
- **Dragón Solar** (tipo 7): dragón de escamas doradas y marfil con alas de luz y un núcleo incandescente. Su aliento es una llamarada con núcleo blanco que **prende fuego**, deja **brillando** a los enemigos y castiga un 35% extra a los no muertos; su pasiva protege del fuego.
  - Las especies de **Luz, Sagrado, Sol, Cénit y Fotón** ahora usan este modelo (Lumina Sol, Sun Guardian, Solar Deity, Photon Ray, Zenith Star...), más la nueva **Ancient Sun** (`original_sun`, rara).
  - **Huevo de Dragón Solar**: 1 de cada 9 huevos escondidos bajo tierra es solar. También está en la pestaña creativa, con bloque, objeto, icono, modelo, blockstate y loot table.
- **Dragón Caparazón** (tipo 8): tortuga-dragón colosal con patas como pilares, cuernos de piedra y una maza con cristales en la cola. Sobre el caparazón crece un **jardín flotante**: cerezo con pétalos, estanque, cascada, lianas, musgo y cristales, con tres rocas orbitando. Especie: **Mossback Titan** (`mossback_titan`, legendaria).
- **Dragón Lunar** (tipo 9): polilla-dragón de cuerpo peludo, ojos compuestos, cuernos en media luna y gema lunar en la frente; **cuatro alas de mariposa** con ojos de luna y colas, antenas plumosas y penacho en la cola. Especie: **Luna Wyrm** (`luna_wyrm`, legendaria).
- **Dragón Ancestral** (tipo 10): el dragón clásico definitivo, de marfil y oro, con **cuatro alas enormes en abanico**, cuernos dobles, corona de cristal de hielo y una **aureola de 16 runas** girando tras la cabeza. Especie: **Primordial Elder** (`primordial_elder`, legendaria, la más fuerte: 400 de vida extra y x3 de daño).
- **Tres elementos nuevos** (`TITAN`, `LUNAR`, `PRIMAL`) con su pasiva, partículas y ataque especial (Temblor, Lluvia de estrellas...). El mod pasa a **108 especies**.
- Caparazón, Lunar y Ancestral **no tienen huevo propio**: salen con el huevo generador de Dragón Antiguo (el tipo se sortea entre los once) o con `/dragon especie <id>`.
- **Bestiario, Códice, menú y corazón**: la sección Tipos muestra los once tipos con sus especies y de dónde sale cada huevo; el menú del dragón (G) tiene tema y vista previa para los cuatro nuevos; el corazón de la vida compartida usa su color propio; `/dragon texto` y el Edulnari muestran sus nombres.
- El tamaño se ajusta con `MOON_MODEL_SCALE` (1,3) y `ELDER_MODEL_SCALE` (1,1); Solar y Caparazón usan la escala normal.

## 1.13.0 - Dragones legendarios, red de portales y armadura dracónica
- **Rediseño completo de los once dragones**: cada modelo recibe entre 111 y 166 cubos nuevos de orfebrería (1.636 en total) repartidos por cabeza, cuello, lomo, hombros, patas, alas y cola: coronas de puntas con gemas, cuernos curvos y barridos, placas en la frente y las cejas, colmillos, crestas dorsales, hombreras, brazaletes y espolones en las patas, garras y venas de gema en las alas, aletas caudales y núcleos luminosos. Las texturas se amplían con una **banda nueva de materiales** (oro, hueso, gema y acento) y los `_glowmask` se repintan para que ojos, gemas y filigranas brillen de noche. Las animaciones no cambian: los once conservan sus clips de reposo, caminar, volar, planear, nado (los que nadan), aliento y mordisco.
- **Portal del Dragón** (`dragon_portal`): hoja de energía de 3×5 en un marco de piedra de dragón con pilonos, dintel escalonado y lámparas. **Aparece en todas las estructuras masivas del mod** (castillos, cuevas, santuarios, aldeas, puertas, observatorios y criaderos). Al atravesarlo te lleva a **otro portal al azar de la red del mundo**, con preferencia por los que están a **256 bloques o más** y nunca a otro portal del mismo monumento: llegada segura, sonido y partículas en ambos extremos, **5 segundos de recarga**, aviso si aún no hay otro portal o si el gemelo se apagó, y hay que **bajar de la montura** para cruzar (agachado o en espectador tampoco se activa). La red se guarda con el mundo (`isladragoncitos_portales`), así que sobrevive a recargar la partida.
- **Piedra de dragón**: `dragonstone_bricks`, `chiseled_dragonstone` y `dragon_lamp` (luz 15), con receta, loot y pico; el portal es indestructible, no tiene colisión y también ilumina.
- **Tres estructuras nuevas, todas con portal**:
  - **Puerta del Dragón** (`isladragoncitos:dragon_gate`): muralla almenada con puerta central, **torres gemelas** de tres pisos con escaleras y cofres, avenida de pilonos con lámparas, patio de honor con alfombra y un altar con huevo, 4 cofres y 3 adoradores.
  - **Observatorio del Dragón** (`isladragoncitos:dragon_observatory`): torre circular de tres alturas con biblioteca, escalera de mano, **cúpula de cristal** con costillas de pizarra y un **telescopio de cobre** que asoma por el techo; huevo celeste en el altar, 3 cofres y 4 adoradores.
  - **Criadero Ancestral** (`isladragoncitos:dragon_hatchery`): cúpula de cristal sobre ocho pilares, **cinco nidos de obsidiana** (cada uno con huevo, cofre y adorador), altar central de oro con otro huevo, dos estanques y vegetación; 7 cofres y 8 adoradores en total.
  - Los huevos de la puerta y del criadero sortean cualquiera de los ocho tipos con huevo (fuego, hielo, tormenta, agua, celeste, cristal, vacío y solar); el observatorio guarda siempre uno celeste.
- **Armadura dracónica**: yelmo, coraza, grebas y botas forjadas con **5, 8, 7 y 4 escamas de cualquier color + 1 esencia de dragón** respectivamente. Defensa 4/9/7/4, dureza 4, resistencia al empuje 0,15, encantabilidad 25, durabilidad 605/880/825/715, se repara con esencia y **brilla** (foil). Con el **set completo** otorga **Resistencia I y Caída lenta** mientras lo lleves, un aura de partículas y el logro **Égida dracónica** (reto). Tiene capas de armadura propias (`draconic_layer_1/2`).
- **Dragones ancestrales salvajes**: solo en el Overworld, cada 20 s hay una probabilidad de 1 entre 30 de que aparezca uno si no hay otro salvaje a 224 bloques; llega a 64–112 bloques del jugador y 20–40 sobre el terreno. El **70 % son del tipo Ancestral** y el resto sortea entre los diez tipos, con **20–40 escamas**, fuerza 30–79 y mucha vida, y no desaparecen. Vuelan, se posan, cazan monstruos y animales, rugen con partículas y **no se pueden domesticar** (si les ofreces comida te lo dicen); solo atacan si los atacas. Contemplarlos a menos de 64 bloques da el logro **Testigo del Alba**.
- Todos los textos nuevos están traducidos en los siete idiomas del mod (204 claves por archivo).
