package com.isladragoncitos.block;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Hojas doradas del Gran Arbol del Mundo. Las hojas con fruto sueltan, de vez en cuando, una manzana
 * dorada o un objeto cualquiera: el arbol que creo todo es capaz de crear todo. Nunca se marchitan.
 */
public class WorldTreeLeavesBlock extends LeavesBlock {
    public static final BooleanProperty FRUIT = BooleanProperty.create("fruit");

    /** Una de cada tantos "random ticks" suelta algo (las hojas con fruto solamente). */
    private static final int DROP_CHANCE = 110;
    /** Para no llenar el suelo de objetos: si ya hay muchos cerca, no cae nada. */
    private static final int MAX_NEARBY_ITEMS = 48;

    private static final Set<String> BLACKLIST = Set.of(
            "air", "barrier", "light", "command_block", "chain_command_block", "repeating_command_block",
            "command_block_minecart", "structure_block", "structure_void", "jigsaw", "debug_stick",
            "knowledge_book", "bedrock", "petrified_oak_slab", "reinforced_deepslate", "end_portal_frame");

    private static List<Item> pool;

    public WorldTreeLeavesBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(DISTANCE, 1)
                .setValue(PERSISTENT, Boolean.TRUE)
                .setValue(WATERLOGGED, Boolean.FALSE)
                .setValue(FRUIT, Boolean.FALSE));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(FRUIT);
    }

    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return state.getValue(FRUIT) || super.isRandomlyTicking(state);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        super.randomTick(state, level, pos, random);
        if (!state.getValue(FRUIT) || random.nextInt(DROP_CHANCE) != 0) {
            return;
        }
        BlockPos below = pos.below();
        if (!level.getBlockState(below).isAir()) {
            return;
        }
        AABB area = new AABB(pos).inflate(48.0D);
        if (level.getEntitiesOfClass(ItemEntity.class, area).size() >= MAX_NEARBY_ITEMS) {
            return;
        }
        ItemStack drop = this.pickDrop(random);
        ItemEntity entity = new ItemEntity(level, below.getX() + 0.5D, below.getY() + 0.3D, below.getZ() + 0.5D, drop);
        entity.setDefaultPickUpDelay();
        level.addFreshEntity(entity);
        level.sendParticles(ParticleTypes.END_ROD, below.getX() + 0.5D, below.getY() + 0.6D, below.getZ() + 0.5D,
                6, 0.25D, 0.25D, 0.25D, 0.02D);
    }

    private ItemStack pickDrop(RandomSource random) {
        int roll = random.nextInt(100);
        if (roll < 52) {
            return new ItemStack(Items.GOLDEN_APPLE, 1 + random.nextInt(2));
        }
        if (roll < 55) {
            return new ItemStack(Items.ENCHANTED_GOLDEN_APPLE);
        }
        Item item = randomItem(random);
        int max = Math.max(1, Math.min(item.getMaxStackSize(), 4));
        return new ItemStack(item, 1 + random.nextInt(max));
    }

    /** Cualquier objeto del juego (de cualquier mod), salvo los puramente tecnicos que rompen la partida. */
    public static Item randomItem(RandomSource random) {
        if (pool == null) {
            List<Item> list = new ArrayList<>();
            for (Item item : ForgeRegistries.ITEMS) {
                ResourceLocation key = ForgeRegistries.ITEMS.getKey(item);
                if (key != null && !BLACKLIST.contains(key.getPath())) {
                    list.add(item);
                }
            }
            pool = list;
        }
        return pool.get(random.nextInt(pool.size()));
    }
}
