package com.isladragoncitos.client;

/** Colores del menu segun el tipo de dragon: 0 fuego, 1 hielo, 2 tormenta, 3 agua, 4 celeste, 5 cristal, 6 vacio, 7 sol, 8 caparazon, 9 lunar, 10 ancestral. */
public record DragonTheme(String name, int accent, int light, int mid, int dark) {
    private static final DragonTheme[] THEMES = {
            new DragonTheme("Dragón de Fuego", 0xFFFF7A2E, 0xFFFFD27F, 0xFF4A1A0C, 0xFF200A05),
            new DragonTheme("Dragón de Hielo", 0xFF6FE0FF, 0xFFD8F6FF, 0xFF123A4F, 0xFF07161F),
            new DragonTheme("Dragón de Tormenta", 0xFFB98CFF, 0xFFFFE066, 0xFF2A1A52, 0xFF100820),
            new DragonTheme("Dragón del Agua", 0xFF47B6FF, 0xFFA8F0E8, 0xFF0E3566, 0xFF051326),
            new DragonTheme("Dragón Celeste", 0xFF8FFFE0, 0xFFF3D9FF, 0xFF1E1D5C, 0xFF0A0A26),
            new DragonTheme("Dragón de Cristal", 0xFF7FE8FF, 0xFFEAFDFF, 0xFF17414D, 0xFF071F26),
            new DragonTheme("Dragón del Vacío", 0xFFB96CFF, 0xFFE7CCFF, 0xFF2A1440, 0xFF0C0616),
            new DragonTheme("Dragón Solar", 0xFFFFC83D, 0xFFFFF3C4, 0xFF5A3A08, 0xFF241604),
            new DragonTheme("Dragón Caparazón", 0xFF8FE36A, 0xFFFFD6E8, 0xFF2B3A22, 0xFF0F150C),
            new DragonTheme("Dragón Lunar", 0xFFD9B8FF, 0xFFFFF1B8, 0xFF2E1F5C, 0xFF0F0A24),
            new DragonTheme("Dragón Ancestral", 0xFFBFEFFF, 0xFFF1D58A, 0xFF1C3A4A, 0xFF08141C)
    };

    public static DragonTheme of(int type) {
        return THEMES[Math.max(0, Math.min(THEMES.length - 1, type))];
    }

    public static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
