package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.ElfEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

public class ElfRenderer extends MobRenderer<ElfEntity, ElfModel> {
    private static final ResourceLocation[] TEXTURES = {
            texture("guardian"), texture("sage"), texture("gardener")
    };

    public ElfRenderer(EntityRendererProvider.Context context) {
        super(context, new ElfModel(context.bakeLayer(ElfModel.LAYER_LOCATION)), 0.4F);
        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    private static ResourceLocation texture(String name) {
        return new ResourceLocation(IslaDragoncitosMod.MODID, "textures/entity/elf_" + name + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(ElfEntity entity) {
        return TEXTURES[Math.floorMod(entity.getVariant(), TEXTURES.length)];
    }
}
