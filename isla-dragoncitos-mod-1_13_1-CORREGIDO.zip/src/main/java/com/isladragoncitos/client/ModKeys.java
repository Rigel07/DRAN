package com.isladragoncitos.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

public final class ModKeys {
    /** Abre el menu del dragon (G por defecto; se puede cambiar en Controles). */
    public static final KeyMapping DRAGON_MENU = new KeyMapping("key.isladragoncitos.dragon_menu",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.isladragoncitos");

    /** Lanza la habilidad draconiana seleccionada (R). */
    public static final KeyMapping ABILITY_CAST = new KeyMapping("key.isladragoncitos.ability_cast",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.isladragoncitos");

    /** Cambia a la siguiente habilidad draconiana (V). */
    public static final KeyMapping ABILITY_CYCLE = new KeyMapping("key.isladragoncitos.ability_cycle",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.isladragoncitos");

    private ModKeys() {}
}
