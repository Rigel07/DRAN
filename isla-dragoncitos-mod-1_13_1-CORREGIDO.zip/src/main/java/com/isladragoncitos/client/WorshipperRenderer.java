package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.DragonWorshipperEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Los adoradores se dibujan con el modelo humanoide y una piel propia (tunica roja con ribete dorado). */
public class WorshipperRenderer extends HumanoidMobRenderer<DragonWorshipperEntity, HumanoidModel<DragonWorshipperEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(IslaDragoncitosMod.MODID, "textures/entity/worshipper.png");

    public WorshipperRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(DragonWorshipperEntity entity) {
        return TEXTURE;
    }
}
