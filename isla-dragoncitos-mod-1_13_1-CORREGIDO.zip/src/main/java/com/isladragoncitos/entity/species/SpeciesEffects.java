package com.isladragoncitos.entity.species;

import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.entity.species.DragonSpecies.Element;
import com.isladragoncitos.entity.species.DragonSpecies.SpeciesData;
import java.util.List;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Pasivas y ataques especiales de las especies de dragon, segun su elemento y su rareza. */
public final class SpeciesEffects {
    private SpeciesEffects() {}

    /** Los efectos que la pasiva da al dueño (a) y los que pone a los enemigos cercanos (b). */
    private record Fx(MobEffect owner, int ownerAmp, MobEffect ownerExtra, MobEffect foe, int foeAmp, boolean ignite) {}

    private static Fx fx(Element e) {
        return switch (e) {
            case FIRE, RUBY, AMBER, SULFUR -> new Fx(MobEffects.FIRE_RESISTANCE, 0, null, null, 0, e == Element.SULFUR);
            case MAGMA, SUN, PHOTON, ZENITH -> new Fx(MobEffects.FIRE_RESISTANCE, 0, MobEffects.DIG_SPEED, null, 0, true);
            case ICE, TUNDRA, CLOUD, STEAM -> new Fx(null, 0, null, MobEffects.MOVEMENT_SLOWDOWN, 0, false);
            case STORM, NEON, PLASMA -> new Fx(MobEffects.MOVEMENT_SPEED, 0, null, null, 0, false);
            case WATER, SAPPHIRE, COBALT, ECHO -> new Fx(MobEffects.WATER_BREATHING, 0, MobEffects.DOLPHINS_GRACE, null, 0, false);
            case SHADOW, ONYX, NADIR, GHOST -> new Fx(MobEffects.NIGHT_VISION, 0, null, MobEffects.BLINDNESS, 0, false);
            case LIGHT, HOLY, CRYSTAL, QUARTZ, PRISM -> new Fx(MobEffects.REGENERATION, 0, null, MobEffects.GLOWING, 0, false);
            case EARTH, METAL, TITANIUM, OBSIDIAN, GRAPHENE, ORDER, TITAN -> new Fx(MobEffects.DAMAGE_RESISTANCE, 0, null, null, 0, false);
            case WIND, PAPER -> new Fx(MobEffects.JUMP, 1, MobEffects.SLOW_FALLING, null, 0, false);
            case POISON, JUNGLE -> new Fx(null, 0, null, MobEffects.POISON, 0, false);
            case COSMIC, MOON, ETHER, LUNAR -> new Fx(MobEffects.NIGHT_VISION, 0, MobEffects.SLOW_FALLING, MobEffects.GLOWING, 0, false);
            case PRIMAL -> new Fx(MobEffects.DAMAGE_BOOST, 1, MobEffects.DAMAGE_RESISTANCE, MobEffects.WEAKNESS, 0, false);
            case VOID -> new Fx(null, 0, null, MobEffects.WITHER, 0, false);
            case NATURE, FOREST, EMERALD -> new Fx(MobEffects.REGENERATION, 0, null, MobEffects.MOVEMENT_SLOWDOWN, 0, false);
            case TIME, DIMENSION -> new Fx(MobEffects.DIG_SPEED, 1, MobEffects.MOVEMENT_SPEED, MobEffects.MOVEMENT_SLOWDOWN, 1, false);
            case LUCK -> new Fx(MobEffects.LUCK, 2, null, null, 0, false);
            case PSYCHE, MIRROR -> new Fx(MobEffects.NIGHT_VISION, 0, null, MobEffects.CONFUSION, 0, false);
            case LEGEND -> new Fx(MobEffects.DAMAGE_BOOST, 0, MobEffects.DAMAGE_RESISTANCE, MobEffects.WEAKNESS, 0, false);
            case GRAVITY, MAGNITUDE -> new Fx(MobEffects.JUMP, 2, null, MobEffects.MOVEMENT_SLOWDOWN, 1, false);
            case CHAOS -> new Fx(MobEffects.DAMAGE_BOOST, 0, null, MobEffects.CONFUSION, 0, false);
            case BLOOD, SOUL -> new Fx(MobEffects.DAMAGE_BOOST, 0, null, MobEffects.WEAKNESS, 0, false);
            case SAND, DESERT, STEAM_PUNK, MERCURY -> new Fx(MobEffects.MOVEMENT_SPEED, 0, null, MobEffects.MOVEMENT_SLOWDOWN, 0, false);
            case SKY -> new Fx(MobEffects.SLOW_FALLING, 0, MobEffects.NIGHT_VISION, MobEffects.GLOWING, 0, false);
            default -> new Fx(null, 0, null, null, 0, false);
        };
    }

    private static int power(SpeciesData species) {
        return Math.min(3, species.rarity.ordinal() / 2);
    }

    /** Pasiva: se llama cada 2 segundos en el servidor. */
    public static void tickPassive(AncientDragonEntity dragon) {
        if (!(dragon.level() instanceof ServerLevel level) || !dragon.isTame()) {
            return;
        }
        SpeciesData species = dragon.getSpecies();
        if (species == null) {
            return;
        }
        Fx fx = fx(species.element);
        int power = power(species);
        LivingEntity owner = dragon.getOwner();
        if (owner != null && dragon.distanceToSqr(owner) < 40.0D * 40.0D) {
            if (fx.owner() != null) {
                owner.addEffect(new MobEffectInstance(fx.owner(), 100, Math.min(3, fx.ownerAmp() + (power >= 3 ? 1 : 0)), true, false));
            }
            if (fx.ownerExtra() != null) {
                owner.addEffect(new MobEffectInstance(fx.ownerExtra(), 100, 0, true, false));
            }
            // pasiva de los jefes divinos: ademas, resistencia
            if (species.rarity.ordinal() >= DragonSpecies.Rarity.DIVINE.ordinal()) {
                owner.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 1, true, false));
            }
        }
        if (fx.foe() != null || fx.ignite()) {
            double radius = 8.0D + power * 3.0D;
            for (LivingEntity foe : level.getEntitiesOfClass(LivingEntity.class, dragon.getBoundingBox().inflate(radius),
                    entity -> entity instanceof Enemy && entity.isAlive())) {
                if (fx.foe() != null) {
                    foe.addEffect(new MobEffectInstance(fx.foe(), 60, Math.min(2, fx.foeAmp() + power / 2)));
                }
                if (fx.ignite()) {
                    foe.setSecondsOnFire(2 + power);
                }
            }
        }
    }

    private static ParticleOptions particle(Element e) {
        return switch (e) {
            case FIRE, MAGMA, RUBY, AMBER, SULFUR, STEAM_PUNK, SAND, DESERT -> ParticleTypes.FLAME;
            case ICE, TUNDRA, CLOUD, PAPER -> ParticleTypes.SNOWFLAKE;
            case STORM, NEON, PLASMA, PHOTON -> ParticleTypes.ELECTRIC_SPARK;
            case WATER, SAPPHIRE, COBALT, ECHO, MERCURY -> ParticleTypes.SPLASH;
            case SHADOW, VOID, ONYX, NADIR, OBSIDIAN, GRAPHENE -> ParticleTypes.LARGE_SMOKE;
            case LIGHT, HOLY, SUN, ZENITH, LEGEND -> ParticleTypes.END_ROD;
            case NATURE, FOREST, JUNGLE, EMERALD, POISON -> ParticleTypes.HAPPY_VILLAGER;
            case SOUL, GHOST, BLOOD -> ParticleTypes.SOUL_FIRE_FLAME;
            case COSMIC, MOON, ETHER, MAGNITUDE, DIMENSION, GRAVITY -> ParticleTypes.PORTAL;
            case TIME, PSYCHE, MIRROR, ORDER, CHAOS -> ParticleTypes.ENCHANT;
            case LUCK -> ParticleTypes.TOTEM_OF_UNDYING;
            case CRYSTAL, QUARTZ, PRISM, TITANIUM, METAL -> ParticleTypes.CRIT;
            case STEAM -> ParticleTypes.CLOUD;
            case EARTH, TITAN -> ParticleTypes.CAMPFIRE_COSY_SMOKE;
            case WIND -> ParticleTypes.CLOUD;
            case SKY, LUNAR, PRIMAL -> ParticleTypes.END_ROD;
            default -> ParticleTypes.CLOUD;
        };
    }

    private static boolean friendly(AncientDragonEntity dragon, LivingEntity other) {
        if (other == dragon || other == dragon.getOwner() || other instanceof Player) {
            return true;
        }
        if (other instanceof OwnableEntity pet && pet.getOwnerUUID() != null && pet.getOwnerUUID().equals(dragon.getOwnerUUID())) {
            return true;
        }
        return other instanceof AncientDragonEntity;
    }

    /** Ataque especial sobre un objetivo; devuelve true si se lanzo (el dragon pone en cooldown). */
    public static boolean castSpecial(AncientDragonEntity dragon, LivingEntity target) {
        if (!(dragon.level() instanceof ServerLevel level)) {
            return false;
        }
        SpeciesData species = dragon.getSpecies();
        if (species == null || target == null || !target.isAlive() || friendly(dragon, target)) {
            return false;
        }
        int power = power(species);
        double radius = 3.0D + power * 1.5D;
        float damage = (3.0F + species.rarity.ordinal() * 1.5F) * Math.max(1.0F, species.damageMultiplier * 0.6F);
        Element e = species.element;
        Vec3 at = target.position().add(0.0D, target.getBbHeight() * 0.5D, 0.0D);

        List<LivingEntity> victims = level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(radius),
                entity -> entity.isAlive() && !friendly(dragon, entity));
        Fx fx = fx(e);
        for (LivingEntity victim : victims) {
            victim.hurt(level.damageSources().mobAttack(dragon), damage);
            if (fx.foe() != null) {
                victim.addEffect(new MobEffectInstance(fx.foe(), 80 + power * 40, Math.min(3, fx.foeAmp() + power / 2)));
            }
            if (fx.ignite()) {
                victim.setSecondsOnFire(4 + power * 2);
            }
            switch (e) {
                case WIND, EARTH, GRAVITY, MAGNITUDE, TITAN -> {
                    Vec3 push = victim.position().subtract(dragon.position()).normalize();
                    boolean pull = e == Element.GRAVITY;
                    victim.push(push.x * (pull ? -0.9D : 1.2D), (e == Element.EARTH || e == Element.TITAN) ? 0.9D : 0.35D, push.z * (pull ? -0.9D : 1.2D));
                    victim.hurtMarked = true;
                }
                case TIME -> victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 6));
                case VOID, NADIR -> victim.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1));
                case ICE, TUNDRA, AMBER -> victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 3));
                case SHADOW, ONYX -> victim.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0));
                case PSYCHE, MIRROR, CHAOS -> victim.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0));
                case HOLY, LIGHT, ZENITH, PRISM -> victim.addEffect(new MobEffectInstance(MobEffects.GLOWING, 120, 0));
                case LUCK -> victim.addEffect(new MobEffectInstance(MobEffects.UNLUCK, 200, 1));
                case LUNAR -> {
                    victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
                    victim.addEffect(new MobEffectInstance(MobEffects.GLOWING, 120, 0));
                }
                case PRIMAL -> {
                    victim.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1));
                    victim.addEffect(new MobEffectInstance(MobEffects.GLOWING, 120, 0));
                }
                default -> {
                }
            }
        }
        if (e == Element.STORM || e == Element.PLASMA) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
            if (bolt != null) {
                bolt.moveTo(target.getX(), target.getY(), target.getZ());
                bolt.setVisualOnly(true);
                level.addFreshEntity(bolt);
            }
        }
        level.sendParticles(particle(e), at.x, at.y, at.z, 40 + power * 20, radius * 0.4D, radius * 0.3D, radius * 0.4D, 0.05D);
        level.playSound(null, target.blockPosition(), SoundEvents.DRAGON_FIREBALL_EXPLODE, SoundSource.HOSTILE, 1.0F, 0.9F + level.random.nextFloat() * 0.3F);
        return true;
    }

    /** Cooldown del ataque especial en ticks: las especies mas raras lo lanzan antes. */
    public static int cooldownTicks(SpeciesData species) {
        return Math.max(60, 200 - species.rarity.ordinal() * 20);
    }

    private static String effectName(MobEffect effect) {
        return effect.getDisplayName().getString();
    }

    /** Descripcion de la pasiva (para el Bestiario). */
    public static String describePassive(Element element) {
        Fx fx = fx(element);
        StringBuilder text = new StringBuilder();
        if (fx.owner() != null) {
            text.append("Al jinete: ").append(effectName(fx.owner()));
            if (fx.ownerExtra() != null) {
                text.append(" y ").append(effectName(fx.ownerExtra()));
            }
            text.append(". ");
        } else if (fx.ownerExtra() != null) {
            text.append("Al jinete: ").append(effectName(fx.ownerExtra())).append(". ");
        }
        if (fx.foe() != null) {
            text.append("Enemigos cercanos: ").append(effectName(fx.foe())).append(". ");
        }
        if (fx.ignite()) {
            text.append("Prende fuego a los enemigos cercanos. ");
        }
        if (text.length() == 0) {
            text.append("Aura protectora. ");
        }
        return text.append("Solo si el dragón es tuyo y está cerca (cada 2 s).").toString();
    }

    /** Descripcion del ataque especial (para el Bestiario). */
    public static String describeSpecial(Element element) {
        Fx fx = fx(element);
        String extra;
        switch (element) {
            case STORM, PLASMA -> extra = "cae un rayo sobre el objetivo";
            case WIND, MAGNITUDE -> extra = "empuja a los enemigos lejos";
            case EARTH, TITAN -> extra = "lanza a los enemigos por el aire";
            case GRAVITY -> extra = "atrae a los enemigos hacia el dragón";
            case TIME -> extra = "congela el tiempo de los enemigos (lentitud extrema)";
            case VOID, NADIR -> extra = "marchita a los enemigos (efecto Wither)";
            case ICE, TUNDRA, AMBER -> extra = "frena a los enemigos";
            case SHADOW, ONYX -> extra = "ciega a los enemigos";
            case PSYCHE, MIRROR, CHAOS -> extra = "confunde a los enemigos";
            case HOLY, LIGHT, ZENITH, PRISM -> extra = "deja brillando a los enemigos";
            case LUCK -> extra = "les da mala suerte";
            case LUNAR -> extra = "los frena y los deja brillando";
            case PRIMAL -> extra = "los debilita con polvo estelar";
            default -> extra = fx.foe() != null ? "aplica " + effectName(fx.foe()) : (fx.ignite() ? "los prende fuego" : "golpe mágico");
        }
        return "Golpe en área sobre su objetivo; " + extra + ". Se lanza solo contra los enemigos del dragón.";
    }
}
