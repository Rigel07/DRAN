package com.isladragoncitos.item;

import com.isladragoncitos.IslaDragoncitosMod;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Pieza del set dracónico. Usa su propia capa de armadura y describe el bono de conjunto. */
public class DraconicArmorItem extends ArmorItem {
    public DraconicArmorItem(ArmorMaterial material, Type type, Properties properties) {
        super(material, type, properties);
    }

    @Override
    @Nullable
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        int layer = slot == EquipmentSlot.LEGS ? 2 : 1;
        return IslaDragoncitosMod.MODID + ":textures/models/armor/draconic_layer_" + layer
                + (type == null ? "" : "_" + type) + ".png";
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.isladragoncitos.draconic_set").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.isladragoncitos.draconic_bonus").withStyle(ChatFormatting.LIGHT_PURPLE));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
