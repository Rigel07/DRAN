package com.isladragoncitos.item;

import com.isladragoncitos.IslaDragoncitosMod;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.Structure;

/** Brujula de dragon: con clic derecho indica la direccion y la distancia de la isla mas cercana. */
public class DragonCompassItem extends Item {
    public static final TagKey<Structure> ISLANDS =
            TagKey.create(Registries.STRUCTURE, new ResourceLocation(IslaDragoncitosMod.MODID, "isla"));
    private static final String[] DIRECTIONS = {"e", "se", "s", "sw", "w", "nw", "n", "ne"};

    public DragonCompassItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(level instanceof ServerLevel serverLevel)) {
            return InteractionResultHolder.success(stack);
        }
        player.getCooldowns().addCooldown(this, 60);
        BlockPos found = serverLevel.findNearestMapStructure(ISLANDS, player.blockPosition(), 100, false);
        if (found == null) {
            player.displayClientMessage(Component.translatable("message.isladragoncitos.compass_none"), true);
            return InteractionResultHolder.success(stack);
        }
        double dx = found.getX() - player.getX();
        double dz = found.getZ() - player.getZ();
        int distance = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
        int index = Math.floorMod((int) Math.round(Math.toDegrees(Math.atan2(dz, dx)) / 45.0D), 8);
        player.displayClientMessage(Component.translatable("message.isladragoncitos.compass_found", distance,
                Component.translatable("direction.isladragoncitos." + DIRECTIONS[index])), true);

        double length = Math.max(1.0D, Math.sqrt(dx * dx + dz * dz));
        for (int i = 1; i <= 10; i++) {
            serverLevel.sendParticles(ParticleTypes.END_ROD, player.getX() + dx / length * i * 0.6D,
                    player.getY() + 1.2D, player.getZ() + dz / length * i * 0.6D, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        return InteractionResultHolder.success(stack);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.isladragoncitos.compass").withStyle(ChatFormatting.GRAY));
    }
}
