package com.isladragoncitos.item;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Montadragones: con clic derecho sobre tu dragon antiguo te subes a su lomo. */
public class DragonRiderItem extends Item {
    public DragonRiderItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.isladragoncitos.rider").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.isladragoncitos.rider.controls").withStyle(ChatFormatting.DARK_GRAY));
    }
}
