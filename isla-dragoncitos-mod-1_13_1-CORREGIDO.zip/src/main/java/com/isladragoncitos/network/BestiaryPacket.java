package com.isladragoncitos.network;

import com.isladragoncitos.client.ClientHooks;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: abre el Bestiario con las especies criadas, las habilidades aprendidas y el progreso. */
public record BestiaryPacket(List<String> species, List<String> abilities, boolean all, int markLevel, int halfPoints) {

    public static void encode(BestiaryPacket packet, FriendlyByteBuf buf) {
        buf.writeBoolean(packet.all());
        buf.writeVarInt(packet.markLevel());
        buf.writeVarInt(Math.max(0, packet.halfPoints()));
        buf.writeVarInt(packet.species().size());
        for (String id : packet.species()) {
            buf.writeUtf(id);
        }
        buf.writeVarInt(packet.abilities().size());
        for (String id : packet.abilities()) {
            buf.writeUtf(id);
        }
    }

    public static BestiaryPacket decode(FriendlyByteBuf buf) {
        boolean all = buf.readBoolean();
        int mark = buf.readVarInt();
        int half = buf.readVarInt();
        List<String> species = new ArrayList<>();
        int n = buf.readVarInt();
        for (int i = 0; i < n; i++) {
            species.add(buf.readUtf());
        }
        List<String> abilities = new ArrayList<>();
        int m = buf.readVarInt();
        for (int i = 0; i < m; i++) {
            abilities.add(buf.readUtf());
        }
        return new BestiaryPacket(species, abilities, all, mark, half);
    }

    public static void handle(BestiaryPacket packet, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientHooks.openBestiary(packet.species(), packet.abilities(), packet.all(), packet.markLevel(), packet.halfPoints())));
        context.get().setPacketHandled(true);
    }
}
