package com.isladragoncitos.network;

import com.isladragoncitos.client.ClientHooks;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: abre el Codice Draconico con las especies descubiertas. */
public record CodexPacket(List<String> discovered, boolean all) {

    public static void encode(CodexPacket packet, FriendlyByteBuf buf) {
        buf.writeBoolean(packet.all());
        buf.writeVarInt(packet.discovered().size());
        for (String id : packet.discovered()) {
            buf.writeUtf(id);
        }
    }

    public static CodexPacket decode(FriendlyByteBuf buf) {
        boolean all = buf.readBoolean();
        int n = buf.readVarInt();
        List<String> list = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            list.add(buf.readUtf());
        }
        return new CodexPacket(list, all);
    }

    public static void handle(CodexPacket packet, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openCodex(packet.discovered(), packet.all())));
        context.get().setPacketHandled(true);
    }
}
