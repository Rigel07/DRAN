package com.isladragoncitos.portal;

import com.isladragoncitos.IslaDragoncitosMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID)
public final class DragonPortalEvents {
    private DragonPortalEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            DragonPortalRegistry.flush(event.getServer());
        }
    }
}
