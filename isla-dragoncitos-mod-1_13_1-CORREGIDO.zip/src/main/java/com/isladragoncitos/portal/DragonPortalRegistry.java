package com.isladragoncitos.portal;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;

/** Red de portales del dragon guardada con el mundo. */
public final class DragonPortalRegistry extends SavedData {
    private static final String ID = "isladragoncitos_portales";
    private static final Set<GlobalPos> PENDING = ConcurrentHashMap.newKeySet();

    private final Set<GlobalPos> portals = new HashSet<>();

    public static DragonPortalRegistry get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(DragonPortalRegistry::load, DragonPortalRegistry::new, ID);
    }

    /** Llamado desde la generacion de estructuras (puede venir de varios hilos). */
    public static void queue(GlobalPos pos) {
        if (pos != null) {
            PENDING.add(pos);
        }
    }

    /** Vuelca los portales generados a los datos del mundo; se ejecuta en el hilo del servidor. */
    public static void flush(MinecraftServer server) {
        if (PENDING.isEmpty()) {
            return;
        }
        DragonPortalRegistry registry = get(server);
        boolean changed = false;
        Iterator<GlobalPos> iterator = PENDING.iterator();
        while (iterator.hasNext()) {
            GlobalPos pos = iterator.next();
            if (registry.portals.add(pos)) {
                changed = true;
            }
            iterator.remove();
        }
        if (changed) {
            registry.setDirty();
        }
    }

    public List<GlobalPos> destinationsFrom(MinecraftServer server, GlobalPos origin, double minDistanceSqr) {
        List<GlobalPos> near = new ArrayList<>();
        List<GlobalPos> far = new ArrayList<>();
        for (GlobalPos portal : this.portals) {
            if (portal.equals(origin) || server.getLevel(portal.dimension()) == null) {
                continue;
            }
            double distance = portal.pos().distSqr(origin.pos());
            if (distance < 48.0D * 48.0D) {
                // otro portal del mismo monumento: no cuenta como destino
                continue;
            }
            if (distance >= minDistanceSqr) {
                far.add(portal);
            } else {
                near.add(portal);
            }
        }
        return far.isEmpty() ? near : far;
    }

    public boolean remove(GlobalPos pos) {
        boolean removed = this.portals.remove(pos);
        if (removed) {
            this.setDirty();
        }
        return removed;
    }

    public int size() {
        return this.portals.size();
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (GlobalPos portal : this.portals) {
            CompoundTag entry = new CompoundTag();
            entry.putString("Dimension", portal.dimension().location().toString());
            entry.putLong("Pos", portal.pos().asLong());
            list.add(entry);
        }
        tag.put("Portals", list);
        return tag;
    }

    public static DragonPortalRegistry load(CompoundTag tag) {
        DragonPortalRegistry registry = new DragonPortalRegistry();
        ListTag list = tag.getList("Portals", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            ResourceLocation id = ResourceLocation.tryParse(entry.getString("Dimension"));
            if (id == null || !entry.contains("Pos")) {
                continue;
            }
            ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, id);
            registry.portals.add(GlobalPos.of(dimension, BlockPos.of(entry.getLong("Pos"))));
        }
        return registry;
    }
}
