package com.isladragoncitos.portal;

import com.isladragoncitos.block.DragonPortalBlock;
import com.isladragoncitos.registry.ModBlocks;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Viaje entre portales del dragon: destino aleatorio, llegada segura y enfriamiento. */
public final class DragonPortalService {
    private static final String COOLDOWN_TAG = "IsladragoncitosPortalCd";
    private static final int COOLDOWN_TICKS = 100;
    private static final double FAR_DISTANCE = 256.0D;

    private DragonPortalService() {}

    public static void tryTravel(ServerPlayer player, ServerLevel level, BlockPos portalPos) {
        if (player.isSpectator() || player.isShiftKeyDown()) {
            return;
        }
        MinecraftServer server = player.server;
        long now = server.overworld().getGameTime();
        CompoundTag data = player.getPersistentData();
        if (now - data.getLong(COOLDOWN_TAG) < COOLDOWN_TICKS) {
            return;
        }
        data.putLong(COOLDOWN_TAG, now);

        if (player.isPassenger()) {
            player.displayClientMessage(Component.translatable("message.isladragoncitos.portal_riding"), true);
            return;
        }

        GlobalPos origin = GlobalPos.of(level.dimension(), portalPos);
        DragonPortalRegistry.queue(origin);
        DragonPortalRegistry registry = DragonPortalRegistry.get(server);
        List<GlobalPos> options = registry.destinationsFrom(server, origin, FAR_DISTANCE * FAR_DISTANCE);
        if (options.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.isladragoncitos.portal_none"), true);
            return;
        }

        for (int attempt = 0; attempt < 5 && !options.isEmpty(); attempt++) {
            GlobalPos destination = options.remove(player.getRandom().nextInt(options.size()));
            if (travelTo(player, level, portalPos, destination)) {
                return;
            }
            registry.remove(destination);
        }
        player.displayClientMessage(Component.translatable("message.isladragoncitos.portal_inactive"), true);
    }

    private static boolean travelTo(ServerPlayer player, ServerLevel source, BlockPos sourcePos, GlobalPos destination) {
        MinecraftServer server = player.server;
        ServerLevel target = server.getLevel(destination.dimension());
        if (target == null) {
            return false;
        }
        BlockPos core = destination.pos();
        target.getChunkAt(core);
        BlockState state = target.getBlockState(core);
        if (!state.is(ModBlocks.DRAGON_PORTAL.get())) {
            return false;
        }
        Direction facing = state.getValue(DragonPortalBlock.FACING);
        Arrival arrival = findArrival(target, core, facing);

        double sx = sourcePos.getX() + 0.5D;
        double sy = sourcePos.getY() + 1.0D;
        double sz = sourcePos.getZ() + 0.5D;
        source.playSound(null, sourcePos, SoundEvents.PORTAL_TRAVEL, SoundSource.BLOCKS, 0.8F, 1.0F);
        source.sendParticles(ParticleTypes.PORTAL, sx, sy, sz, 64, 0.7D, 1.2D, 0.7D, 0.8D);
        source.sendParticles(ParticleTypes.END_ROD, sx, sy, sz, 18, 0.5D, 1.0D, 0.5D, 0.12D);

        double x = arrival.pos().getX() + 0.5D;
        double y = arrival.pos().getY();
        double z = arrival.pos().getZ() + 0.5D;
        player.teleportTo(target, x, y, z, arrival.facing().toYRot(), 0.0F);
        player.fallDistance = 0.0F;
        player.setDeltaMovement(Vec3.ZERO);

        target.playSound(null, arrival.pos(), SoundEvents.PORTAL_TRAVEL, SoundSource.BLOCKS, 0.7F, 1.15F);
        target.sendParticles(ParticleTypes.PORTAL, x, y + 1.0D, z, 48, 0.5D, 1.0D, 0.5D, 0.6D);
        target.sendParticles(ParticleTypes.END_ROD, x, y + 1.0D, z, 12, 0.35D, 0.8D, 0.35D, 0.08D);
        player.displayClientMessage(Component.translatable("message.isladragoncitos.portal_travel"), true);
        return true;
    }

    private static Arrival findArrival(ServerLevel level, BlockPos core, Direction facing) {
        for (Direction view : new Direction[]{facing, facing.getOpposite()}) {
            for (int distance = 1; distance <= 3; distance++) {
                BlockPos base = core.relative(view, distance);
                for (int dy : new int[]{0, 1, 2, -1, 3}) {
                    BlockPos candidate = base.above(dy);
                    if (canStand(level, candidate)) {
                        return new Arrival(candidate, view);
                    }
                }
            }
        }
        return new Arrival(core, facing);
    }

    private static boolean canStand(ServerLevel level, BlockPos pos) {
        BlockState feet = level.getBlockState(pos);
        if (!feet.getCollisionShape(level, pos).isEmpty() || !feet.getFluidState().isEmpty()) {
            return false;
        }
        BlockPos headPos = pos.above();
        BlockState head = level.getBlockState(headPos);
        if (!head.getCollisionShape(level, headPos).isEmpty() || !head.getFluidState().isEmpty()) {
            return false;
        }
        BlockPos floorPos = pos.below();
        BlockState floor = level.getBlockState(floorPos);
        return !floor.getCollisionShape(level, floorPos).isEmpty() && floor.getFluidState().isEmpty();
    }

    private record Arrival(BlockPos pos, Direction facing) {}
}
