package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.worldgen.AncientEggFeature;
import com.isladragoncitos.worldgen.WaterEggFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(ForgeRegistries.FEATURES, IslaDragoncitosMod.MODID);

    public static final RegistryObject<Feature<NoneFeatureConfiguration>> ANCIENT_EGG = FEATURES.register("ancient_egg",
            () -> new AncientEggFeature(NoneFeatureConfiguration.CODEC));

    public static final RegistryObject<Feature<NoneFeatureConfiguration>> WATER_EGG = FEATURES.register("water_egg",
            () -> new WaterEggFeature(NoneFeatureConfiguration.CODEC));

    private ModFeatures() {}
}
