package com.isladragoncitos.system;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Bono del set dracónico: resistencia, caída lenta y un aura de escamas mientras se lleve completo. */
@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID)
public final class DraconicArmorEvents {
    private DraconicArmorEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) {
            return;
        }
        if (!hasFullSet(player) || player.tickCount % 20 != 0) {
            return;
        }
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 0, true, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 60, 0, true, false, true));
        DraconicData.grant(player, "draconic_armor");
        if (player.tickCount % 100 == 0) {
            player.serverLevel().sendParticles(ParticleTypes.END_ROD,
                    player.getX(), player.getY() + 1.0D, player.getZ(), 6, 0.6D, 0.9D, 0.6D, 0.03D);
        }
    }

    private static boolean hasFullSet(ServerPlayer player) {
        return isPiece(player, EquipmentSlot.HEAD, ModItems.DRACONIC_HELMET.get())
                && isPiece(player, EquipmentSlot.CHEST, ModItems.DRACONIC_CHESTPLATE.get())
                && isPiece(player, EquipmentSlot.LEGS, ModItems.DRACONIC_LEGGINGS.get())
                && isPiece(player, EquipmentSlot.FEET, ModItems.DRACONIC_BOOTS.get());
    }

    private static boolean isPiece(ServerPlayer player, EquipmentSlot slot, net.minecraft.world.item.Item item) {
        ItemStack stack = player.getItemBySlot(slot);
        return !stack.isEmpty() && stack.is(item);
    }
}
