package com.isladragoncitos.system;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.entity.species.DragonSpecies;
import com.isladragoncitos.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** De vez en cuando un dragon ancestral salvaje aparece volando cerca de un jugador. */
@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID)
public final class WildDragonSightings {
    private static final int CHECK_INTERVAL = 400;
    private static final int SIGHTING_CHANCE = 30;
    private static final double LOCAL_RADIUS = 224.0D;

    private WildDragonSightings() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) {
            return;
        }
        if (player.tickCount % CHECK_INTERVAL != 0 || player.isSpectator()) {
            return;
        }
        ServerLevel level = player.serverLevel();
        if (level.dimension() != Level.OVERWORLD) {
            return;
        }
        if (player.getRandom().nextInt(SIGHTING_CHANCE) != 0) {
            return;
        }
        if (!level.getEntitiesOfClass(AncientDragonEntity.class, player.getBoundingBox().inflate(LOCAL_RADIUS),
                AncientDragonEntity::isWild).isEmpty()) {
            return;
        }
        var random = player.getRandom();
        double angle = random.nextDouble() * Math.PI * 2.0D;
        double distance = 64.0D + random.nextDouble() * 48.0D;
        BlockPos base = player.blockPosition().offset((int) Math.round(Math.cos(angle) * distance), 0,
                (int) Math.round(Math.sin(angle) * distance));
        level.getChunkAt(base);
        int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, base.getX(), base.getZ());
        int y = Math.min(level.getMaxBuildHeight() - 16, ground + 20 + random.nextInt(20));
        if (y <= level.getMinBuildHeight() + 10) {
            return;
        }
        AncientDragonEntity dragon = ModEntities.ANCIENT_DRAGON.get().create(level);
        if (dragon == null) {
            return;
        }
        int type = random.nextInt(100) < 70 ? AncientDragonEntity.TYPE_ELDER : random.nextInt(10);
        String species = DragonSpecies.roll(type, new java.util.Random(random.nextLong()));
        dragon.moveTo(base.getX() + 0.5D, y, base.getZ() + 0.5D, random.nextFloat() * 360.0F, 0.0F);
        dragon.makeWild(type, species, 1200 + random.nextInt(1400), 30 + random.nextInt(50), 120 + random.nextInt(180));
        level.addFreshEntity(dragon);
        level.playSound(null, dragon.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 2.0F, 0.8F);
        Component message = Component.translatable("message.isladragoncitos.wild_dragon");
        for (ServerPlayer nearby : level.players()) {
            if (nearby.distanceToSqr(player) < 256.0D * 256.0D) {
                nearby.displayClientMessage(message, false);
            }
        }
    }
}
