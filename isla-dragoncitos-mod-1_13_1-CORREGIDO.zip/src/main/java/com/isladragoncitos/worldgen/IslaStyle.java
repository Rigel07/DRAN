package com.isladragoncitos.worldgen;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Paleta y reglas de cada tipo de isla. El estilo se guarda con la estructura, asi que
 * cada isla conserva su aspecto para siempre.
 */
public final class IslaStyle {
    public static final int PRIMAVERA = 0;
    public static final int NIEVE = 1;
    public static final int VOLCANICA = 2;
    public static final int CRISTAL = 3;
    public static final int JUNGLA = 4;
    public static final int OASIS = 5;
    public static final int COUNT = 6;

    public enum Tree { ROUND, CONE, FUNGUS, SPIRE, TALL, PALM }

    public enum Hang { VINES, COLUMN }

    public enum Flora { MEADOW, SNOW, VOLCANIC, CRYSTAL, JUNGLE, DESERT }

    /** Una especie de arbol: tronco, hojas y altura. */
    public static final class TreeSet {
        public final BlockState log;
        public final BlockState leafA;
        public final BlockState leafB;
        public final int minH;
        public final int varH;
        public final double cut;

        TreeSet(BlockState log, BlockState leafA, BlockState leafB, int minH, int varH, double cut) {
            this.log = log;
            this.leafA = leafA;
            this.leafB = leafB;
            this.minH = minH;
            this.varH = varH;
            this.cut = cut;
        }
    }

    public final int id;
    public final Tree tree;
    public final Hang hang;
    public final Flora flora;

    public BlockState top;
    public BlockState top2;
    public double topPatch = 0.06D;
    public BlockState dirtA;
    public BlockState dirtB;
    public BlockState beach;
    public BlockState[] lakeFloor;
    public BlockState lakeCover;
    public BlockState[] deep;
    public BlockState[] mid;

    public BlockState brick;
    public BlockState mossy;
    public BlockState cracked;
    public BlockState chiseled;
    public BlockState accent;
    public BlockState rubble;
    public BlockState slab;
    public BlockState polished;
    public BlockState carpet;
    public BlockState lantern;
    public double cut1 = 0.58D;
    public double cut2 = 0.84D;

    public TreeSet[] treeSets;
    public double treeChance = 0.5D;

    public BlockState column;
    public BlockState columnTip;
    public BlockState capLeaves;

    /** Color de dragoncito mas comun en este tipo de isla (0 rosa, 1 verde, 2 azul, 3 rojo). */
    public int dragonVariant;

    private static final IslaStyle[] ALL = build();

    private IslaStyle(int id, Tree tree, Hang hang, Flora flora) {
        this.id = id;
        this.tree = tree;
        this.hang = hang;
        this.flora = flora;
    }

    public static IslaStyle get(int id) {
        return ALL[Math.floorMod(id, COUNT)];
    }

    private static BlockState d(Block block) {
        return block.defaultBlockState();
    }

    private static BlockState lv(Block block) {
        return block.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
    }

    private static IslaStyle[] build() {
        IslaStyle[] all = new IslaStyle[COUNT];

        // ---- Primavera: cerezos, robles, azaleas, flores (el estilo clasico)
        IslaStyle s = new IslaStyle(PRIMAVERA, Tree.ROUND, Hang.VINES, Flora.MEADOW);
        s.top = d(Blocks.GRASS_BLOCK);
        s.top2 = d(Blocks.PODZOL);
        s.topPatch = 0.06D;
        s.dirtA = d(Blocks.DIRT);
        s.dirtB = d(Blocks.COARSE_DIRT);
        s.beach = d(Blocks.SAND);
        s.lakeFloor = new BlockState[]{d(Blocks.SAND), d(Blocks.CLAY), d(Blocks.GRAVEL)};
        s.deep = new BlockState[]{d(Blocks.STONE), d(Blocks.ANDESITE), d(Blocks.TUFF), d(Blocks.MOSSY_COBBLESTONE), d(Blocks.CALCITE)};
        s.mid = new BlockState[]{d(Blocks.STONE), d(Blocks.ANDESITE), d(Blocks.TUFF)};
        s.brick = d(Blocks.STONE_BRICKS);
        s.mossy = d(Blocks.MOSSY_STONE_BRICKS);
        s.cracked = d(Blocks.CRACKED_STONE_BRICKS);
        s.chiseled = d(Blocks.CHISELED_STONE_BRICKS);
        s.accent = d(Blocks.AMETHYST_BLOCK);
        s.rubble = d(Blocks.MOSSY_COBBLESTONE);
        s.slab = d(Blocks.STONE_BRICK_SLAB);
        s.polished = d(Blocks.POLISHED_ANDESITE);
        s.carpet = d(Blocks.PINK_CARPET);
        s.lantern = d(Blocks.LANTERN);
        s.treeSets = new TreeSet[]{
                new TreeSet(d(Blocks.CHERRY_LOG), lv(Blocks.CHERRY_LEAVES), lv(Blocks.CHERRY_LEAVES), 4, 2, 0.5D),
                new TreeSet(d(Blocks.OAK_LOG), lv(Blocks.OAK_LEAVES), lv(Blocks.OAK_LEAVES), 4, 3, 0.8D),
                new TreeSet(d(Blocks.OAK_LOG), lv(Blocks.AZALEA_LEAVES), lv(Blocks.FLOWERING_AZALEA_LEAVES), 3, 2, 1.01D)};
        s.treeChance = 0.5D;
        s.capLeaves = lv(Blocks.FLOWERING_AZALEA_LEAVES);
        s.column = d(Blocks.MOSS_BLOCK);
        s.dragonVariant = 0;
        all[PRIMAVERA] = s;

        // ---- Nieve: abetos, hierba nevada, lago helado, carambanos de hielo
        s = new IslaStyle(NIEVE, Tree.CONE, Hang.COLUMN, Flora.SNOW);
        s.top = d(Blocks.GRASS_BLOCK).setValue(BlockStateProperties.SNOWY, true);
        s.top2 = d(Blocks.STONE);
        s.topPatch = 0.05D;
        s.dirtA = d(Blocks.DIRT);
        s.dirtB = d(Blocks.COARSE_DIRT);
        s.beach = d(Blocks.SNOW_BLOCK);
        s.lakeFloor = new BlockState[]{d(Blocks.GRAVEL), d(Blocks.CLAY), d(Blocks.PACKED_ICE)};
        s.lakeCover = d(Blocks.ICE);
        s.deep = new BlockState[]{d(Blocks.STONE), d(Blocks.PACKED_ICE), d(Blocks.TUFF), d(Blocks.BLUE_ICE), d(Blocks.CALCITE)};
        s.mid = new BlockState[]{d(Blocks.STONE), d(Blocks.ANDESITE), d(Blocks.PACKED_ICE)};
        s.brick = d(Blocks.STONE_BRICKS);
        s.mossy = d(Blocks.SNOW_BLOCK);
        s.cracked = d(Blocks.CRACKED_STONE_BRICKS);
        s.chiseled = d(Blocks.CHISELED_STONE_BRICKS);
        s.accent = d(Blocks.BLUE_ICE);
        s.rubble = d(Blocks.COBBLESTONE);
        s.slab = d(Blocks.STONE_BRICK_SLAB);
        s.polished = d(Blocks.POLISHED_ANDESITE);
        s.carpet = d(Blocks.WHITE_CARPET);
        s.lantern = d(Blocks.LANTERN);
        s.treeSets = new TreeSet[]{
                new TreeSet(d(Blocks.SPRUCE_LOG), lv(Blocks.SPRUCE_LEAVES), lv(Blocks.SPRUCE_LEAVES), 5, 4, 1.01D)};
        s.treeChance = 0.55D;
        s.capLeaves = lv(Blocks.SPRUCE_LEAVES);
        s.column = d(Blocks.PACKED_ICE);
        s.dragonVariant = 2;
        all[NIEVE] = s;

        // ---- Volcanica: nylium carmesi, basalto, hongos gigantes, crater de lava
        s = new IslaStyle(VOLCANICA, Tree.FUNGUS, Hang.COLUMN, Flora.VOLCANIC);
        s.top = d(Blocks.CRIMSON_NYLIUM);
        s.top2 = d(Blocks.WARPED_NYLIUM);
        s.topPatch = 0.10D;
        s.dirtA = d(Blocks.NETHERRACK);
        s.dirtB = d(Blocks.BLACKSTONE);
        s.beach = d(Blocks.SMOOTH_BASALT);
        s.lakeFloor = new BlockState[]{d(Blocks.BASALT), d(Blocks.BLACKSTONE), d(Blocks.GRAVEL)};
        s.deep = new BlockState[]{d(Blocks.BLACKSTONE), d(Blocks.BASALT), d(Blocks.DEEPSLATE), d(Blocks.MAGMA_BLOCK), d(Blocks.SMOOTH_BASALT)};
        s.mid = new BlockState[]{d(Blocks.BLACKSTONE), d(Blocks.BASALT), d(Blocks.DEEPSLATE)};
        s.brick = d(Blocks.POLISHED_BLACKSTONE_BRICKS);
        s.mossy = d(Blocks.BLACKSTONE);
        s.cracked = d(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS);
        s.chiseled = d(Blocks.CHISELED_POLISHED_BLACKSTONE);
        s.accent = d(Blocks.CRYING_OBSIDIAN);
        s.rubble = d(Blocks.BLACKSTONE);
        s.slab = d(Blocks.POLISHED_BLACKSTONE_BRICK_SLAB);
        s.polished = d(Blocks.POLISHED_BASALT);
        s.carpet = d(Blocks.RED_CARPET);
        s.lantern = d(Blocks.SOUL_LANTERN);
        s.treeSets = new TreeSet[]{
                new TreeSet(d(Blocks.CRIMSON_STEM), d(Blocks.NETHER_WART_BLOCK), d(Blocks.SHROOMLIGHT), 4, 3, 0.6D),
                new TreeSet(d(Blocks.WARPED_STEM), d(Blocks.WARPED_WART_BLOCK), d(Blocks.SHROOMLIGHT), 4, 3, 1.01D)};
        s.treeChance = 0.38D;
        s.capLeaves = d(Blocks.NETHER_WART_BLOCK);
        s.column = d(Blocks.BASALT);
        s.dragonVariant = 3;
        all[VOLCANICA] = s;

        // ---- Cristal: musgo, calcita, espinas de amatista que brillan
        s = new IslaStyle(CRISTAL, Tree.SPIRE, Hang.COLUMN, Flora.CRYSTAL);
        s.top = d(Blocks.MOSS_BLOCK);
        s.top2 = d(Blocks.CALCITE);
        s.topPatch = 0.12D;
        s.dirtA = d(Blocks.TUFF);
        s.dirtB = d(Blocks.CALCITE);
        s.beach = d(Blocks.CALCITE);
        s.lakeFloor = new BlockState[]{d(Blocks.CALCITE), d(Blocks.AMETHYST_BLOCK), d(Blocks.TUFF)};
        s.deep = new BlockState[]{d(Blocks.DEEPSLATE), d(Blocks.TUFF), d(Blocks.CALCITE), d(Blocks.AMETHYST_BLOCK), d(Blocks.BUDDING_AMETHYST)};
        s.mid = new BlockState[]{d(Blocks.DEEPSLATE), d(Blocks.TUFF), d(Blocks.CALCITE)};
        s.brick = d(Blocks.DEEPSLATE_BRICKS);
        s.mossy = d(Blocks.CALCITE);
        s.cracked = d(Blocks.CRACKED_DEEPSLATE_BRICKS);
        s.chiseled = d(Blocks.CHISELED_DEEPSLATE);
        s.accent = d(Blocks.AMETHYST_BLOCK);
        s.rubble = d(Blocks.COBBLED_DEEPSLATE);
        s.slab = d(Blocks.DEEPSLATE_BRICK_SLAB);
        s.polished = d(Blocks.POLISHED_DEEPSLATE);
        s.carpet = d(Blocks.PURPLE_CARPET);
        s.lantern = d(Blocks.LANTERN);
        s.treeSets = new TreeSet[]{
                new TreeSet(d(Blocks.AMETHYST_BLOCK), d(Blocks.AMETHYST_CLUSTER), d(Blocks.CALCITE), 5, 5, 1.01D)};
        s.treeChance = 0.45D;
        s.capLeaves = d(Blocks.MOSS_BLOCK);
        s.column = d(Blocks.AMETHYST_BLOCK);
        s.columnTip = d(Blocks.AMETHYST_CLUSTER).setValue(BlockStateProperties.FACING, Direction.DOWN);
        s.dragonVariant = 0;
        all[CRISTAL] = s;

        // ---- Jungla: arboles altos, helechos, orquideas, mucho musgo
        s = new IslaStyle(JUNGLA, Tree.TALL, Hang.VINES, Flora.JUNGLE);
        s.top = d(Blocks.GRASS_BLOCK);
        s.top2 = d(Blocks.MOSS_BLOCK);
        s.topPatch = 0.14D;
        s.dirtA = d(Blocks.DIRT);
        s.dirtB = d(Blocks.ROOTED_DIRT);
        s.beach = d(Blocks.MUD);
        s.lakeFloor = new BlockState[]{d(Blocks.MUD), d(Blocks.CLAY), d(Blocks.SAND)};
        s.deep = new BlockState[]{d(Blocks.STONE), d(Blocks.MOSSY_COBBLESTONE), d(Blocks.ANDESITE), d(Blocks.MOSS_BLOCK), d(Blocks.CLAY)};
        s.mid = new BlockState[]{d(Blocks.STONE), d(Blocks.MOSSY_COBBLESTONE), d(Blocks.ANDESITE)};
        s.brick = d(Blocks.STONE_BRICKS);
        s.mossy = d(Blocks.MOSSY_STONE_BRICKS);
        s.cracked = d(Blocks.CRACKED_STONE_BRICKS);
        s.chiseled = d(Blocks.CHISELED_STONE_BRICKS);
        s.accent = d(Blocks.MOSS_BLOCK);
        s.rubble = d(Blocks.MOSSY_COBBLESTONE);
        s.slab = d(Blocks.STONE_BRICK_SLAB);
        s.polished = d(Blocks.POLISHED_ANDESITE);
        s.carpet = d(Blocks.MOSS_CARPET);
        s.lantern = d(Blocks.LANTERN);
        s.cut1 = 0.25D;
        s.cut2 = 0.80D;
        s.treeSets = new TreeSet[]{
                new TreeSet(d(Blocks.JUNGLE_LOG), lv(Blocks.JUNGLE_LEAVES), lv(Blocks.JUNGLE_LEAVES), 7, 5, 0.7D),
                new TreeSet(d(Blocks.JUNGLE_LOG), lv(Blocks.JUNGLE_LEAVES), lv(Blocks.OAK_LEAVES), 4, 3, 1.01D)};
        s.treeChance = 0.75D;
        s.capLeaves = lv(Blocks.JUNGLE_LEAVES);
        s.column = d(Blocks.MOSS_BLOCK);
        s.dragonVariant = 1;
        all[JUNGLA] = s;

        // ---- Oasis: arena, palmeras, cactus, ruinas de arenisca
        s = new IslaStyle(OASIS, Tree.PALM, Hang.COLUMN, Flora.DESERT);
        s.top = d(Blocks.SAND);
        s.top2 = d(Blocks.RED_SAND);
        s.topPatch = 0.15D;
        s.dirtA = d(Blocks.SANDSTONE);
        s.dirtB = d(Blocks.RED_SANDSTONE);
        s.beach = d(Blocks.SAND);
        s.lakeFloor = new BlockState[]{d(Blocks.SAND), d(Blocks.CLAY), d(Blocks.SAND)};
        s.deep = new BlockState[]{d(Blocks.SANDSTONE), d(Blocks.RED_SANDSTONE), d(Blocks.TERRACOTTA), d(Blocks.ORANGE_TERRACOTTA), d(Blocks.CUT_SANDSTONE)};
        s.mid = new BlockState[]{d(Blocks.SANDSTONE), d(Blocks.SANDSTONE), d(Blocks.TERRACOTTA)};
        s.brick = d(Blocks.CUT_SANDSTONE);
        s.mossy = d(Blocks.SANDSTONE);
        s.cracked = d(Blocks.RED_SANDSTONE);
        s.chiseled = d(Blocks.CHISELED_SANDSTONE);
        s.accent = d(Blocks.TERRACOTTA);
        s.rubble = d(Blocks.SANDSTONE);
        s.slab = d(Blocks.CUT_SANDSTONE_SLAB);
        s.polished = d(Blocks.SMOOTH_SANDSTONE);
        s.carpet = d(Blocks.ORANGE_CARPET);
        s.lantern = d(Blocks.LANTERN);
        s.treeSets = new TreeSet[]{
                new TreeSet(d(Blocks.STRIPPED_JUNGLE_LOG), lv(Blocks.JUNGLE_LEAVES), lv(Blocks.JUNGLE_LEAVES), 5, 4, 1.01D)};
        s.treeChance = 0.22D;
        s.capLeaves = lv(Blocks.JUNGLE_LEAVES);
        s.column = d(Blocks.SANDSTONE);
        s.dragonVariant = 3;
        all[OASIS] = s;

        return all;
    }
}
