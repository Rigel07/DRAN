package com.isladragoncitos.worldgen;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.registry.ModBlocks;
import com.isladragoncitos.registry.ModStructures;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/** Pieza de las ruinas de los Jinetes del Alba. Cada tipo cuenta un trozo de la historia desaparecida. */
public class RiderRuinPiece extends StructurePiece {
    public static final int WATCH = 0;
    public static final int GRAVEYARD = 1;
    public static final int CIRCLE = 2;
    public static final int SEA = 3;

    private static final ResourceLocation LOOT = new ResourceLocation(IslaDragoncitosMod.MODID, "chests/jinete_ruinas");
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState BONE = Blocks.BONE_BLOCK.defaultBlockState();

    private int kind;
    private int cx;
    private int y0;
    private int cz;
    private int rot;
    private long seed;

    public RiderRuinPiece(int kind, int cx, int y0, int cz, long seed, int rot) {
        super(ModStructures.RUIN_PIECE.get(), 0, boxFor(kind, cx, y0, cz));
        this.kind = kind;
        this.cx = cx;
        this.y0 = y0;
        this.cz = cz;
        this.seed = seed;
        this.rot = rot;
    }

    public RiderRuinPiece(CompoundTag tag) {
        super(ModStructures.RUIN_PIECE.get(), tag);
        this.kind = tag.getInt("Kind");
        this.cx = tag.getInt("Cx");
        this.y0 = tag.getInt("Y0");
        this.cz = tag.getInt("Cz");
        this.seed = tag.getLong("Seed");
        this.rot = tag.getInt("Rot");
    }

    private static BoundingBox boxFor(int kind, int cx, int y0, int cz) {
        int m = kind == GRAVEYARD ? 38 : 14;
        int down = kind == GRAVEYARD ? 14 : 8;
        int up = kind == GRAVEYARD ? 22 : 24;
        return new BoundingBox(cx - m, y0 - down, cz - m, cx + m, y0 + up, cz + m);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("Kind", this.kind);
        tag.putInt("Cx", this.cx);
        tag.putInt("Y0", this.y0);
        tag.putInt("Cz", this.cz);
        tag.putLong("Seed", this.seed);
        tag.putInt("Rot", this.rot);
    }

    // ------------------------------------------------------------------ utilidades

    private int wx(int u, int v) {
        switch (this.rot & 3) {
            case 0:
                return this.cx + u;
            case 1:
                return this.cx - v;
            case 2:
                return this.cx - u;
            default:
                return this.cx + v;
        }
    }

    private int wz(int u, int v) {
        switch (this.rot & 3) {
            case 0:
                return this.cz + v;
            case 1:
                return this.cz + u;
            case 2:
                return this.cz - v;
            default:
                return this.cz - u;
        }
    }

    private Direction fwd() {
        return new Direction[]{Direction.EAST, Direction.SOUTH, Direction.WEST, Direction.NORTH}[this.rot & 3];
    }

    private double rnd(int a, int b, int c) {
        long h = this.seed ^ ((long) a * 0x9E3779B97F4A7C15L) ^ ((long) b * 0xC2B2AE3D27D4EB4FL) ^ ((long) c * 0x165667B19E3779F9L);
        h ^= (h >>> 33);
        h *= 0xFF51AFD7ED558CCDL;
        h ^= (h >>> 33);
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= (h >>> 33);
        return (h >>> 11) * (1.0D / (double) (1L << 53));
    }

    private int chapter() {
        return (int) (this.rnd(7, 7, 7) * RiderLore.chapters());
    }

    private void set(WorldGenLevel level, BoundingBox box, int u, int y, int v, BlockState state) {
        BlockPos pos = new BlockPos(this.wx(u, v), y, this.wz(u, v));
        if (box.isInside(pos)) {
            level.setBlock(pos, state, 2);
        }
    }

    /** Pone el bloque y lo prolonga hacia abajo hasta tocar el suelo, para que nada flote. */
    private void setDown(WorldGenLevel level, BoundingBox box, int u, int y, int v, BlockState state, int depth) {
        for (int i = 0; i <= depth; i++) {
            BlockPos pos = new BlockPos(this.wx(u, v), y - i, this.wz(u, v));
            if (!box.isInside(pos)) {
                continue;
            }
            BlockState current = level.getBlockState(pos);
            if (i > 0 && !(current.isAir() || current.canBeReplaced())) {
                break;
            }
            level.setBlock(pos, state, 2);
        }
    }

    private void line(WorldGenLevel level, BoundingBox box, int u0, int y0, int v0, int u1, int y1, int v1, BlockState state) {
        int n = Math.max(Math.abs(u1 - u0), Math.max(Math.abs(y1 - y0), Math.abs(v1 - v0)));
        for (int i = 0; i <= n; i++) {
            double t = n == 0 ? 0.0D : (double) i / n;
            if (this.rnd(u0 + i, y0, v0 + i) < 0.06D) {
                continue;
            }
            this.set(level, box, (int) Math.round(u0 + (u1 - u0) * t), (int) Math.round(y0 + (y1 - y0) * t),
                    (int) Math.round(v0 + (v1 - v0) * t), state);
        }
    }

    private BlockState brick(int a, int b, int c) {
        double r = this.rnd(a, b, c);
        if (r < 0.5D) {
            return Blocks.STONE_BRICKS.defaultBlockState();
        }
        return r < 0.8D ? Blocks.MOSSY_STONE_BRICKS.defaultBlockState() : Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
    }

    private BlockState chest(boolean wet) {
        BlockState state = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, this.fwd());
        return wet ? state.setValue(ChestBlock.WATERLOGGED, true) : state;
    }

    private void lectern(WorldGenLevel level, BoundingBox box, int u, int y, int v) {
        RiderLore.placeLectern(level, box, new BlockPos(this.wx(u, v), y, this.wz(u, v)), this.fwd(), this.chapter());
    }

    private void chestAt(WorldGenLevel level, BoundingBox box, RandomSource random, int u, int y, int v, boolean wet) {
        BlockPos pos = new BlockPos(this.wx(u, v), y, this.wz(u, v));
        this.createChest(level, box, random, pos, LOOT, this.chest(wet));
    }

    // ------------------------------------------------------------------ generacion

    @Override
    public void postProcess(WorldGenLevel level, StructureManager manager, ChunkGenerator generator, RandomSource random,
                            BoundingBox box, ChunkPos chunkPos, BlockPos pivot) {
        switch (this.kind) {
            case WATCH -> this.buildWatch(level, box, random);
            case GRAVEYARD -> this.buildGraveyard(level, box, random);
            case CIRCLE -> this.buildCircle(level, box, random);
            default -> this.buildSea(level, box, random);
        }
    }

    /** Atalaya del jinete: torre en ruinas con cofre abajo y un atril con la cronica arriba. */
    private void buildWatch(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int top = this.y0;
        int height = 10 + (int) (this.rnd(1, 1, 1) * 5.0D);
        for (int u = -5; u <= 5; u++) {
            for (int v = -5; v <= 5; v++) {
                if (Math.max(Math.abs(u), Math.abs(v)) == 5 && this.rnd(u, 2, v) < 0.35D) {
                    continue;
                }
                this.setDown(level, box, u, top - 1, v, this.brick(u, 3, v), 5);
            }
        }
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, this.fwd());
        for (int u = -2; u <= 2; u++) {
            for (int v = -2; v <= 2; v++) {
                boolean wall = Math.max(Math.abs(u), Math.abs(v)) == 2;
                boolean corner = Math.abs(u) == 2 && Math.abs(v) == 2;
                if (wall) {
                    int wallH = corner ? height : height - (int) (this.rnd(u, 4, v) * 4.0D);
                    for (int k = 1; k <= wallH; k++) {
                        boolean door = u == 2 && v == 0 && k <= 2;
                        boolean window = !corner && (u == 0 || v == 0) && u != 2 && (k == 4 || k == 5 || k == 8);
                        if (door || window) {
                            this.set(level, box, u, top + k, v, AIR);
                        } else {
                            this.set(level, box, u, top + k, v, corner && k == 1
                                    ? Blocks.CHISELED_STONE_BRICKS.defaultBlockState() : this.brick(u, 5 + k, v));
                        }
                    }
                } else {
                    for (int k = 1; k <= height; k++) {
                        this.set(level, box, u, top + k, v, AIR);
                    }
                    if (u == -1 && v == 0) {
                        for (int k = 1; k <= 5; k++) {
                            this.set(level, box, u, top + k, v, ladder);
                        }
                    } else {
                        this.set(level, box, u, top + 5, v, this.brick(u, 40, v));
                    }
                }
            }
        }
        this.set(level, box, 2, top + 3, 0, Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
        this.chestAt(level, box, random, -1, top + 1, 1, false);
        this.set(level, box, 1, top + 1, -1, Blocks.LANTERN.defaultBlockState());
        this.lectern(level, box, -1, top + 6, -1);
    }

    /** Cementerio de dragones: el esqueleto colosal de un dragon, con el campamento de su jinete. */
    private void buildGraveyard(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int y = this.y0;
        // columna y cola
        for (int u = -16; u <= 10; u++) {
            int sy = y + 5 + (int) Math.round(1.5D * Math.sin(u * 0.2D));
            if (this.rnd(u, 5, 0) < 0.06D) {
                continue;
            }
            this.set(level, box, u, sy, 0, BONE);
            if (u % 2 == 0) {
                this.set(level, box, u, sy + 1, 0, BONE);
            }
            if (u % 3 == 0) {
                this.setDown(level, box, u, sy - 1, 0, BONE, 14);
            }
        }
        for (int u = -17; u >= -34; u--) {
            int ty = y + 4 - (Math.abs(u) - 16) / 6;
            if (this.rnd(u, 6, 0) < 0.08D) {
                continue;
            }
            this.set(level, box, u, ty, 0, BONE);
            if (u % 2 == 0) {
                this.set(level, box, u, ty + 1, 0, BONE);
            }
        }
        // costillas
        int[] ribs = {-12, -9, -6, -3, 0, 3};
        for (int u : ribs) {
            double radius = Math.max(2.0D, 5.0D - Math.abs(u + 4) / 4.0D);
            int spineY = y + 5 + (int) Math.round(1.5D * Math.sin(u * 0.2D));
            for (double a = 0.0D; a <= 2.7D; a += 0.15D) {
                int v = (int) Math.round(radius * Math.sin(a));
                int ry = spineY - (int) Math.round(radius * 0.9D * (1.0D - Math.cos(a)));
                if (ry < y - 1) {
                    break;
                }
                for (int side = -1; side <= 1; side += 2) {
                    if (this.rnd(u, (int) (a * 10), side) > 0.07D) {
                        this.set(level, box, u, ry, side * v, BONE);
                    }
                }
            }
        }
        // craneo
        for (int u = 11; u <= 17; u++) {
            for (int v = -2; v <= 2; v++) {
                for (int k = 3; k <= 7; k++) {
                    boolean shell = u == 11 || u == 17 || Math.abs(v) == 2 || k == 3 || k == 7;
                    this.set(level, box, u, y + k, v, shell ? BONE : AIR);
                }
            }
        }
        for (int s = -1; s <= 1; s += 2) {
            this.set(level, box, 17, y + 6, s, AIR);
            this.set(level, box, 17, y + 5, s * 2, AIR);
        }
        for (int u = 13; u <= 18; u++) {
            for (int v = -1; v <= 1; v++) {
                this.set(level, box, u, y + 2, v, BONE);
            }
            this.set(level, box, u, y + 3, -1, u % 2 == 0 ? Blocks.QUARTZ_BLOCK.defaultBlockState() : BONE);
            this.set(level, box, u, y + 3, 1, u % 2 == 0 ? Blocks.QUARTZ_BLOCK.defaultBlockState() : BONE);
        }
        this.setDown(level, box, 12, y + 1, 0, BONE, 12);
        this.setDown(level, box, 16, y + 1, 0, BONE, 12);
        for (int k = 0; k <= 4; k++) {
            for (int s = -1; s <= 1; s += 2) {
                this.set(level, box, 11 - k, y + 8 + k, s * (2 + k / 2), BONE);
            }
        }
        // alas
        for (int s = -1; s <= 1; s += 2) {
            this.line(level, box, -6, y + 6, s, -6, y + 9, s * 8, BONE);
            this.line(level, box, -6, y + 9, s * 8, -8, y + 7, s * 16, BONE);
            this.line(level, box, -8, y + 7, s * 16, -14, y + 2, s * 13, BONE);
            this.line(level, box, -8, y + 7, s * 16, -16, y + 1, s * 17, BONE);
            this.line(level, box, -8, y + 7, s * 16, -12, y + 3, s * 20, BONE);
        }
        // campamento del jinete
        for (int u = -7; u <= -2; u++) {
            for (int v = 10; v <= 15; v++) {
                if (this.rnd(u, 9, v) < 0.8D) {
                    this.setDown(level, box, u, y - 1, v, Blocks.MOSSY_COBBLESTONE.defaultBlockState(), 4);
                }
            }
        }
        this.set(level, box, -4, y, 12, Blocks.CAMPFIRE.defaultBlockState().setValue(CampfireBlock.LIT, false));
        this.set(level, box, -6, y, 11, Blocks.SKELETON_SKULL.defaultBlockState());
        this.set(level, box, -3, y, 14, Blocks.COBWEB.defaultBlockState());
        this.chestAt(level, box, random, -2, y, 11, false);
        this.lectern(level, box, -6, y, 14);
        this.set(level, box, -2, y, 14, Blocks.LANTERN.defaultBlockState());
    }

    /** Circulo del Alba: ocho piedras, cuatro ofrendas de escamas y un cofre escondido bajo el altar. */
    private void buildCircle(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int y = this.y0;
        for (int u = -8; u <= 8; u++) {
            for (int v = -8; v <= 8; v++) {
                double d = Math.sqrt(u * u + v * v);
                if (d >= 4.5D && d <= 6.3D && this.rnd(u, 10, v) < 0.6D) {
                    this.set(level, box, u, y - 1, v, this.rnd(u, 11, v) < 0.5D
                            ? Blocks.MOSSY_COBBLESTONE.defaultBlockState() : Blocks.GRAVEL.defaultBlockState());
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0D + Math.PI / 8.0D;
            int u = (int) Math.round(Math.cos(a) * 8.0D);
            int v = (int) Math.round(Math.sin(a) * 8.0D);
            int h = 3 + (int) (this.rnd(i, 12, 0) * 3.0D);
            this.setDown(level, box, u, y, v, this.brick(u, 13, v), 4);
            for (int k = 1; k <= h; k++) {
                this.set(level, box, u, y + k, v, this.brick(u, 14 + k, v));
            }
            if (this.rnd(i, 15, 0) < 0.8D) {
                this.set(level, box, u, y + h + 1, v, Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
            }
        }
        // altar central
        for (int u = -1; u <= 1; u++) {
            for (int v = -1; v <= 1; v++) {
                this.setDown(level, box, u, y, v, Blocks.POLISHED_ANDESITE.defaultBlockState(), 3);
            }
        }
        this.set(level, box, 0, y + 1, 0, Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
        this.lectern(level, box, 0, y + 2, 0);
        // ofrendas: una escama de cada color en un pedestal
        BlockState[] offerings = {ModBlocks.PINK_SCALE_BLOCK.get().defaultBlockState(), ModBlocks.GREEN_SCALE_BLOCK.get().defaultBlockState(),
                ModBlocks.BLUE_SCALE_BLOCK.get().defaultBlockState(), ModBlocks.RED_SCALE_BLOCK.get().defaultBlockState()};
        int[][] spots = {{4, 0}, {0, 4}, {-4, 0}, {0, -4}};
        for (int i = 0; i < 4; i++) {
            this.setDown(level, box, spots[i][0], y, spots[i][1], Blocks.CHISELED_STONE_BRICKS.defaultBlockState(), 3);
            this.set(level, box, spots[i][0], y + 1, spots[i][1], Blocks.STONE_BRICK_WALL.defaultBlockState());
            this.set(level, box, spots[i][0], y + 2, spots[i][1], offerings[i]);
        }
        // cofre escondido bajo el altar
        for (int u = -1; u <= 1; u++) {
            for (int v = -1; v <= 1; v++) {
                this.set(level, box, u, y - 3, v, Blocks.STONE_BRICKS.defaultBlockState());
                this.set(level, box, u, y - 4, v, Blocks.STONE_BRICKS.defaultBlockState());
            }
        }
        this.set(level, box, 0, y - 2, 0, Blocks.CRACKED_STONE_BRICKS.defaultBlockState());
        this.chestAt(level, box, random, 0, y - 3, 0, false);
    }

    /** Pilar de las profundidades: ruinas de prismarina en el fondo del oceano, con un cofre y un atril. */
    private void buildSea(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int y = this.y0;
        BlockState prism = Blocks.PRISMARINE_BRICKS.defaultBlockState();
        BlockState dark = Blocks.DARK_PRISMARINE.defaultBlockState();
        BlockState lantern = Blocks.SEA_LANTERN.defaultBlockState();
        for (int u = -5; u <= 5; u++) {
            for (int v = -5; v <= 5; v++) {
                if (Math.max(Math.abs(u), Math.abs(v)) == 5 && this.rnd(u, 20, v) < 0.4D) {
                    continue;
                }
                this.set(level, box, u, y - 1, v, this.rnd(u, 21, v) < 0.7D ? prism : dark);
            }
        }
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3.0D;
            int u = (int) Math.round(Math.cos(a) * 4.0D);
            int v = (int) Math.round(Math.sin(a) * 4.0D);
            int h = 5 + (int) (this.rnd(i, 22, 0) * 4.0D);
            for (int k = 0; k < h; k++) {
                this.set(level, box, u, y + k, v, this.rnd(u, 23 + k, v) < 0.6D ? prism : dark);
            }
            this.set(level, box, u, y + h, v, this.rnd(i, 24, 0) < 0.7D ? lantern : dark);
        }
        this.set(level, box, 0, y, 0, prism);
        this.set(level, box, 0, y + 1, 0, Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
        this.lectern(level, box, 0, y + 2, 0);
        this.chestAt(level, box, random, 0, y, 2, true);
        this.set(level, box, 2, y, -1, lantern);
    }
}
