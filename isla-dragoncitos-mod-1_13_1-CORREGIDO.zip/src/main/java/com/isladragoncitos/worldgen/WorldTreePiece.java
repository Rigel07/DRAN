package com.isladragoncitos.worldgen;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.block.WorldTreeLeavesBlock;
import com.isladragoncitos.entity.ElfEntity;
import com.isladragoncitos.registry.ModBlocks;
import com.isladragoncitos.registry.ModEntities;
import com.isladragoncitos.registry.ModStructures;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/**
 * Yggdrasil, el Gran Arbol del Mundo. Un tronco hueco de 250 bloques con escalera de caracol, raices colosales,
 * una copa dorada de 240 bloques de ancho, ramas gigantes, y los reinos de la imagen: la camara de Helheim bajo
 * las raices, la meseta de Midgard, la ciudad elfica de Alfheim y el palacio de Asgard en la cima.
 */
public class WorldTreePiece extends StructurePiece {
    public static final int RADIUS = 124;
    public static final int TOP = 250;
    private static final int DEPTH = 40;

    // alturas relativas a la base del arbol
    private static final int HEL_FLOOR = -33;
    private static final int MIDGARD = 64;
    private static final int ALFHEIM = 127;
    private static final int ASGARD = 206;
    private static final int KEEP_TOP = 240;
    private static final int STAIR_TOP = 238;

    private static final ResourceLocation LOOT_TREASURE = new ResourceLocation(IslaDragoncitosMod.MODID, "chests/world_tree_treasure");
    private static final ResourceLocation LOOT_HEL = new ResourceLocation(IslaDragoncitosMod.MODID, "chests/world_tree_hel");
    private static final ResourceLocation LOOT_HOME = new ResourceLocation(IslaDragoncitosMod.MODID, "chests/elf_home");

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    private int cx;
    private int y0;
    private int cz;
    private long seed;
    private double ph1;
    private double ph2;
    private double ph3;

    public WorldTreePiece(int cx, int y0, int cz, long seed) {
        super(ModStructures.WORLD_TREE_PIECE.get(), 0,
                new BoundingBox(cx - RADIUS, y0 - DEPTH, cz - RADIUS, cx + RADIUS, y0 + TOP, cz + RADIUS));
        this.cx = cx;
        this.y0 = y0;
        this.cz = cz;
        this.seed = seed;
        this.initPhases();
    }

    public WorldTreePiece(CompoundTag tag) {
        super(ModStructures.WORLD_TREE_PIECE.get(), tag);
        this.cx = tag.getInt("Cx");
        this.y0 = tag.getInt("Y0");
        this.cz = tag.getInt("Cz");
        this.seed = tag.getLong("Seed");
        this.initPhases();
    }

    private void initPhases() {
        this.ph1 = this.rnd(1, 2, 3) * 6.2831853D;
        this.ph2 = this.rnd(4, 5, 6) * 6.2831853D;
        this.ph3 = this.rnd(7, 8, 9) * 6.2831853D;
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("Cx", this.cx);
        tag.putInt("Y0", this.y0);
        tag.putInt("Cz", this.cz);
        tag.putLong("Seed", this.seed);
    }

    // ------------------------------------------------------------------ utilidades

    /** Contexto de un chunk concreto: limites de escritura y acceso al nivel. */
    private static final class Ctx {
        final WorldGenLevel level;
        final BoundingBox chunkBox;
        final RandomSource random;
        final int minX;
        final int maxX;
        final int minY;
        final int maxY;
        final int minZ;
        final int maxZ;
        final BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();

        Ctx(WorldGenLevel level, BoundingBox chunk, BoundingBox piece, RandomSource random) {
            this.level = level;
            this.chunkBox = chunk;
            this.random = random;
            this.minX = Math.max(chunk.minX(), piece.minX());
            this.maxX = Math.min(chunk.maxX(), piece.maxX());
            this.minZ = Math.max(chunk.minZ(), piece.minZ());
            this.maxZ = Math.min(chunk.maxZ(), piece.maxZ());
            this.minY = Math.max(Math.max(chunk.minY(), piece.minY()), level.getMinBuildHeight());
            this.maxY = Math.min(Math.min(chunk.maxY(), piece.maxY()), level.getMaxBuildHeight() - 1);
        }

        boolean empty() {
            return this.minX > this.maxX || this.minZ > this.maxZ || this.minY > this.maxY;
        }

        boolean outside(int x0, int z0, int x1, int z1, int ya, int yb) {
            return x1 < this.minX || x0 > this.maxX || z1 < this.minZ || z0 > this.maxZ || yb < this.minY || ya > this.maxY;
        }

        boolean in(int x, int y, int z) {
            return x >= this.minX && x <= this.maxX && y >= this.minY && y <= this.maxY && z >= this.minZ && z <= this.maxZ;
        }

        void set(int x, int y, int z, BlockState state) {
            if (this.in(x, y, z)) {
                this.mut.set(x, y, z);
                this.level.setBlock(this.mut, state, 2);
            }
        }

        BlockState get(int x, int y, int z) {
            this.mut.set(x, y, z);
            return this.level.getBlockState(this.mut);
        }
    }

    private double rnd(int a, int b, int c) {
        long h = this.seed ^ ((long) a * 0x9E3779B97F4A7C15L) ^ ((long) b * 0xC2B2AE3D27D4EB4FL) ^ ((long) c * 0x165667B19E3779F9L);
        h ^= (h >>> 33);
        h *= 0xFF51AFD7ED558CCDL;
        h ^= (h >>> 33);
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= (h >>> 33);
        return (h >>> 11) * (1.0D / (double) (1L << 53));
    }

    private double noise(double u, double v) {
        return (Math.sin(u * 0.083D + this.ph1) + Math.sin(v * 0.091D + this.ph2)
                + Math.sin((u + v) * 0.052D + this.ph3) + Math.sin((u - v) * 0.067D + this.ph1 * 2.0D)) * 0.25D;
    }

    private static double baseRadius(int h) {
        return 12.0D + 17.0D * Math.exp(-Math.max(h, 0) / 80.0D);
    }

    private static double angleDiff(double a, double b) {
        double d = a - b;
        while (d > Math.PI) {
            d -= 2.0D * Math.PI;
        }
        while (d < -Math.PI) {
            d += 2.0D * Math.PI;
        }
        return d;
    }

    private static double stairAngle(int h) {
        return angleDiff((h - 1) / 5.0D, 0.0D);
    }

    private static Direction facingOf(double dx, double dz) {
        if (Math.abs(dx) > Math.abs(dz)) {
            return dx > 0 ? Direction.EAST : Direction.WEST;
        }
        return dz > 0 ? Direction.SOUTH : Direction.NORTH;
    }

    private static int facingIndex(double dx, double dz) {
        if (Math.abs(dx) > Math.abs(dz)) {
            return dx > 0 ? 0 : 2;
        }
        return dz > 0 ? 1 : 3;
    }

    private BlockState bark(int x, int y, int z) {
        double r = this.rnd(x, y, z);
        if (r < 0.60D) {
            return Blocks.DARK_OAK_WOOD.defaultBlockState();
        }
        if (r < 0.82D) {
            return Blocks.OAK_WOOD.defaultBlockState();
        }
        if (r < 0.93D) {
            return Blocks.STRIPPED_DARK_OAK_WOOD.defaultBlockState();
        }
        return Blocks.MOSS_BLOCK.defaultBlockState();
    }

    private static BlockState leaves(boolean fruit) {
        return ModBlocks.WORLD_TREE_LEAVES.get().defaultBlockState().setValue(WorldTreeLeavesBlock.FRUIT, fruit);
    }

    private static BlockState oakLeaves() {
        return Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
    }

    private static BlockState stair(Block block, Direction facing) {
        return block.defaultBlockState().setValue(StairBlock.FACING, facing);
    }

    /** Doors: {height of the floor, angle, half width}. Ground doors have their floor at h = -1. */
    private int doorCount() {
        return 6;
    }

    private double doorAngle(int i) {
        switch (i) {
            case 0:
                return Math.PI / 6.0D;
            case 1:
                return 5.0D * Math.PI / 6.0D;
            case 2:
                return -Math.PI / 2.0D;
            case 3:
                return stairAngle(MIDGARD);
            case 4:
                return stairAngle(ALFHEIM);
            default:
                return stairAngle(ASGARD);
        }
    }

    private int doorFloor(int i) {
        switch (i) {
            case 3:
                return MIDGARD;
            case 4:
                return ALFHEIM;
            case 5:
                return ASGARD;
            default:
                return -1;
        }
    }

    /** 0 = no es puerta, 1 = hueco de puerta (aire), 2 = suelo de la puerta. */
    private int door(int h, double d, double th) {
        for (int i = 0; i < this.doorCount(); i++) {
            int floor = this.doorFloor(i);
            if (h < floor || h > floor + 10) {
                continue;
            }
            double diff = angleDiff(th, this.doorAngle(i));
            if (Math.cos(diff) <= 0.0D) {
                continue;
            }
            boolean ground = i < 3;
            double half = ground ? 3.3D : 2.8D;
            double lat = Math.abs(d * Math.sin(diff));
            if (lat > half) {
                continue;
            }
            if (h == floor) {
                return 2;
            }
            double arch = (ground ? 5.0D : 4.0D) + Math.sqrt(Math.max(0.0D, half * half + 0.4D - lat * lat));
            if (h - floor <= arch) {
                return 1;
            }
        }
        return 0;
    }

    private double[] branchPoint(int i, int k) {
        double phi = i * Math.PI / 4.0D + (this.rnd(i, 1, 1) - 0.5D) * 0.5D;
        int h0 = 142 + (int) (this.rnd(i, 2, 2) * 10.0D);
        double rho0 = baseRadius(h0) - 3.0D;
        double[][] pts = {
                {rho0, h0, 8.5D},
                {rho0 + 30.0D, h0 + 14, 6.5D},
                {rho0 + 58.0D, h0 + 30, 4.8D},
                {rho0 + 86.0D, h0 + 44, 3.0D}};
        double[] p = pts[k];
        return new double[]{this.cx + Math.cos(phi) * p[0], this.y0 + p[1], this.cz + Math.sin(phi) * p[0], p[2], phi};
    }

    // ------------------------------------------------------------------ generacion

    @Override
    public void postProcess(WorldGenLevel level, StructureManager manager, ChunkGenerator generator, RandomSource random,
                            BoundingBox box, ChunkPos chunkPos, BlockPos pivot) {
        Ctx c = new Ctx(level, box, this.boundingBox, random);
        if (c.empty()) {
            return;
        }
        this.canopyPass(c);
        this.branchesPass(c);
        this.rootsPass(c);
        this.midgardPass(c);
        this.alfheimPass(c);
        this.asgardPass(c);
        this.trunkPass(c);
        this.detailsPass(c);
    }

    // ---- formas basicas

    private void sphere(Ctx c, double px, double py, double pz, double r) {
        int x0 = Math.max(c.minX, (int) Math.floor(px - r));
        int x1 = Math.min(c.maxX, (int) Math.ceil(px + r));
        int y0_ = Math.max(c.minY, (int) Math.floor(py - r));
        int y1 = Math.min(c.maxY, (int) Math.ceil(py + r));
        int z0 = Math.max(c.minZ, (int) Math.floor(pz - r));
        int z1 = Math.min(c.maxZ, (int) Math.ceil(pz + r));
        double r2 = r * r;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int y = y0_; y <= y1; y++) {
                    double dx = x - px;
                    double dy = y - py;
                    double dz = z - pz;
                    if (dx * dx + dy * dy + dz * dz <= r2) {
                        c.set(x, y, z, this.bark(x, y, z));
                    }
                }
            }
        }
    }

    private void box(Ctx c, int x0, int ya, int z0, int x1, int yb, int z1, BlockState state) {
        int ax = Math.max(c.minX, Math.min(x0, x1));
        int bx = Math.min(c.maxX, Math.max(x0, x1));
        int ay = Math.max(c.minY, Math.min(ya, yb));
        int by = Math.min(c.maxY, Math.max(ya, yb));
        int az = Math.max(c.minZ, Math.min(z0, z1));
        int bz = Math.min(c.maxZ, Math.max(z0, z1));
        for (int x = ax; x <= bx; x++) {
            for (int z = az; z <= bz; z++) {
                for (int y = ay; y <= by; y++) {
                    c.set(x, y, z, state);
                }
            }
        }
    }

    private void disc(Ctx c, int px, int y, int pz, double r, BlockState state) {
        int rr = (int) Math.ceil(r);
        if (c.outside(px - rr, pz - rr, px + rr, pz + rr, y, y)) {
            return;
        }
        for (int x = Math.max(c.minX, px - rr); x <= Math.min(c.maxX, px + rr); x++) {
            for (int z = Math.max(c.minZ, pz - rr); z <= Math.min(c.maxZ, pz + rr); z++) {
                if ((x - px) * (x - px) + (z - pz) * (z - pz) <= r * r) {
                    c.set(x, y, z, state);
                }
            }
        }
    }

    // ---- copa dorada

    private void canopyPass(Ctx c) {
        if (c.outside(this.cx - 122, this.cz - 122, this.cx + 122, this.cz + 122, this.y0 + 120, this.y0 + 215)) {
            return;
        }
        for (int x = c.minX; x <= c.maxX; x++) {
            for (int z = c.minZ; z <= c.maxZ; z++) {
                int u = x - this.cx;
                int v = z - this.cz;
                double d = Math.sqrt((double) (u * u + v * v));
                double th = Math.atan2(v, u);
                double edge = 114.0D + 6.0D * Math.sin(th * 5.0D + this.ph1) + 3.0D * Math.sin(th * 11.0D + this.ph2);
                if (d > edge) {
                    continue;
                }
                double t = d / 120.0D;
                double s = Math.sqrt(Math.max(0.0D, 1.0D - t * t));
                int upper = this.y0 + (int) Math.round(170.0D + 36.0D * s + 5.0D * this.noise(u, v));
                int thick = (int) Math.round(34.0D - 12.0D * t * t + 6.0D * this.noise(u * 1.7D + 40.0D, v * 1.7D - 20.0D));
                int lower = upper - thick - (int) Math.round(14.0D * t * t * t);
                int from = Math.max(lower, c.minY);
                int to = Math.min(upper, c.maxY);
                for (int y = from; y <= to; y++) {
                    BlockState state;
                    if (y == lower) {
                        double r = this.rnd(x, y, z);
                        if (r < 0.05D) {
                            state = leaves(true);
                        } else if (r < 0.056D) {
                            state = Blocks.SHROOMLIGHT.defaultBlockState();
                        } else {
                            state = leaves(false);
                        }
                    } else {
                        state = leaves(false);
                    }
                    c.set(x, y, z, state);
                }
            }
        }
    }

    // ---- ramas gigantes

    private void branchesPass(Ctx c) {
        if (c.outside(this.cx - 125, this.cz - 125, this.cx + 125, this.cz + 125, this.y0 + 125, this.y0 + 200)) {
            return;
        }
        for (int i = 0; i < 8; i++) {
            for (int k = 0; k < 3; k++) {
                double[] a = this.branchPoint(i, k);
                double[] b = this.branchPoint(i, k + 1);
                for (int s = 0; s <= 30; s++) {
                    double t = s / 30.0D;
                    this.sphere(c, a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t,
                            a[3] + (b[3] - a[3]) * t);
                }
            }
            // ramitas laterales
            for (int side = -1; side <= 1; side += 2) {
                double[] a = this.branchPoint(i, side < 0 ? 1 : 2);
                double phi = a[4] + side * 0.75D;
                for (int s = 0; s <= 24; s++) {
                    double t = s / 24.0D;
                    this.sphere(c, a[0] + Math.cos(phi) * 30.0D * t, a[1] + 11.0D * t, a[2] + Math.sin(phi) * 30.0D * t,
                            3.2D - 1.8D * t);
                }
            }
        }
    }

    // ---- raices

    private void rootsPass(Ctx c) {
        if (c.outside(this.cx - 64, this.cz - 64, this.cx + 64, this.cz + 64, this.y0 - 6, this.y0 + 40)) {
            return;
        }
        for (int x = Math.max(c.minX, this.cx - 64); x <= Math.min(c.maxX, this.cx + 64); x++) {
            for (int z = Math.max(c.minZ, this.cz - 64); z <= Math.min(c.maxZ, this.cz + 64); z++) {
                int u = x - this.cx;
                int v = z - this.cz;
                double d = Math.sqrt((double) (u * u + v * v));
                if (d > 62.0D) {
                    continue;
                }
                double th = Math.atan2(v, u);
                double lobe = Math.pow(0.5D + 0.5D * Math.cos(6.0D * (th + 0.35D * Math.sin(d * 0.09D + this.ph1))), 3.0D);
                double fall = Math.max(0.0D, Math.min(1.0D, (62.0D - d) / 42.0D));
                int rh = (int) Math.round(lobe * 30.0D * Math.pow(fall, 1.3D));
                rh = Math.max(rh, (int) Math.round(6.0D * fall * fall));
                if (rh <= 0) {
                    continue;
                }
                int topY = this.y0 + rh;
                int ground = c.level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z);
                if (topY < ground) {
                    continue;
                }
                for (int y = Math.max(c.minY, ground - 3); y <= Math.min(topY, c.maxY); y++) {
                    c.set(x, y, z, (y == topY && this.rnd(x, y, z) < 0.5D) ? Blocks.MOSS_BLOCK.defaultBlockState() : this.bark(x, y, z));
                }
            }
        }
    }

    // ---- mesetas de los reinos

    private double midEdge(double th) {
        return 56.0D + 6.0D * Math.sin(th * 3.0D + this.ph1) + 3.0D * Math.sin(th * 7.0D + this.ph2);
    }

    private double alfEdge(double th) {
        return 48.0D + 5.0D * Math.sin(th * 4.0D + this.ph2) + 3.0D * Math.sin(th * 9.0D + this.ph3);
    }

    private double asgEdge(double th) {
        return 36.0D + 2.0D * Math.sin(th * 6.0D + this.ph1);
    }

    /** Midgard: la gran meseta de hierba que rodea el tronco, con la base de roca afilandose hacia abajo. */
    private void midgardPass(Ctx c) {
        int top = this.y0 + MIDGARD;
        if (c.outside(this.cx - 64, this.cz - 64, this.cx + 64, this.cz + 64, top - 34, top)) {
            return;
        }
        for (int x = Math.max(c.minX, this.cx - 64); x <= Math.min(c.maxX, this.cx + 64); x++) {
            for (int z = Math.max(c.minZ, this.cz - 64); z <= Math.min(c.maxZ, this.cz + 64); z++) {
                int u = x - this.cx;
                int v = z - this.cz;
                double d = Math.sqrt((double) (u * u + v * v));
                double edge = this.midEdge(Math.atan2(v, u));
                if (d > edge) {
                    continue;
                }
                double t = d / edge;
                int depth = 5 + (int) (26.0D * Math.pow(1.0D - t, 1.4D));
                for (int y = Math.max(c.minY, top - depth); y <= Math.min(c.maxY, top); y++) {
                    BlockState state;
                    if (y == top) {
                        state = Blocks.GRASS_BLOCK.defaultBlockState();
                    } else if (y >= top - 2) {
                        state = this.rnd(x, y, z) < 0.15D ? Blocks.COARSE_DIRT.defaultBlockState() : Blocks.DIRT.defaultBlockState();
                    } else {
                        double r = this.rnd(x, y, z);
                        state = r < 0.62D ? Blocks.STONE.defaultBlockState()
                                : (r < 0.80D ? Blocks.ANDESITE.defaultBlockState()
                                : (r < 0.92D ? Blocks.MOSSY_COBBLESTONE.defaultBlockState() : Blocks.GRAVEL.defaultBlockState()));
                    }
                    c.set(x, y, z, state);
                }
            }
        }
    }

    /** Alfheim: la gran plataforma de madera clara donde viven los elfos. */
    private void alfheimPass(Ctx c) {
        int top = this.y0 + ALFHEIM;
        if (c.outside(this.cx - 56, this.cz - 56, this.cx + 56, this.cz + 56, top - 20, top + 2)) {
            return;
        }
        for (int x = Math.max(c.minX, this.cx - 56); x <= Math.min(c.maxX, this.cx + 56); x++) {
            for (int z = Math.max(c.minZ, this.cz - 56); z <= Math.min(c.maxZ, this.cz + 56); z++) {
                int u = x - this.cx;
                int v = z - this.cz;
                double d = Math.sqrt((double) (u * u + v * v));
                double edge = this.alfEdge(Math.atan2(v, u));
                if (d > edge) {
                    continue;
                }
                double t = d / edge;
                int depth = 3 + (int) (15.0D * Math.pow(1.0D - t, 1.3D));
                for (int y = Math.max(c.minY, top - depth); y <= Math.min(c.maxY, top); y++) {
                    BlockState state;
                    if (y == top) {
                        state = this.rnd(x, y, z) < 0.25D ? Blocks.STRIPPED_BIRCH_WOOD.defaultBlockState() : Blocks.BIRCH_PLANKS.defaultBlockState();
                    } else if (y == top - depth && this.rnd(x, y, z) < 0.02D) {
                        state = Blocks.SHROOMLIGHT.defaultBlockState();
                    } else {
                        state = this.bark(x, y, z);
                    }
                    c.set(x, y, z, state);
                }
                if (d > edge - 1.2D && top + 1 <= c.maxY) {
                    c.set(x, top + 1, z, Blocks.BIRCH_FENCE.defaultBlockState());
                    if (this.rnd(x, top, z) < 0.10D) {
                        c.set(x, top + 2, z, Blocks.LANTERN.defaultBlockState());
                    }
                }
            }
        }
    }

    /** Asgard: la terraza de cuarzo y oro sobre la copa. */
    private void asgardPass(Ctx c) {
        int top = this.y0 + ASGARD;
        if (c.outside(this.cx - 40, this.cz - 40, this.cx + 40, this.cz + 40, top - 16, top)) {
            return;
        }
        for (int x = Math.max(c.minX, this.cx - 40); x <= Math.min(c.maxX, this.cx + 40); x++) {
            for (int z = Math.max(c.minZ, this.cz - 40); z <= Math.min(c.maxZ, this.cz + 40); z++) {
                int u = x - this.cx;
                int v = z - this.cz;
                double d = Math.sqrt((double) (u * u + v * v));
                double edge = this.asgEdge(Math.atan2(v, u));
                if (d > edge) {
                    continue;
                }
                double t = d / edge;
                int depth = 3 + (int) (12.0D * (1.0D - t));
                for (int y = Math.max(c.minY, top - depth); y <= Math.min(c.maxY, top); y++) {
                    BlockState state;
                    if (y == top) {
                        boolean ring = (d >= 16.5D && d <= 17.6D) || (d >= 28.0D && d <= 29.0D);
                        state = ring ? Blocks.GOLD_BLOCK.defaultBlockState()
                                : (((u + v) & 1) == 0 ? Blocks.QUARTZ_BLOCK.defaultBlockState() : Blocks.SMOOTH_QUARTZ.defaultBlockState());
                    } else {
                        state = y == top - depth ? Blocks.GOLD_BLOCK.defaultBlockState() : Blocks.QUARTZ_BRICKS.defaultBlockState();
                    }
                    c.set(x, y, z, state);
                }
            }
        }
    }

    // ---- tronco hueco con escalera de caracol

    private void trunkPass(Ctx c) {
        if (c.outside(this.cx - 36, this.cz - 36, this.cx + 36, this.cz + 36, this.y0 - DEPTH, this.y0 + KEEP_TOP + 3)) {
            return;
        }
        int[] stairH = new int[12];
        double[] base = new double[KEEP_TOP + 3 + DEPTH + 1];
        for (int i = 0; i < base.length; i++) {
            base[i] = baseRadius(i - DEPTH);
        }
        int hLo = Math.max(c.minY - this.y0, -DEPTH);
        int hHi = Math.min(c.maxY - this.y0, KEEP_TOP + 2);
        for (int x = Math.max(c.minX, this.cx - 36); x <= Math.min(c.maxX, this.cx + 36); x++) {
            for (int z = Math.max(c.minZ, this.cz - 36); z <= Math.min(c.maxZ, this.cz + 36); z++) {
                int u = x - this.cx;
                int v = z - this.cz;
                int d2 = u * u + v * v;
                if (d2 > 36 * 36) {
                    continue;
                }
                double d = Math.sqrt((double) d2);
                double th = Math.atan2(v, u);
                int rho = (int) Math.round(d);
                int n = 0;
                if (rho >= 3 && rho <= 7) {
                    for (int k = -1; k <= 8; k++) {
                        int h = (int) Math.round(1.0D + 5.0D * (th + 2.0D * Math.PI * k));
                        if (h >= 0 && h <= STAIR_TOP && n < stairH.length) {
                            stairH[n++] = h;
                        }
                    }
                }
                Direction up = facingOf(-Math.sin(th), Math.cos(th));
                for (int h = hLo; h <= hHi; h++) {
                    int y = this.y0 + h;
                    double b = base[h + DEPTH];
                    double ir = b - 5.5D;
                    double outer = b;
                    if (h > 0) {
                        outer += 1.8D * Math.sin(3.0D * th + h * 0.045D + this.ph1) + 1.5D * Math.sin(5.0D * th - h * 0.061D + this.ph2);
                    }
                    BlockState state;
                    if (d <= ir) {
                        state = this.hollow(x, y, z, u, v, h, d, th, rho, stairH, n, up);
                    } else if (d <= outer) {
                        int dr = this.door(h, d, th);
                        if (dr == 1) {
                            state = AIR;
                        } else if (dr == 2) {
                            state = Blocks.BIRCH_PLANKS.defaultBlockState();
                        } else {
                            state = this.wall(x, y, z, h, d, ir, th);
                        }
                    } else if (h <= 14 && d <= outer + 12.0D && this.door(h, d, th) == 1) {
                        state = AIR;
                    } else {
                        continue;
                    }
                    if (state != null) {
                        c.set(x, y, z, state);
                    }
                }
            }
        }
    }

    private BlockState hollow(int x, int y, int z, int u, int v, int h, double d, double th, int rho, int[] stairH, int n, Direction up) {
        if (h < HEL_FLOOR) {
            return this.bark(x, y, z);
        }
        if (h == HEL_FLOOR) {
            double r = this.rnd(x, y, z);
            return r < 0.12D ? Blocks.SOUL_SOIL.defaultBlockState()
                    : (r < 0.55D ? Blocks.DEEPSLATE_TILES.defaultBlockState()
                    : (r < 0.80D ? Blocks.COBBLED_DEEPSLATE.defaultBlockState() : Blocks.DEEPSLATE_BRICKS.defaultBlockState()));
        }
        if (h < -1) {
            return AIR;
        }
        if (h == -1) {
            if (u == 2 && v == 0) {
                return AIR;
            }
            if (d < 11.0D) {
                return ((u + v) & 1) == 0 ? Blocks.BIRCH_PLANKS.defaultBlockState() : Blocks.STRIPPED_BIRCH_WOOD.defaultBlockState();
            }
            if (d < 12.2D) {
                return Blocks.GOLD_BLOCK.defaultBlockState();
            }
            double r = this.rnd(x, y, z);
            return r < 0.5D ? Blocks.STONE_BRICKS.defaultBlockState()
                    : (r < 0.8D ? Blocks.MOSSY_STONE_BRICKS.defaultBlockState() : Blocks.CRACKED_STONE_BRICKS.defaultBlockState());
        }
        if (n > 0) {
            if (rho >= 4 && rho <= 6) {
                for (int i = 0; i < n; i++) {
                    if (stairH[i] == h) {
                        return stair(h > ASGARD ? Blocks.QUARTZ_STAIRS : Blocks.BIRCH_STAIRS, up);
                    }
                }
            } else {
                for (int i = 0; i < n; i++) {
                    if (stairH[i] + 1 == h && this.door(h, d, th) == 0) {
                        return Blocks.BIRCH_FENCE.defaultBlockState();
                    }
                }
            }
        }
        if (h > KEEP_TOP) {
            return AIR;
        }
        if (d >= 3.5D && this.door(h, d, th) == 2) {
            return Blocks.BIRCH_PLANKS.defaultBlockState();
        }
        return AIR;
    }

    private BlockState wall(int x, int y, int z, int h, double d, double ir, double th) {
        if (h > ASGARD) {
            double a = (th + Math.PI) / (2.0D * Math.PI) * 16.0D;
            int idx = (int) Math.floor(a);
            double frac = a - idx;
            if (h > KEEP_TOP) {
                return (((int) Math.floor(a * 1.5D)) & 1) == 0 ? Blocks.QUARTZ_BRICKS.defaultBlockState() : null;
            }
            int hm = h & 7;
            if (hm == 0) {
                return Blocks.GOLD_BLOCK.defaultBlockState();
            }
            if (hm >= 3 && hm <= 5 && frac > 0.3D && frac < 0.7D && (idx & 1) == 0) {
                return Blocks.GLASS.defaultBlockState();
            }
            return Blocks.QUARTZ_BRICKS.defaultBlockState();
        }
        if (h > 0 && d <= ir + 1.6D && this.rnd(x, y, z) < 0.045D) {
            return Blocks.SHROOMLIGHT.defaultBlockState();
        }
        return this.bark(x, y, z);
    }

    // ------------------------------------------------------------------ detalles, ciudades y habitantes

    private void detailsPass(Ctx c) {
        this.helheim(c);
        this.groundHall(c);
        this.midgardDetails(c);
        this.alfheimDetails(c);
        this.outposts(c);
        this.asgardDetails(c);
    }

    private void spawn(Ctx c, net.minecraft.world.entity.Mob mob, int x, int y, int z) {
        if (mob == null || !c.in(x, y, z)) {
            return;
        }
        mob.moveTo(x + 0.5D, y, z + 0.5D, (float) (this.rnd(x, y, z) * 360.0D), 0.0F);
        mob.finalizeSpawn(c.level, c.level.getCurrentDifficultyAt(new BlockPos(x, y, z)), MobSpawnType.STRUCTURE, null, null);
        c.level.addFreshEntityWithPassengers(mob);
    }

    private void elf(Ctx c, int x, int y, int z, int variant) {
        if (!c.in(x, y, z)) {
            return;
        }
        ElfEntity elf = ModEntities.ELF.get().create(c.level.getLevel());
        if (elf != null) {
            elf.setVariant(variant);
            this.spawn(c, elf, x, y, z);
        }
    }

    private void dragoncito(Ctx c, int x, int y, int z) {
        if (!c.in(x, y, z)) {
            return;
        }
        net.minecraft.world.entity.Mob mob = ModEntities.DRAGONCITO.get().create(c.level.getLevel());
        this.spawn(c, mob, x, y, z);
    }

    private void chest(Ctx c, int x, int y, int z, Direction facing, ResourceLocation loot) {
        BlockState state = Blocks.CHEST.defaultBlockState().setValue(net.minecraft.world.level.block.ChestBlock.FACING, facing);
        this.createChest(c.level, c.chunkBox, c.random, new BlockPos(x, y, z), loot, state);
    }

    private void lectern(Ctx c, int x, int y, int z, Direction facing) {
        RiderLore.placeLectern(c.level, c.chunkBox, new BlockPos(x, y, z), facing, (int) (this.rnd(x, y, z) * RiderLore.chapters()));
    }

    // ---- Helheim: la camara bajo las raices

    private void helheim(Ctx c) {
        if (c.outside(this.cx - 24, this.cz - 24, this.cx + 24, this.cz + 24, this.y0 + HEL_FLOOR, this.y0 + 3)) {
            return;
        }
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.WEST);
        for (int h = HEL_FLOOR + 1; h <= 0; h++) {
            c.set(this.cx + 2, this.y0 + h, this.cz, ladder);
        }
        for (int h = HEL_FLOOR + 1; h <= 1; h++) {
            c.set(this.cx + 3, this.y0 + h, this.cz, Blocks.STONE_BRICKS.defaultBlockState());
        }
        c.set(this.cx + 3, this.y0 + 2, this.cz, Blocks.LANTERN.defaultBlockState());
        // ocho columnas de hueso con faroles de almas
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0D + Math.PI / 8.0D;
            int px = this.cx + (int) Math.round(Math.cos(a) * 15.0D);
            int pz = this.cz + (int) Math.round(Math.sin(a) * 15.0D);
            for (int h = HEL_FLOOR + 1; h <= -3; h++) {
                c.set(px, this.y0 + h, pz, Blocks.BONE_BLOCK.defaultBlockState());
            }
            c.set(px, this.y0 - 2, pz, Blocks.SOUL_LANTERN.defaultBlockState());
        }
        // estrado de Hel
        int dx = this.cx - 8;
        int fy = this.y0 + HEL_FLOOR + 1;
        this.box(c, dx - 2, fy, this.cz - 2, dx + 2, fy, this.cz + 2, Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                c.set(dx + sx * 2, fy, this.cz + sz * 2, Blocks.SOUL_SOIL.defaultBlockState());
                c.set(dx + sx * 2, fy + 1, this.cz + sz * 2, Blocks.SOUL_FIRE.defaultBlockState());
            }
        }
        this.chest(c, dx, fy + 1, this.cz, Direction.EAST, LOOT_HEL);
        this.lectern(c, dx, fy, this.cz + 4, Direction.NORTH);
        for (int i = 0; i < 14; i++) {
            int sx = this.cx + (int) Math.round((this.rnd(i, 60, 1) - 0.5D) * 34.0D);
            int sz = this.cz + (int) Math.round((this.rnd(i, 61, 1) - 0.5D) * 34.0D);
            if (Math.hypot(sx - this.cx, sz - this.cz) < 20.0D && c.get(sx, fy - 1, sz).isSolid()) {
                c.set(sx, fy, sz, i % 3 == 0 ? Blocks.COBWEB.defaultBlockState() : Blocks.SKELETON_SKULL.defaultBlockState());
            }
        }
    }

    // ---- el gran salon al pie del tronco

    private void groundHall(Ctx c) {
        if (c.outside(this.cx - 20, this.cz - 20, this.cx + 20, this.cz + 20, this.y0, this.y0 + 18)) {
            return;
        }
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0D;
            int px = this.cx + (int) Math.round(Math.cos(a) * 16.0D);
            int pz = this.cz + (int) Math.round(Math.sin(a) * 16.0D);
            for (int h = 0; h <= 14; h++) {
                c.set(px, this.y0 + h, pz, h % 5 == 0 ? Blocks.GOLD_BLOCK.defaultBlockState() : Blocks.STRIPPED_DARK_OAK_WOOD.defaultBlockState());
            }
            c.set(px, this.y0 + 15, pz, Blocks.LANTERN.defaultBlockState());
        }
    }

    // ---- Midgard

    private void midgardDetails(Ctx c) {
        int top = this.y0 + MIDGARD;
        if (c.outside(this.cx - 64, this.cz - 64, this.cx + 64, this.cz + 64, top, top + 16)) {
            return;
        }
        // flores y hierba
        BlockState[] plants = {Blocks.GRASS.defaultBlockState(), Blocks.FERN.defaultBlockState(), Blocks.DANDELION.defaultBlockState(),
                Blocks.POPPY.defaultBlockState(), Blocks.AZURE_BLUET.defaultBlockState(), Blocks.CORNFLOWER.defaultBlockState(),
                Blocks.OXEYE_DAISY.defaultBlockState(), Blocks.ALLIUM.defaultBlockState()};
        for (int x = Math.max(c.minX, this.cx - 64); x <= Math.min(c.maxX, this.cx + 64); x++) {
            for (int z = Math.max(c.minZ, this.cz - 64); z <= Math.min(c.maxZ, this.cz + 64); z++) {
                int u = x - this.cx;
                int v = z - this.cz;
                double d = Math.sqrt((double) (u * u + v * v));
                if (d < 25.0D || d > this.midEdge(Math.atan2(v, u)) - 1.5D) {
                    continue;
                }
                double r = this.rnd(x, 50, z);
                if (r < 0.16D) {
                    c.set(x, top + 1, z, plants[(int) (this.rnd(x, 51, z) * plants.length)]);
                }
            }
        }
        // estanques
        for (int i = 0; i < 4; i++) {
            double a = Math.PI / 12.0D + i * Math.PI / 2.0D;
            int px = this.cx + (int) Math.round(Math.cos(a) * 27.0D);
            int pz = this.cz + (int) Math.round(Math.sin(a) * 27.0D);
            for (int dx = -5; dx <= 5; dx++) {
                for (int dz = -5; dz <= 5; dz++) {
                    if (dx * dx + dz * dz <= 17) {
                        c.set(px + dx, top, pz + dz, Blocks.WATER.defaultBlockState());
                        c.set(px + dx, top - 1, pz + dz, Blocks.WATER.defaultBlockState());
                        c.set(px + dx, top + 1, pz + dz, AIR);
                    }
                }
            }
        }
        // arboles pequenos (algunos dorados, descendientes del grande)
        for (int i = 0; i < 18; i++) {
            double a = this.rnd(i, 70, 0) * Math.PI * 2.0D;
            double r = 26.0D + this.rnd(i, 71, 0) * 26.0D;
            int px = this.cx + (int) Math.round(Math.cos(a) * r);
            int pz = this.cz + (int) Math.round(Math.sin(a) * r);
            this.smallTree(c, px, top + 1, pz, 4 + (int) (this.rnd(i, 72, 0) * 3.0D), i % 5 == 0);
        }
        // casas, caminos y farolas
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI / 6.0D + (this.rnd(i, 20, 0) - 0.5D) * 0.2D;
            int r = 36 + (int) (this.rnd(i, 21, 0) * 4.0D);
            int hx = this.cx + (int) Math.round(Math.cos(a) * r);
            int hz = this.cz + (int) Math.round(Math.sin(a) * r);
            for (int s = 24; s <= r - 5; s++) {
                for (int w = -1; w <= 1; w++) {
                    int px = this.cx + (int) Math.round(Math.cos(a) * s - Math.sin(a) * w);
                    int pz = this.cz + (int) Math.round(Math.sin(a) * s + Math.cos(a) * w);
                    c.set(px, top, pz, Blocks.DIRT_PATH.defaultBlockState());
                    c.set(px, top + 1, pz, AIR);
                }
                if (s % 9 == 0) {
                    int px = this.cx + (int) Math.round(Math.cos(a) * s - Math.sin(a) * 2);
                    int pz = this.cz + (int) Math.round(Math.sin(a) * s + Math.cos(a) * 2);
                    c.set(px, top + 1, pz, Blocks.OAK_FENCE.defaultBlockState());
                    c.set(px, top + 2, pz, Blocks.OAK_FENCE.defaultBlockState());
                    c.set(px, top + 3, pz, Blocks.LANTERN.defaultBlockState());
                }
            }
            int f = facingIndex(this.cx - hx, this.cz - hz);
            this.house(c, hx, top, hz, f, 1);
            this.elf(c, hx, top + 1, hz, i % 3);
            if (i % 2 == 0) {
                this.dragoncito(c, hx + 1, top + 1, hz + 6);
            }
        }
    }

    private void smallTree(Ctx c, int x, int y, int z, int height, boolean golden) {
        if (c.outside(x - 3, z - 3, x + 3, z + 3, y, y + height + 3)) {
            return;
        }
        for (int h = 0; h < height; h++) {
            c.set(x, y + h, z, golden ? Blocks.BIRCH_LOG.defaultBlockState() : Blocks.OAK_LOG.defaultBlockState());
        }
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = -1; dy <= 2; dy++) {
                    double dd = dx * dx + dz * dz + dy * dy * 1.6D;
                    if (dd <= 5.2D && !(dx == 0 && dz == 0 && dy <= 0)) {
                        c.set(x + dx, y + height - 1 + dy, z + dz, golden ? leaves(this.rnd(x + dx, dy, z + dz) < 0.12D) : oakLeaves());
                    }
                }
            }
        }
    }

    // ---- Alfheim

    private void alfheimDetails(Ctx c) {
        int top = this.y0 + ALFHEIM;
        if (c.outside(this.cx - 56, this.cz - 56, this.cx + 56, this.cz + 56, top, top + 36)) {
            return;
        }
        for (int i = 0; i < 14; i++) {
            double a = i * Math.PI * 2.0D / 14.0D + (this.rnd(i, 30, 0) - 0.5D) * 0.1D;
            int r = 34 + (int) Math.round(this.rnd(i, 31, 0));
            int hx = this.cx + (int) Math.round(Math.cos(a) * r);
            int hz = this.cz + (int) Math.round(Math.sin(a) * r);
            this.house(c, hx, top, hz, facingIndex(this.cx - hx, this.cz - hz), 0);
            this.elf(c, hx - 1, top + 1, hz, 0);
            this.elf(c, hx + 1, top + 1, hz, i % 2 == 0 ? 1 : 2);
            // jardin con matorral dorado delante
            int gx = this.cx + (int) Math.round(Math.cos(a) * (r - 7));
            int gz = this.cz + (int) Math.round(Math.sin(a) * (r - 7));
            this.bush(c, gx, top + 1, gz);
            if (i % 3 == 0) {
                this.dragoncito(c, gx, top + 1, gz);
            }
        }
        for (int i = 0; i < 4; i++) {
            double a = Math.PI / 4.0D + i * Math.PI / 2.0D;
            int tx = this.cx + (int) Math.round(Math.cos(a) * 24.0D);
            int tz = this.cz + (int) Math.round(Math.sin(a) * 24.0D);
            this.tower(c, tx, top, tz, 4, 26, 0, i == 0);
            this.elf(c, tx + 1, top + 1, tz + 1, 1);
        }
        // plaza central: farolas
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI / 6.0D + Math.PI / 12.0D;
            int px = this.cx + (int) Math.round(Math.cos(a) * 28.0D);
            int pz = this.cz + (int) Math.round(Math.sin(a) * 28.0D);
            for (int h = 1; h <= 3; h++) {
                c.set(px, top + h, pz, Blocks.BIRCH_FENCE.defaultBlockState());
            }
            c.set(px, top + 4, pz, Blocks.LANTERN.defaultBlockState());
        }
    }

    private void bush(Ctx c, int x, int y, int z) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                c.set(x + dx, y, z + dz, leaves(this.rnd(x + dx, y, z + dz) < 0.2D));
                if (dx == 0 || dz == 0) {
                    c.set(x + dx, y + 1, z + dz, leaves(false));
                }
            }
        }
    }

    // ---- puestos elficos sobre las ramas gigantes

    private void outposts(Ctx c) {
        for (int i = 0; i < 8; i += 2) {
            double[] p = this.branchPoint(i, 1);
            int px = (int) Math.round(p[0]);
            int pz = (int) Math.round(p[2]);
            int top = (int) Math.round(p[1]) + 7;
            if (c.outside(px - 10, pz - 10, px + 10, pz + 10, top - 12, top + 16)) {
                continue;
            }
            for (int dx = -9; dx <= 9; dx++) {
                for (int dz = -9; dz <= 9; dz++) {
                    double d = Math.sqrt((double) (dx * dx + dz * dz));
                    if (d > 9.0D) {
                        continue;
                    }
                    int depth = 2 + (int) (8.0D * (1.0D - d / 9.0D));
                    for (int y = top - depth; y < top; y++) {
                        c.set(px + dx, y, pz + dz, this.bark(px + dx, y, pz + dz));
                    }
                    c.set(px + dx, top, pz + dz, Blocks.BIRCH_PLANKS.defaultBlockState());
                    if (d > 7.8D) {
                        c.set(px + dx, top + 1, pz + dz, Blocks.BIRCH_FENCE.defaultBlockState());
                        if (this.rnd(px + dx, top, pz + dz) < 0.15D) {
                            c.set(px + dx, top + 2, pz + dz, Blocks.LANTERN.defaultBlockState());
                        }
                    }
                }
            }
            this.house(c, px, top, pz, facingIndex(Math.cos(p[4]), Math.sin(p[4])), 0);
            this.elf(c, px, top + 1, pz, 0);
            this.elf(c, px + 1, top + 1, pz - 1, 2);
        }
    }

    // ---- Asgard

    private void asgardDetails(Ctx c) {
        int top = this.y0 + ASGARD;
        if (c.outside(this.cx - 40, this.cz - 40, this.cx + 40, this.cz + 52, top, top + 46)) {
            return;
        }
        double gate = this.doorAngle(5);
        // muralla con dos puertas
        for (int x = Math.max(c.minX, this.cx - 38); x <= Math.min(c.maxX, this.cx + 38); x++) {
            for (int z = Math.max(c.minZ, this.cz - 38); z <= Math.min(c.maxZ, this.cz + 38); z++) {
                int u = x - this.cx;
                int v = z - this.cz;
                double d = Math.sqrt((double) (u * u + v * v));
                if (d < 32.6D || d > 34.8D) {
                    continue;
                }
                double th = Math.atan2(v, u);
                if (Math.abs(d * Math.sin(angleDiff(th, gate))) < 3.6D) {
                    continue;
                }
                for (int h = 1; h <= 6; h++) {
                    c.set(x, top + h, z, h == 1 ? Blocks.CHISELED_QUARTZ_BLOCK.defaultBlockState() : Blocks.QUARTZ_BRICKS.defaultBlockState());
                }
                if (((u + v) & 1) == 0) {
                    c.set(x, top + 7, z, Blocks.QUARTZ_BRICKS.defaultBlockState());
                    if (this.rnd(x, top, z) < 0.12D) {
                        c.set(x, top + 8, z, Blocks.LANTERN.defaultBlockState());
                    }
                }
            }
        }
        // seis torres doradas
        for (int i = 0; i < 6; i++) {
            double a = gate + Math.PI / 6.0D + i * Math.PI / 3.0D;
            int tx = this.cx + (int) Math.round(Math.cos(a) * 26.0D);
            int tz = this.cz + (int) Math.round(Math.sin(a) * 26.0D);
            this.tower(c, tx, top, tz, 4, 24, 1, i == 3 || i == 0);
            this.elf(c, tx + 1, top + 1, tz, 0);
        }
        // matorrales dorados en el jardin
        for (int i = 0; i < 10; i++) {
            double a = gate + Math.PI / 3.0D + i * Math.PI / 5.0D;
            this.bush(c, this.cx + (int) Math.round(Math.cos(a) * 20.0D), top + 1, this.cz + (int) Math.round(Math.sin(a) * 20.0D));
        }
        // guardias
        for (int i = 0; i < 8; i++) {
            double a = gate + i * Math.PI / 4.0D + 0.2D;
            this.elf(c, this.cx + (int) Math.round(Math.cos(a) * 22.0D), top + 1, this.cz + (int) Math.round(Math.sin(a) * 22.0D), 0);
        }
        // el Ojo de Yggdrasil flotando sobre la torre del homenaje
        int ey = this.y0 + 244;
        double ex = this.cx;
        double ez = this.cz;
        if (!c.outside(this.cx - 5, this.cz - 5, this.cx + 5, this.cz + 5, ey - 5, ey + 5)) {
            for (int dx = -4; dx <= 4; dx++) {
                for (int dy = -4; dy <= 4; dy++) {
                    for (int dz = -4; dz <= 4; dz++) {
                        double dd = Math.sqrt((double) (dx * dx + dy * dy + dz * dz));
                        if (dd <= 1.7D) {
                            c.set(this.cx + dx, ey + dy, this.cz + dz, Blocks.SEA_LANTERN.defaultBlockState());
                        } else if (dd <= 3.6D) {
                            c.set(this.cx + dx, ey + dy, this.cz + dz, Blocks.BLUE_STAINED_GLASS.defaultBlockState());
                        }
                    }
                }
            }
        }
    }

    // ---- casas y torres de los elfos

    /** Casita de 7x7: cimiento, paredes con ventanas, tejado escalonado y un poco de vida dentro. */
    private void house(Ctx c, int hx, int hy, int hz, int f, int style) {
        if (c.outside(hx - 6, hz - 6, hx + 6, hz + 6, hy, hy + 12)) {
            return;
        }
        int[][] dirs = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}};
        int fx = dirs[f & 3][0];
        int fz = dirs[f & 3][1];
        int rx = -fz;
        int rz = fx;
        BlockState floor = style == 0 ? Blocks.BIRCH_PLANKS.defaultBlockState() : Blocks.OAK_PLANKS.defaultBlockState();
        BlockState wall = style == 0 ? Blocks.WHITE_TERRACOTTA.defaultBlockState() : Blocks.OAK_PLANKS.defaultBlockState();
        BlockState post = style == 0 ? Blocks.STRIPPED_BIRCH_WOOD.defaultBlockState() : Blocks.OAK_LOG.defaultBlockState();
        BlockState roofA = style == 0 ? Blocks.RAW_GOLD_BLOCK.defaultBlockState() : Blocks.SPRUCE_PLANKS.defaultBlockState();
        BlockState roofB = style == 0 ? Blocks.YELLOW_TERRACOTTA.defaultBlockState() : Blocks.DARK_OAK_PLANKS.defaultBlockState();
        BlockState glass = Blocks.GLASS.defaultBlockState();
        for (int a = -4; a <= 4; a++) {
            for (int b = -4; b <= 4; b++) {
                int wx = hx + a * rx + b * fx;
                int wz = hz + a * rz + b * fz;
                int m = Math.max(Math.abs(a), Math.abs(b));
                if (m <= 3) {
                    c.set(wx, hy, wz, floor);
                    for (int k = 1; k <= 4; k++) {
                        BlockState s;
                        if (m < 3) {
                            s = AIR;
                        } else if (Math.abs(a) == 3 && Math.abs(b) == 3) {
                            s = post;
                        } else if (b == 3 && a == 0 && k <= 2) {
                            s = AIR;
                        } else if ((k == 2 || k == 3) && ((b == 3 && Math.abs(a) == 2) || (Math.abs(a) == 3 && b == 0) || (b == -3 && a == 0))) {
                            s = glass;
                        } else {
                            s = wall;
                        }
                        c.set(wx, hy + k, wz, s);
                    }
                }
                for (int layer = 0; layer <= 4; layer++) {
                    int half = 4 - layer;
                    if (Math.abs(a) <= half && Math.abs(b) <= half) {
                        c.set(wx, hy + 5 + layer, wz, (layer & 1) == 0 ? roofA : roofB);
                    }
                }
            }
        }
        c.set(hx, hy + 10, hz, Blocks.LANTERN.defaultBlockState());
        c.set(hx, hy + 4, hz, Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
        for (int a = -1; a <= 1; a++) {
            for (int b = -1; b <= 1; b++) {
                c.set(hx + a * rx + b * fx, hy + 1, hz + a * rz + b * fz, style == 0 ? Blocks.WHITE_CARPET.defaultBlockState() : Blocks.RED_CARPET.defaultBlockState());
            }
        }
        c.set(hx - 2 * rx - 2 * fx, hy + 1, hz - 2 * rz - 2 * fz, Blocks.BOOKSHELF.defaultBlockState());
        c.set(hx - 2 * rx - 2 * fx, hy + 2, hz - 2 * rz - 2 * fz, Blocks.BOOKSHELF.defaultBlockState());
        c.set(hx + 2 * rx - 2 * fx, hy + 1, hz + 2 * rz - 2 * fz, Blocks.CRAFTING_TABLE.defaultBlockState());
        c.set(hx + 2 * rx + 4 * fx, hy + 1, hz + 2 * rz + 4 * fz, Blocks.LANTERN.defaultBlockState());
        if (this.rnd(hx, hy, hz) < 0.35D) {
            Direction facing = f == 0 ? Direction.WEST : (f == 1 ? Direction.NORTH : (f == 2 ? Direction.EAST : Direction.SOUTH));
            this.chest(c, hx - 2 * rx - 1 * fx - 1 * fx, hy + 1, hz - 2 * rz - 1 * fz - 1 * fz, facing, LOOT_HOME);
        }
    }

    /** Torre cilindrica con escalera de mano, suelos, ventanas y tejado conico dorado. */
    private void tower(Ctx c, int tx, int ty, int tz, int r, int height, int style, boolean treasure) {
        if (c.outside(tx - r - 2, tz - r - 2, tx + r + 2, tz + r + 2, ty, ty + height + r + 8)) {
            return;
        }
        BlockState wallA = style == 0 ? Blocks.QUARTZ_BRICKS.defaultBlockState() : Blocks.SMOOTH_QUARTZ.defaultBlockState();
        BlockState band = Blocks.GOLD_BLOCK.defaultBlockState();
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.WEST);
        for (int y = 0; y <= height; y++) {
            for (int dx = -r - 1; dx <= r + 1; dx++) {
                for (int dz = -r - 1; dz <= r + 1; dz++) {
                    double dd = Math.sqrt((double) (dx * dx + dz * dz));
                    if (dd > r + 0.5D) {
                        continue;
                    }
                    BlockState s;
                    if (dd > r - 1.0D) {
                        if (y == 0) {
                            s = Blocks.STONE_BRICKS.defaultBlockState();
                        } else if (dz == 0 && dx < 0 && y <= 3) {
                            s = AIR;
                        } else if (y % 7 == 0) {
                            s = band;
                        } else if (y % 7 >= 3 && y % 7 <= 4 && (dx == 0 || dz == 0)) {
                            s = Blocks.GLASS.defaultBlockState();
                        } else {
                            s = wallA;
                        }
                    } else if (y == 0 || (y % 7 == 0 && !(dx == r - 1 && dz == 0))) {
                        s = Blocks.BIRCH_PLANKS.defaultBlockState();
                    } else if (dx == r - 1 && dz == 0 && y < height) {
                        s = ladder;
                    } else {
                        s = AIR;
                    }
                    c.set(tx + dx, ty + y, tz + dz, s);
                }
            }
        }
        for (int j = 0; j <= r + 3; j++) {
            double rr = (r + 1.0D) * (1.0D - j / (r + 4.0D));
            int yy = ty + height + 1 + j;
            for (int dx = -r - 1; dx <= r + 1; dx++) {
                for (int dz = -r - 1; dz <= r + 1; dz++) {
                    if (Math.sqrt((double) (dx * dx + dz * dz)) <= rr + 0.3D) {
                        c.set(tx + dx, yy, tz + dz, (j & 1) == 0 ? Blocks.RAW_GOLD_BLOCK.defaultBlockState() : Blocks.YELLOW_TERRACOTTA.defaultBlockState());
                    }
                }
            }
        }
        c.set(tx, ty + height + r + 5, tz, Blocks.SEA_LANTERN.defaultBlockState());
        c.set(tx, ty + 1, tz, Blocks.LANTERN.defaultBlockState());
        if (treasure) {
            this.chest(c, tx, ty + 1, tz - 1, Direction.SOUTH, LOOT_TREASURE);
        }
    }
}
