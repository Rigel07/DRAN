package com.isladragoncitos.worldgen.massive;

import com.isladragoncitos.block.DragonPortalBlock;
import com.isladragoncitos.portal.DragonPortalRegistry;
import com.isladragoncitos.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;

/** Construye el marco del portal del dragon y registra su nucleo como destino de la red. */
public final class DragonPortalBuilder {
    private DragonPortalBuilder() {}

    public static void build(WorldGenLevel level, BuildHelper h, int x, int y, int z, Direction facing) {
        BlockState bricks = ModBlocks.DRAGONSTONE_BRICKS.get().defaultBlockState();
        BlockState chiseled = ModBlocks.CHISELED_DRAGONSTONE.get().defaultBlockState();
        BlockState lamp = ModBlocks.DRAGON_LAMP.get().defaultBlockState();
        BlockState portal = ModBlocks.DRAGON_PORTAL.get().defaultBlockState().setValue(DragonPortalBlock.FACING, facing);
        Direction right = facing.getClockWise();
        int rx = right.getStepX();
        int rz = right.getStepZ();
        int fx = facing.getStepX();
        int fz = facing.getStepZ();

        // despeja el hueco para que la vegetacion o la roca no atraviesen el portal
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = 0; dy <= 8; dy++) {
                for (int depth = -2; depth <= 2; depth++) {
                    h.set(x + rx * dx + fx * depth, y + dy, z + rz * dx + fz * depth, BuildHelper.AIR);
                }
            }
        }

        // plataforma
        for (int dx = -4; dx <= 4; dx++) {
            for (int depth = -2; depth <= 1; depth++) {
                int px = x + rx * dx + fx * depth;
                int pz = z + rz * dx + fz * depth;
                BlockState state = (Math.abs(dx) == 3 || depth == 0) ? chiseled : bricks;
                h.set(px, y - 1, pz, state);
                h.set(px, y - 2, pz, bricks);
            }
        }

        // columnas del marco
        for (int side = -1; side <= 1; side += 2) {
            for (int dy = 0; dy <= 5; dy++) {
                BlockState state = (dy == 2 || dy == 4) ? chiseled : bricks;
                h.set(x + rx * side * 2, y + dy, z + rz * side * 2, state);
            }
            // pilonos exteriores
            for (int dy = 0; dy <= 3; dy++) {
                h.set(x + rx * side * 4, y + dy, z + rz * side * 4, dy == 3 ? chiseled : bricks);
            }
            h.set(x + rx * side * 4, y + 4, z + rz * side * 4, lamp);
        }

        // dintel escalonado
        for (int dx = -2; dx <= 2; dx++) {
            h.set(x + rx * dx, y + 5, z + rz * dx, Math.abs(dx) == 1 ? chiseled : bricks);
        }
        for (int dx = -1; dx <= 1; dx++) {
            h.set(x + rx * dx, y + 6, z + rz * dx, bricks);
        }
        h.set(x, y + 7, z, chiseled);
        h.set(x, y + 8, z, lamp);
        for (int side = -1; side <= 1; side += 2) {
            h.set(x + rx * side, y + 7, z + rz * side, lamp);
            h.set(x + rx * side * 3, y + 6, z + rz * side * 3, chiseled);
        }

        // hoja de energia
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = 0; dy <= 4; dy++) {
                h.set(x + rx * dx, y + dy, z + rz * dx, portal.setValue(DragonPortalBlock.CORE, dx == 0 && dy == 0));
            }
        }

        BlockPos core = new BlockPos(x, y, z);
        if (h.inside(core.getX(), core.getY(), core.getZ())) {
            BlockState placed = h.get(core.getX(), core.getY(), core.getZ());
            if (placed.is(ModBlocks.DRAGON_PORTAL.get()) && placed.getValue(DragonPortalBlock.CORE)) {
                DragonPortalRegistry.queue(GlobalPos.of(level.getLevel().dimension(), core));
            }
        }
    }
}
