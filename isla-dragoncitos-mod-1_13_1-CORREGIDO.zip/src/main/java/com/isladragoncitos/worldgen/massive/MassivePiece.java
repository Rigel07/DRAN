package com.isladragoncitos.worldgen.massive;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.registry.ModBlocks;
import com.isladragoncitos.registry.ModEntities;
import com.isladragoncitos.registry.ModStructures;
import com.isladragoncitos.entity.DragonWorshipperEntity;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/** Pieza de las estructuras masivas. Todo sale de la semilla, asi que cada chunk reconstruye lo mismo. */
public class MassivePiece extends StructurePiece {
    public static final int CASTLE = 0;
    public static final int CAVE = 1;
    public static final int SANCTUARY = 2;
    public static final int VILLAGE = 3;
    public static final int GATE = 4;
    public static final int OBSERVATORY = 5;
    public static final int HATCHERY = 6;

    private static final String[] LOOT_NAMES = {"castle", "cave", "sanctuary", "village", "gate", "observatory", "hatchery"};

    private int kind;
    private int cx;
    private int y0;
    private int cz;
    private long seed;

    public MassivePiece(int kind, int cx, int y0, int cz, long seed) {
        super(ModStructures.MASSIVE_PIECE.get(), 0, boxFor(kind, cx, y0, cz));
        this.kind = kind;
        this.cx = cx;
        this.y0 = y0;
        this.cz = cz;
        this.seed = seed;
    }

    public MassivePiece(CompoundTag tag) {
        super(ModStructures.MASSIVE_PIECE.get(), tag);
        this.kind = tag.getInt("Kind");
        this.cx = tag.getInt("Cx");
        this.y0 = tag.getInt("Y0");
        this.cz = tag.getInt("Cz");
        this.seed = tag.getLong("Seed");
    }

    public static int halfSize(int kind) {
        return switch (kind) {
            case CASTLE -> 24;
            case CAVE -> 26;
            case SANCTUARY -> 20;
            case GATE -> 23;
            case OBSERVATORY -> 20;
            case HATCHERY -> 24;
            default -> 28;
        };
    }

    private static BoundingBox boxFor(int kind, int cx, int y0, int cz) {
        int m = halfSize(kind);
        int down = kind == CAVE ? 28 : 16;
        int up = switch (kind) {
            case CASTLE -> 36;
            case SANCTUARY -> 26;
            case GATE -> 30;
            case OBSERVATORY -> 36;
            case HATCHERY -> 24;
            default -> 16;
        };
        return new BoundingBox(cx - m, y0 - down, cz - m, cx + m, y0 + up, cz + m);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("Kind", this.kind);
        tag.putInt("Cx", this.cx);
        tag.putInt("Y0", this.y0);
        tag.putInt("Cz", this.cz);
        tag.putLong("Seed", this.seed);
    }

    private static BlockState b(Block block) {
        return block.defaultBlockState();
    }

    private ResourceLocation loot() {
        return new ResourceLocation(IslaDragoncitosMod.MODID, "chests/" + LOOT_NAMES[this.kind]);
    }

    @Override
    public void postProcess(WorldGenLevel level, StructureManager manager, ChunkGenerator generator, RandomSource random,
                            BoundingBox box, ChunkPos chunkPos, BlockPos pivot) {
        BuildHelper h = new BuildHelper(level, box);
        Random rnd = new Random(this.seed ^ (this.kind * 0x9E3779B97F4A7C15L));
        switch (this.kind) {
            case CASTLE -> this.castle(h, level, box, rnd, random);
            case CAVE -> this.cave(h, level, box, rnd, random);
            case SANCTUARY -> this.sanctuary(h, level, box, rnd, random);
            case GATE -> this.gate(h, level, box, rnd, random);
            case OBSERVATORY -> this.observatory(h, level, box, rnd, random);
            case HATCHERY -> this.hatchery(h, level, box, rnd, random);
            default -> this.village(h, level, box, rnd, random);
        }
    }

    private BlockState brick(Random rnd) {
        float r = rnd.nextFloat();
        if (r < 0.2F) {
            return b(Blocks.MOSSY_STONE_BRICKS);
        }
        if (r < 0.32F) {
            return b(Blocks.CRACKED_STONE_BRICKS);
        }
        return b(Blocks.STONE_BRICKS);
    }

    private void worshipper(WorldGenLevel level, BoundingBox box, int x, int y, int z, Random rnd) {
        BlockPos pos = new BlockPos(x, y, z);
        if (!box.isInside(pos)) {
            return;
        }
        DragonWorshipperEntity entity = ModEntities.WORSHIPPER.get().create(level.getLevel());
        if (entity == null) {
            return;
        }
        entity.moveTo(x + 0.5D, y, z + 0.5D, rnd.nextFloat() * 360.0F, 0.0F);
        entity.setPersistenceRequired();
        entity.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.STRUCTURE, null, null);
        level.addFreshEntityWithPassengers(entity);
    }

    // ---------------------------------------------------------------- castillo

    private void castle(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;
        for (int dx = -22; dx <= 22; dx++) {
            for (int dz = -22; dz <= 22; dz++) {
                h.foundation(cx + dx, cz + dz, y0, 14, b(Blocks.STONE_BRICKS));
            }
        }
        // patio
        for (int dx = -17; dx <= 17; dx++) {
            for (int dz = -17; dz <= 17; dz++) {
                h.set(cx + dx, y0 - 1, cz + dz, (dx + dz) % 4 == 0 ? b(Blocks.POLISHED_ANDESITE) : b(Blocks.COBBLESTONE));
            }
        }
        for (int dz = 8; dz <= 20; dz++) {
            for (int dx = -1; dx <= 1; dx++) {
                h.set(cx + dx, y0 - 1, cz + dz, b(Blocks.SMOOTH_STONE));
            }
        }
        // murallas
        for (int d = -20; d <= 20; d++) {
            for (int t = 0; t < 3; t++) {
                for (int y = 0; y <= 9; y++) {
                    h.set(cx + d, y0 + y, cz - 20 + t, this.brick(rnd));
                    h.set(cx + d, y0 + y, cz + 20 - t, this.brick(rnd));
                    h.set(cx - 20 + t, y0 + y, cz + d, this.brick(rnd));
                    h.set(cx + 20 - t, y0 + y, cz + d, this.brick(rnd));
                }
            }
            if (d % 2 == 0) {
                h.set(cx + d, y0 + 10, cz - 20, b(Blocks.STONE_BRICKS));
                h.set(cx + d, y0 + 10, cz + 20, b(Blocks.STONE_BRICKS));
                h.set(cx - 20, y0 + 10, cz + d, b(Blocks.STONE_BRICKS));
                h.set(cx + 20, y0 + 10, cz + d, b(Blocks.STONE_BRICKS));
            }
        }
        // puerta sur
        h.fill(cx - 2, y0, cz + 18, cx + 2, y0 + 6, cz + 20, BuildHelper.AIR);
        h.fill(cx - 3, y0 + 7, cz + 18, cx + 3, y0 + 7, cz + 20, b(Blocks.DEEPSLATE_BRICKS));
        h.set(cx - 3, y0 + 5, cz + 21, b(Blocks.LANTERN));
        h.set(cx + 3, y0 + 5, cz + 21, b(Blocks.LANTERN));
        // torres de las esquinas
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                this.tower(h, cx + sx * 20, cz + sz * 20, y0, rnd);
            }
        }
        // torreon central
        for (int dx = -7; dx <= 7; dx++) {
            for (int dz = -7; dz <= 7; dz++) {
                for (int y = 0; y <= 25; y++) {
                    boolean wall = Math.abs(dx) == 7 || Math.abs(dz) == 7;
                    h.set(cx + dx, y0 + y, cz + dz, wall ? this.brick(rnd) : BuildHelper.AIR);
                }
            }
        }
        for (int floor : new int[]{0, 8, 16}) {
            for (int dx = -6; dx <= 6; dx++) {
                for (int dz = -6; dz <= 6; dz++) {
                    if (!(dx == 6 && dz == 0) || floor == 0) {
                        h.set(cx + dx, y0 + floor - (floor == 0 ? 1 : 0), cz + dz, b(Blocks.SPRUCE_PLANKS));
                    }
                }
            }
        }
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                boolean rim = Math.abs(dx) >= 7 || Math.abs(dz) >= 7;
                h.set(cx + dx, y0 + 24, cz + dz, rim ? b(Blocks.DEEPSLATE_TILES) : b(Blocks.SPRUCE_PLANKS));
                if (rim && (dx + dz) % 2 == 0) {
                    h.set(cx + dx, y0 + 25, cz + dz, b(Blocks.DEEPSLATE_TILES));
                }
            }
        }
        h.fill(cx - 1, y0, cz + 7, cx + 1, y0 + 3, cz + 7, BuildHelper.AIR);
        for (int y = 0; y <= 23; y++) {
            h.set(cx + 6, y0 + y, cz, b(Blocks.LADDER).setValue(LadderBlock.FACING, Direction.WEST));
        }
        for (int[] w : new int[][]{{-4, 7}, {0, 7}, {4, 7}, {-4, -7}, {0, -7}, {4, -7}, {7, -4}, {-7, -4}, {-7, 4}, {-7, 0}}) {
            for (int fl : new int[]{3, 11, 19}) {
                h.fill(cx + w[0], y0 + fl, cz + w[1], cx + w[0], y0 + fl + 1, cz + w[1], BuildHelper.AIR);
            }
        }
        for (int fl : new int[]{4, 12, 20}) {
            h.set(cx - 5, y0 + fl, cz - 5, b(Blocks.LANTERN));
            h.set(cx + 5, y0 + fl, cz - 5, b(Blocks.LANTERN));
            h.set(cx - 5, y0 + fl, cz + 5, b(Blocks.LANTERN));
        }
        // sala del trono / altar del huevo
        h.fill(cx - 2, y0 + 17, cz - 5, cx + 2, y0 + 17, cz + 5, b(Blocks.RED_CARPET));
        h.fill(cx - 1, y0 + 17, cz - 1, cx + 1, y0 + 17, cz + 1, b(Blocks.OBSIDIAN));
        h.set(cx, y0 + 18, cz, ModBlocks.egg(rnd.nextInt(3)).defaultBlockState());
        h.lootChest(cx - 5, y0 + 17, cz + 5, this.loot(), random);
        h.lootChest(cx + 5, y0 + 17, cz - 5, this.loot(), random);
        h.lootChest(cx - 5, y0 + 1, cz - 5, this.loot(), random);
        // adoradores
        this.worshipper(level, box, cx, y0, cz + 12, rnd);
        this.worshipper(level, box, cx - 8, y0, cz + 10, rnd);
        this.worshipper(level, box, cx + 9, y0, cz - 10, rnd);
        this.worshipper(level, box, cx, y0 + 9, cz + 2, rnd);
        this.worshipper(level, box, cx + 2, y0 + 17, cz + 3, rnd);
        DragonPortalBuilder.build(level, h, cx, y0, cz - 14, Direction.SOUTH);
    }

    private void tower(BuildHelper h, int tx, int tz, int y0, Random rnd) {
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                double d2 = dx * dx + dz * dz;
                if (d2 > 26) {
                    continue;
                }
                for (int y = 0; y <= 20; y++) {
                    boolean wall = d2 > 12;
                    h.set(tx + dx, y0 + y, tz + dz, wall ? this.brick(rnd) : BuildHelper.AIR);
                }
                for (int fl : new int[]{0, 7, 14}) {
                    if (!(dx == 3 && dz == 0) || fl == 0) {
                        h.set(tx + dx, y0 + fl - (fl == 0 ? 1 : 0), tz + dz, d2 <= 12 ? b(Blocks.SPRUCE_PLANKS) : b(Blocks.STONE_BRICKS));
                    }
                }
                h.set(tx + dx, y0 + 20, tz + dz, d2 <= 12 ? b(Blocks.SPRUCE_PLANKS) : b(Blocks.DEEPSLATE_TILES));
                if (d2 > 17 && (dx + dz) % 2 == 0) {
                    h.set(tx + dx, y0 + 21, tz + dz, b(Blocks.DEEPSLATE_TILES));
                }
            }
        }
        for (int y = 0; y <= 19; y++) {
            h.set(tx + 3, y0 + y, tz, b(Blocks.LADDER).setValue(LadderBlock.FACING, Direction.WEST));
        }
        for (int fl : new int[]{3, 10, 16}) {
            h.fill(tx + 4, y0 + fl, tz, tx + 4, y0 + fl + 1, tz, BuildHelper.AIR);
            h.fill(tx, y0 + fl, tz - 4, tx, y0 + fl + 1, tz - 4, BuildHelper.AIR);
        }
        h.set(tx, y0 + 6, tz, b(Blocks.LANTERN));
    }

    // ---------------------------------------------------------------- cueva del dragon

    private void cave(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int cy = this.y0 - 14;
        double rx = 20.0D;
        double ry = 11.0D;
        // sala principal
        for (int dx = -21; dx <= 21; dx++) {
            for (int dy = -12; dy <= 12; dy++) {
                for (int dz = -21; dz <= 21; dz++) {
                    double noise = 0.92D + rnd.nextDouble() * 0.16D;
                    double d = (dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) + (dz * dz) / (rx * rx);
                    if (d <= noise) {
                        h.set(cx + dx, cy + dy, cz + dz, BuildHelper.AIR);
                    } else if (d <= 1.35D && h.get(cx + dx, cy + dy, cz + dz).isAir()) {
                        continue;
                    }
                }
            }
        }
        int floorY = cy - 10;
        // suelo oscuro
        for (int dx = -20; dx <= 20; dx++) {
            for (int dz = -20; dz <= 20; dz++) {
                for (int y = floorY - 2; y <= floorY + 1; y++) {
                    if (h.get(cx + dx, y, cz + dz).isAir() && h.get(cx + dx, y - 1, cz + dz).isAir() == false && y <= floorY + 1) {
                        float r = rnd.nextFloat();
                        h.set(cx + dx, y - 1, cz + dz, r < 0.08F ? b(Blocks.MAGMA_BLOCK) : (r < 0.5F ? b(Blocks.BLACKSTONE) : b(Blocks.BASALT)));
                        break;
                    }
                }
            }
        }
        // entrada: tunel que sube a la superficie por el sur
        for (int t = 0; t <= 24; t++) {
            int tz = cz + 10 + t;
            int ty = cy - 8 + (int) Math.round(t * 0.7D);
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = 0; dy <= 3; dy++) {
                    h.set(cx + dx, ty + dy, tz, BuildHelper.AIR);
                }
            }
            if (t % 5 == 0) {
                h.set(cx - 2, ty + 1, tz, b(Blocks.TORCH));
            }
        }
        // estalactitas y columnas
        for (int i = 0; i < 26; i++) {
            int x = cx + rnd.nextInt(33) - 16;
            int z = cz + rnd.nextInt(33) - 16;
            int len = 3 + rnd.nextInt(6);
            boolean column = rnd.nextInt(4) == 0;
            int top = cy + 9;
            for (int y = 0; y < (column ? 20 : len); y++) {
                h.set(x, top - y, z, b(Blocks.DRIPSTONE_BLOCK));
            }
        }
        // tesoro: montones de oro
        for (int i = 0; i < 7; i++) {
            int px = cx + rnd.nextInt(25) - 12;
            int pz = cz + rnd.nextInt(25) - 12;
            int height = 2 + rnd.nextInt(4);
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    int hh = height - (int) Math.round(Math.sqrt(dx * dx + dz * dz) * 0.8D);
                    for (int y = 0; y < hh; y++) {
                        float r = rnd.nextFloat();
                        h.set(px + dx, floorY + y, pz + dz, r < 0.3F ? b(Blocks.GOLD_BLOCK) : (r < 0.8F ? b(Blocks.RAW_GOLD_BLOCK) : b(Blocks.EMERALD_BLOCK)));
                    }
                }
            }
        }
        // nido del huevo
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d <= 4.2D) {
                    h.set(cx + dx, floorY, cz + dz, d >= 3.0D ? b(Blocks.OBSIDIAN) : b(Blocks.GILDED_BLACKSTONE));
                    h.set(cx + dx, floorY + 1, cz + dz, BuildHelper.AIR);
                }
            }
        }
        h.set(cx, floorY + 1, cz, ModBlocks.egg(rnd.nextInt(3)).defaultBlockState());
        for (int[] c : new int[][]{{-3, 0}, {3, 0}, {0, -3}, {0, 3}}) {
            h.set(cx + c[0], floorY + 1, cz + c[1], b(Blocks.SOUL_LANTERN));
        }
        h.lootChest(cx + 6, floorY + 1, cz + 6, this.loot(), random);
        h.lootChest(cx - 7, floorY + 1, cz - 5, this.loot(), random);
        // lava y brillos
        for (int i = 0; i < 4; i++) {
            int lx = cx + rnd.nextInt(29) - 14;
            int lz = cz + rnd.nextInt(29) - 14;
            if (Math.abs(lx - cx) > 6 || Math.abs(lz - cz) > 6) {
                h.fill(lx, floorY, lz, lx + 2, floorY, lz + 2, b(Blocks.LAVA));
            }
        }
        for (int i = 0; i < 40; i++) {
            int x = cx + rnd.nextInt(37) - 18;
            int z = cz + rnd.nextInt(37) - 18;
            h.set(x, cy + 10, z, rnd.nextBoolean() ? b(Blocks.SHROOMLIGHT) : b(Blocks.AMETHYST_CLUSTER).setValue(net.minecraft.world.level.block.AmethystClusterBlock.FACING, Direction.DOWN));
        }
        DragonPortalBuilder.build(level, h, cx + 12, floorY + 1, cz + 8, Direction.WEST);
    }

    // ---------------------------------------------------------------- santuario

    private void sanctuary(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;
        for (int dx = -17; dx <= 17; dx++) {
            for (int dz = -17; dz <= 17; dz++) {
                h.foundation(cx + dx, cz + dz, y0, 14, b(Blocks.STONE_BRICKS));
            }
        }
        for (int dx = -16; dx <= 16; dx++) {
            for (int dz = -16; dz <= 16; dz++) {
                h.set(cx + dx, y0 - 1, cz + dz, b(Blocks.SMOOTH_QUARTZ));
                h.set(cx + dx, y0, cz + dz, b(Blocks.SMOOTH_QUARTZ));
                if (Math.abs(dx) <= 13 && Math.abs(dz) <= 13) {
                    h.set(cx + dx, y0 + 1, cz + dz, b(Blocks.QUARTZ_BRICKS));
                }
                if (Math.abs(dx) <= 10 && Math.abs(dz) <= 10) {
                    h.set(cx + dx, y0 + 2, cz + dz, (dx + dz) % 2 == 0 ? b(Blocks.QUARTZ_BLOCK) : b(Blocks.QUARTZ_BRICKS));
                }
            }
        }
        // pilares en anillo
        for (int i = 0; i < 12; i++) {
            double angle = i * Math.PI / 6.0D;
            int px = cx + (int) Math.round(Math.cos(angle) * 9.0D);
            int pz = cz + (int) Math.round(Math.sin(angle) * 9.0D);
            h.set(px, y0 + 3, pz, b(Blocks.CHISELED_QUARTZ_BLOCK));
            for (int y = 4; y <= 12; y++) {
                h.set(px, y0 + y, pz, b(Blocks.QUARTZ_PILLAR));
            }
            h.set(px, y0 + 13, pz, b(Blocks.GOLD_BLOCK));
            h.set(px, y0 + 14, pz, b(Blocks.END_ROD));
        }
        // techo con ojo central
        for (int dx = -10; dx <= 10; dx++) {
            for (int dz = -10; dz <= 10; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d <= 10.4D && d >= 3.5D) {
                    h.set(cx + dx, y0 + 13, cz + dz, d > 8.5D ? b(Blocks.SMOOTH_QUARTZ) : b(Blocks.AMETHYST_BLOCK));
                }
                if (d <= 7.5D && d >= 4.5D) {
                    h.set(cx + dx, y0 + 14, cz + dz, b(Blocks.SMOOTH_QUARTZ));
                }
            }
        }
        // altar
        h.fill(cx - 2, y0 + 3, cz - 2, cx + 2, y0 + 3, cz + 2, b(Blocks.GOLD_BLOCK));
        h.fill(cx - 1, y0 + 4, cz - 1, cx + 1, y0 + 4, cz + 1, b(Blocks.CHISELED_QUARTZ_BLOCK));
        h.set(cx, y0 + 5, cz, b(Blocks.SEA_LANTERN));
        h.lootChest(cx, y0 + 3, cz - 6, this.loot(), random);
        h.lootChest(cx, y0 + 3, cz + 6, this.loot(), random);
        for (int[] c : new int[][]{{-6, -6}, {6, -6}, {-6, 6}, {6, 6}}) {
            h.set(cx + c[0], y0 + 3, cz + c[1], b(Blocks.LANTERN));
        }
        for (int[] w : new int[][]{{-4, 0}, {4, 0}, {0, 4}, {0, -4}, {-8, 8}, {8, -8}}) {
            this.worshipper(level, box, cx + w[0], y0 + 3, cz + w[1], rnd);
        }
        DragonPortalBuilder.build(level, h, cx, y0 + 2, cz - 13, Direction.SOUTH);
    }

    // ---------------------------------------------------------------- aldea de adoradores

    private void village(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;
        for (int dx = -26; dx <= 26; dx++) {
            for (int dz = -26; dz <= 26; dz++) {
                h.foundation(cx + dx, cz + dz, y0, 10, b(Blocks.DIRT));
                if (Math.abs(dx) <= 26 && Math.abs(dz) <= 26) {
                    h.set(cx + dx, y0 - 1, cz + dz, b(Blocks.GRASS_BLOCK));
                }
            }
        }
        // plaza
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                h.set(cx + dx, y0 - 1, cz + dz, (Math.abs(dx) + Math.abs(dz)) % 3 == 0 ? b(Blocks.POLISHED_ANDESITE) : b(Blocks.STONE_BRICKS));
            }
        }
        // totem del dragon
        h.fill(cx - 1, y0, cz - 1, cx + 1, y0, cz + 1, b(Blocks.MOSSY_STONE_BRICKS));
        for (int y = 1; y <= 8; y++) {
            h.set(cx, y0 + y, cz, y % 3 == 0 ? b(Blocks.CHISELED_STONE_BRICKS) : b(Blocks.MOSSY_STONE_BRICKS));
        }
        h.set(cx, y0 + 9, cz, b(Blocks.AMETHYST_BLOCK));
        h.set(cx, y0 + 10, cz, b(Blocks.END_ROD));
        for (int[] f : new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}}) {
            h.set(cx + f[0] * 2, y0, cz + f[1] * 2, b(Blocks.LANTERN));
        }
        // cabanas
        int[][] huts = {{-16, -4}, {16, -4}, {-10, -17}, {10, -17}, {-10, 17}, {10, 17}};
        for (int i = 0; i < huts.length; i++) {
            this.hut(h, level, box, cx + huts[i][0], cz + huts[i][1], y0, huts[i][0], huts[i][1], rnd, random, i == 0);
        }
        for (int[] w : new int[][]{{3, 3}, {-3, 4}, {2, -4}, {-4, -3}}) {
            this.worshipper(level, box, cx + w[0], y0, cz + w[1], rnd);
        }
        DragonPortalBuilder.build(level, h, cx, y0, cz - 10, Direction.SOUTH);
    }

    private void hut(BuildHelper h, WorldGenLevel level, BoundingBox box, int hx, int hz, int y0, int relX, int relZ,
                     Random rnd, RandomSource random, boolean chest) {
        // direccion de la puerta: hacia el centro de la aldea
        int doorDx = 0;
        int doorDz = 0;
        if (Math.abs(relX) >= Math.abs(relZ)) {
            doorDx = relX > 0 ? -1 : 1;
        } else {
            doorDz = relZ > 0 ? -1 : 1;
        }
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                h.set(hx + dx, y0 - 1, hz + dz, b(Blocks.COBBLESTONE));
                h.set(hx + dx, y0, hz + dz, b(Blocks.SPRUCE_PLANKS));
                for (int y = 1; y <= 4; y++) {
                    boolean edge = Math.abs(dx) == 3 || Math.abs(dz) == 3;
                    boolean corner = Math.abs(dx) == 3 && Math.abs(dz) == 3;
                    h.set(hx + dx, y0 + y, hz + dz, corner ? b(Blocks.STRIPPED_SPRUCE_LOG) : (edge ? b(Blocks.SPRUCE_PLANKS) : BuildHelper.AIR));
                }
            }
        }
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                h.set(hx + dx, y0 + 5, hz + dz, b(Blocks.DARK_OAK_PLANKS));
                if (Math.abs(dx) <= 3 && Math.abs(dz) <= 3) {
                    h.set(hx + dx, y0 + 6, hz + dz, b(Blocks.DARK_OAK_PLANKS));
                }
                if (Math.abs(dx) <= 1 && Math.abs(dz) <= 1) {
                    h.set(hx + dx, y0 + 7, hz + dz, b(Blocks.DARK_OAK_PLANKS));
                }
            }
        }
        // puerta (hueco de 1x2) y ventanas
        h.fill(hx + doorDx * 3, y0 + 1, hz + doorDz * 3, hx + doorDx * 3, y0 + 2, hz + doorDz * 3, BuildHelper.AIR);
        h.set(hx - doorDx * 3, y0 + 2, hz - doorDz * 3, b(Blocks.GLASS_PANE));
        h.set(hx + doorDz * 3, y0 + 2, hz + doorDx * 3, b(Blocks.GLASS_PANE));
        h.set(hx - doorDz * 3, y0 + 2, hz - doorDx * 3, b(Blocks.GLASS_PANE));
        // interior
        h.set(hx, y0 + 4, hz, b(Blocks.LANTERN));
        h.fill(hx - 1, y0 + 1, hz - 1, hx + 1, y0 + 1, hz + 1, b(Blocks.RED_CARPET));
        h.set(hx - doorDx * 2, y0 + 1, hz - doorDz * 2, b(Blocks.CRAFTING_TABLE));
        if (chest) {
            h.lootChest(hx + doorDz * 2, y0 + 1, hz + doorDx * 2, this.loot(), random);
        }
        // camino hasta la plaza
        int px = hx + doorDx * 4;
        int pz = hz + doorDz * 4;
        for (int i = 0; i < 24; i++) {
            if (Math.abs(px - this.cx) <= 6 && Math.abs(pz - this.cz) <= 6) {
                break;
            }
            h.set(px, y0 - 1, pz, b(Blocks.GRAVEL));
            if (Math.abs(px - this.cx) > 6) {
                px += px > this.cx ? -1 : 1;
            } else {
                pz += pz > this.cz ? -1 : 1;
            }
        }
        this.worshipper(level, box, hx, y0 + 1, hz, rnd);
    }

    // ---------------------------------------------------------------- puerta del dragon

    private void gate(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;
        for (int dx = -22; dx <= 22; dx++) {
            for (int dz = -21; dz <= 22; dz++) {
                h.foundation(cx + dx, cz + dz, y0, 14, b(Blocks.STONE_BRICKS));
            }
        }
        // explanada tras la puerta
        for (int dx = -16; dx <= 16; dx++) {
            for (int dz = -20; dz <= -6; dz++) {
                h.set(cx + dx, y0 - 1, cz + dz, (dx + dz) % 4 == 0
                        ? b(ModBlocks.CHISELED_DRAGONSTONE.get()) : b(Blocks.POLISHED_DEEPSLATE));
            }
        }
        // avenida de acceso
        for (int dz = 5; dz <= 22; dz++) {
            for (int dx = -4; dx <= 4; dx++) {
                BlockState floor = Math.abs(dx) == 4 ? b(Blocks.DEEPSLATE_TILES)
                        : (dx == 0 ? b(ModBlocks.DRAGONSTONE_BRICKS.get()) : b(Blocks.POLISHED_DEEPSLATE));
                h.set(cx + dx, y0 - 1, cz + dz, floor);
            }
            for (int side = -1; side <= 1; side += 2) {
                h.set(cx + side * 6, y0, cz + dz, b(Blocks.DEEPSLATE_BRICKS));
                h.set(cx + side * 6, y0 + 1, cz + dz, b(Blocks.DEEPSLATE_BRICKS));
                if (dz % 5 == 2) {
                    h.set(cx + side * 6, y0 + 2, cz + dz, b(ModBlocks.DRAGON_LAMP.get()));
                }
            }
        }
        // pilonos de la avenida
        for (int side = -1; side <= 1; side += 2) {
            int px = cx + side * 10;
            int pz = cz + 9;
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    for (int dy = 0; dy <= 4; dy++) {
                        h.set(px + dx, y0 + dy, pz + dz, b(Blocks.CHISELED_DEEPSLATE));
                    }
                }
            }
            h.set(px, y0 + 5, pz, b(ModBlocks.CHISELED_DRAGONSTONE.get()));
            h.set(px, y0 + 6, pz, b(ModBlocks.DRAGON_LAMP.get()));
        }
        // muralla con puerta central
        for (int dx = -16; dx <= 16; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                boolean edge = Math.abs(dz) == 5 || Math.abs(dx) == 16;
                if (!edge) {
                    continue;
                }
                for (int dy = 0; dy <= 12; dy++) {
                    boolean door = Math.abs(dz) == 5 && Math.abs(dx) >= 8 && Math.abs(dx) <= 10 && dy <= 4;
                    boolean window = Math.abs(dz) == 5 && (Math.abs(dx) == 4 || Math.abs(dx) == 12) && (dy == 7 || dy == 9);
                    BlockState state = window ? b(Blocks.GLASS) : this.brick(rnd);
                    h.set(cx + dx, y0 + dy, cz + dz, door ? BuildHelper.AIR : state);
                    if (door && dy == 5) {
                        h.set(cx + dx, y0 + dy, cz + dz, b(Blocks.CHISELED_DEEPSLATE));
                    }
                }
            }
        }
        for (int dx = -16; dx <= 16; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                h.set(cx + dx, y0 + 12, cz + dz, this.brick(rnd));
                if ((dx + dz) % 2 == 0 && (Math.abs(dx) == 16 || Math.abs(dz) == 5)) {
                    h.set(cx + dx, y0 + 13, cz + dz, b(Blocks.DEEPSLATE_TILES));
                }
            }
        }
        // contrafuertes
        for (int side = -1; side <= 1; side += 2) {
            for (int bx = -14; bx <= 14; bx += 4) {
                for (int dy = 0; dy <= 6; dy++) {
                    h.set(cx + bx, y0 + dy, cz + side * 6, this.brick(rnd));
                    h.set(cx + bx, y0 + dy, cz + side * 7, this.brick(rnd));
                }
                h.set(cx + bx, y0 + 7, cz + side * 6, b(ModBlocks.CHISELED_DRAGONSTONE.get()));
                if (bx % 8 == 2) {
                    h.set(cx + bx, y0 + 8, cz + side * 7, b(ModBlocks.DRAGON_LAMP.get()));
                }
            }
        }
        // torres gemelas
        this.gateTower(h, cx - 17, cz, y0, rnd, random);
        this.gateTower(h, cx + 17, cz, y0, rnd, random);
        // patio de honor
        h.fill(cx - 1, y0 - 1, cz - 18, cx + 1, y0 - 1, cz - 6, b(Blocks.RED_CARPET));
        for (int[] p : new int[][]{{-11, -9}, {-11, -17}, {11, -9}, {11, -17}}) {
            for (int dy = 0; dy <= 5; dy++) {
                h.set(cx + p[0], y0 + dy, cz + p[1], dy % 2 == 0
                        ? b(ModBlocks.CHISELED_DRAGONSTONE.get()) : b(Blocks.DEEPSLATE_BRICKS));
            }
            h.set(cx + p[0], y0 + 6, cz + p[1], b(ModBlocks.DRAGON_LAMP.get()));
        }
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d <= 3.2D) {
                    h.set(cx + dx, y0 - 1, cz - 13 + dz, d >= 2.4D ? b(Blocks.GOLD_BLOCK) : b(Blocks.GILDED_BLACKSTONE));
                }
            }
        }
        h.fill(cx - 1, y0, cz - 14, cx + 1, y0, cz - 12, b(Blocks.CHISELED_QUARTZ_BLOCK));
        h.set(cx, y0 + 1, cz - 13, ModBlocks.egg(rnd.nextInt(8)).defaultBlockState());
        for (int[] c : new int[][]{{-2, -15}, {2, -15}, {-2, -11}, {2, -11}}) {
            h.set(cx + c[0], y0, cz + c[1], b(ModBlocks.DRAGON_LAMP.get()));
        }
        h.lootChest(cx - 8, y0, cz - 11, this.loot(), random);
        h.lootChest(cx + 8, y0, cz - 18, this.loot(), random);
        this.worshipper(level, box, cx, y0, cz - 8, rnd);
        this.worshipper(level, box, cx - 6, y0, cz - 16, rnd);
        this.worshipper(level, box, cx + 7, y0, cz - 9, rnd);
        DragonPortalBuilder.build(level, h, cx, y0, cz, Direction.SOUTH);
    }

    private void gateTower(BuildHelper h, int tx, int tz, int y0, Random rnd, RandomSource random) {
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                int d2 = dx * dx + dz * dz;
                if (d2 > 26) {
                    continue;
                }
                for (int dy = 0; dy <= 23; dy++) {
                    if (d2 < 13) {
                        continue;
                    }
                    boolean window = (dy == 5 || dy == 12 || dy == 19)
                            && ((dx == 0 && Math.abs(dz) >= 4) || (dz == 0 && Math.abs(dx) >= 4));
                    BlockState state = window ? b(Blocks.GLASS)
                            : ((dy == 7 || dy == 15) ? b(ModBlocks.CHISELED_DRAGONSTONE.get())
                            : (dy % 5 == 0 ? b(ModBlocks.DRAGONSTONE_BRICKS.get()) : this.brick(rnd)));
                    h.set(tx + dx, y0 + dy, tz + dz, state);
                }
                h.set(tx + dx, y0 + 23, tz + dz, b(Blocks.DEEPSLATE_TILES));
                if (d2 >= 13 && (dx + dz) % 2 == 0) {
                    h.set(tx + dx, y0 + 24, tz + dz, b(Blocks.DEEPSLATE_TILES));
                }
            }
        }
        for (int fl : new int[]{8, 16}) {
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    if (dx * dx + dz * dz <= 10 && !(dx >= 1 && dx <= 3 && Math.abs(dz) <= 1)) {
                        h.set(tx + dx, y0 + fl, tz + dz, b(Blocks.DARK_OAK_PLANKS));
                    }
                }
            }
        }
        for (int y = 0; y <= 22; y++) {
            h.set(tx + 3, y0 + y, tz, b(Blocks.LADDER).setValue(LadderBlock.FACING, Direction.WEST));
        }
        h.lootChest(tx - 2, y0 + 17, tz + 2, this.loot(), random);
        h.set(tx, y0 + 24, tz, b(ModBlocks.DRAGON_LAMP.get()));
        h.set(tx, y0 + 20, tz - 3, b(Blocks.LANTERN));
    }

    // ---------------------------------------------------------------- observatorio

    private void observatory(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;
        for (int dx = -17; dx <= 17; dx++) {
            for (int dz = -17; dz <= 17; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > 16.5D) {
                    continue;
                }
                h.foundation(cx + dx, cz + dz, y0, 14, b(Blocks.STONE_BRICKS));
                h.set(cx + dx, y0 - 1, cz + dz, d > 14.5D ? b(Blocks.DEEPSLATE_TILES)
                        : ((dx + dz) % 2 == 0 ? b(Blocks.POLISHED_DEEPSLATE) : b(Blocks.DEEPSLATE_BRICKS)));
            }
        }
        for (int dx = -14; dx <= 14; dx++) {
            for (int dz = -14; dz <= 14; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d < 11.9D || d > 13.7D) {
                    continue;
                }
                double angle = Math.atan2(dz, dx);
                for (int dy = 0; dy <= 21; dy++) {
                    boolean window = (dy == 5 || dy == 9 || dy == 13 || dy == 17)
                            && Math.abs(Math.sin(angle * 4.0D)) > 0.94D;
                    boolean band = dy == 0 || dy == 7 || dy == 14 || dy == 21;
                    BlockState state = window ? b(Blocks.GLASS)
                            : (band ? b(ModBlocks.CHISELED_DRAGONSTONE.get())
                            : (dy % 3 == 0 ? b(Blocks.POLISHED_DEEPSLATE) : b(Blocks.DEEPSLATE_BRICKS)));
                    h.set(cx + dx, y0 + dy, cz + dz, state);
                }
            }
        }
        // entrada sur
        h.fill(cx - 2, y0, cz + 11, cx + 2, y0 + 4, cz + 14, BuildHelper.AIR);
        for (int dy = 0; dy <= 5; dy++) {
            h.set(cx - 3, y0 + dy, cz + 13, b(ModBlocks.CHISELED_DRAGONSTONE.get()));
            h.set(cx + 3, y0 + dy, cz + 13, b(ModBlocks.CHISELED_DRAGONSTONE.get()));
        }
        h.fill(cx - 3, y0 + 5, cz + 13, cx + 3, y0 + 5, cz + 13, b(Blocks.POLISHED_DEEPSLATE));
        h.set(cx - 3, y0 + 6, cz + 13, b(ModBlocks.DRAGON_LAMP.get()));
        h.set(cx + 3, y0 + 6, cz + 13, b(ModBlocks.DRAGON_LAMP.get()));
        for (int dz = 14; dz <= 18; dz++) {
            for (int dx = -2; dx <= 2; dx++) {
                h.set(cx + dx, y0 - 1, cz + dz, b(Blocks.POLISHED_DEEPSLATE));
            }
        }
        // pisos intermedios
        for (int fl : new int[]{10, 19}) {
            for (int dx = -12; dx <= 12; dx++) {
                for (int dz = -12; dz <= 12; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d <= 11.7D && !(dx >= 9 && dx <= 11 && Math.abs(dz) <= 1)) {
                        h.set(cx + dx, y0 + fl, cz + dz, b(Blocks.DEEPSLATE_TILES));
                    }
                }
            }
        }
        for (int y = 0; y <= 20; y++) {
            h.set(cx + 11, y0 + y, cz, b(Blocks.LADDER).setValue(LadderBlock.FACING, Direction.WEST));
        }
        // biblioteca y altar
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI / 6.0D;
            int px = cx + (int) Math.round(Math.cos(a) * 10.0D);
            int pz = cz + (int) Math.round(Math.sin(a) * 10.0D);
            if (pz > cz + 1) {
                continue;
            }
            h.set(px, y0, pz, b(Blocks.BOOKSHELF));
            h.set(px, y0 + 1, pz, b(Blocks.BOOKSHELF));
        }
        h.set(cx, y0, cz - 7, b(Blocks.CHISELED_QUARTZ_BLOCK));
        h.set(cx, y0 + 1, cz - 7, ModBlocks.egg(4).defaultBlockState());
        h.set(cx - 2, y0, cz - 7, b(ModBlocks.DRAGON_LAMP.get()));
        h.set(cx + 2, y0, cz - 7, b(ModBlocks.DRAGON_LAMP.get()));
        h.lootChest(cx - 6, y0, cz - 6, this.loot(), random);
        h.lootChest(cx + 6, y0, cz - 6, this.loot(), random);
        h.lootChest(cx - 5, y0 + 11, cz + 2, this.loot(), random);
        // telescopio de cobre
        for (int i = 0; i <= 7; i++) {
            int ty = y0 + 21 + i;
            int tz = cz - 3 + i;
            BlockState tube = (i == 4) ? b(Blocks.GLASS)
                    : (i % 3 == 0 ? b(Blocks.CUT_COPPER) : b(Blocks.COPPER_BLOCK));
            h.set(cx - 3, ty, tz, tube);
            h.set(cx - 2, ty, tz, tube);
            h.set(cx - 3, ty, tz + 1, tube);
            h.set(cx - 2, ty, tz + 1, tube);
        }
        h.set(cx - 3, y0 + 20, cz - 3, b(Blocks.COPPER_BLOCK));
        h.set(cx - 2, y0 + 20, cz - 3, b(Blocks.COPPER_BLOCK));
        h.set(cx - 3, y0 + 20, cz - 2, b(Blocks.COPPER_BLOCK));
        h.set(cx - 2, y0 + 20, cz - 2, b(Blocks.COPPER_BLOCK));
        // cupula de cristal
        for (int dy = 0; dy <= 8; dy++) {
            double radius = 13.0D * Math.cos(dy * Math.PI / 18.0D);
            for (int dx = -13; dx <= 13; dx++) {
                for (int dz = -13; dz <= 13; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d <= radius + 0.6D && d >= radius - 1.3D) {
                        boolean rib = Math.abs(dx) <= 1 || Math.abs(dz) <= 1
                                || Math.abs(Math.abs(dx) - Math.abs(dz)) <= 1;
                        h.set(cx + dx, y0 + 22 + dy, cz + dz,
                                rib ? b(Blocks.DEEPSLATE_TILES) : b(Blocks.GLASS));
                    }
                }
            }
        }
        h.set(cx, y0 + 30, cz, b(ModBlocks.DRAGON_LAMP.get()));
        for (int[] c : new int[][]{{-8, 8}, {8, 8}, {-8, -8}, {8, -8}}) {
            h.set(cx + c[0], y0 + 22, cz + c[1], b(Blocks.AMETHYST_BLOCK));
        }
        this.worshipper(level, box, cx - 5, y0, cz + 2, rnd);
        this.worshipper(level, box, cx + 6, y0, cz - 2, rnd);
        this.worshipper(level, box, cx - 4, y0 + 10, cz - 5, rnd);
        this.worshipper(level, box, cx + 4, y0 + 20, cz + 4, rnd);
        DragonPortalBuilder.build(level, h, cx, y0, cz + 5, Direction.SOUTH);
    }

    // ---------------------------------------------------------------- criadero ancestral

    private void hatchery(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;
        for (int dx = -22; dx <= 22; dx++) {
            for (int dz = -22; dz <= 22; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > 21.5D) {
                    continue;
                }
                h.foundation(cx + dx, cz + dz, y0, 12, b(Blocks.DIRT));
                BlockState floor;
                if (d > 19.2D) {
                    floor = b(Blocks.MOSSY_STONE_BRICKS);
                } else if (Math.abs(dx) <= 1 || Math.abs(dz) <= 1 || Math.abs(Math.abs(dx) - Math.abs(dz)) <= 1) {
                    floor = b(Blocks.GRAVEL);
                } else {
                    floor = ((dx + dz) % 5 == 0) ? b(Blocks.MOSS_BLOCK)
                            : (rnd.nextFloat() < 0.25F ? b(Blocks.GRASS_BLOCK) : b(Blocks.MOSS_BLOCK));
                }
                h.set(cx + dx, y0 - 1, cz + dz, floor);
            }
        }
        // muro perimetral con entrada sur
        for (int dx = -22; dx <= 22; dx++) {
            for (int dz = -22; dz <= 22; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d < 19.2D || d > 21.3D) {
                    continue;
                }
                boolean entrance = dz > 16 && Math.abs(dx) <= 3;
                if (entrance) {
                    continue;
                }
                for (int dy = 0; dy <= 3; dy++) {
                    BlockState state = dy == 0 ? b(ModBlocks.DRAGONSTONE_BRICKS.get())
                            : (dy == 3 ? b(Blocks.MOSSY_STONE_BRICKS) : this.brick(rnd));
                    h.set(cx + dx, y0 + dy, cz + dz, state);
                }
                if ((dx + dz) % 2 == 0) {
                    h.set(cx + dx, y0 + 4, cz + dz, b(Blocks.MOSSY_STONE_BRICKS));
                }
                if ((dx * 3 + dz * 5) % 29 == 0) {
                    h.set(cx + dx, y0 + 2, cz + dz, b(ModBlocks.DRAGON_LAMP.get()));
                }
            }
        }
        // pilares y cupula de cristal
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0D;
            int px = cx + (int) Math.round(Math.cos(a) * 17.0D);
            int pz = cz + (int) Math.round(Math.sin(a) * 17.0D);
            for (int dy = 0; dy <= 9; dy++) {
                BlockState state = (dy == 3 || dy == 6) ? b(ModBlocks.CHISELED_DRAGONSTONE.get())
                        : (dy % 3 == 0 ? b(ModBlocks.DRAGONSTONE_BRICKS.get()) : b(Blocks.MOSSY_STONE_BRICKS));
                h.set(px, y0 + dy, pz, state);
            }
            h.set(px, y0 + 10, pz, b(ModBlocks.DRAGON_LAMP.get()));
        }
        for (int ring = 0; ring < 5; ring++) {
            int ry = y0 + 10 + ring;
            double radius = 16.5D - ring * 3.3D;
            for (int dx = -17; dx <= 17; dx++) {
                for (int dz = -17; dz <= 17; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d <= radius + 0.8D && d >= radius - 1.2D) {
                        boolean rib = Math.abs(dx) <= 1 || Math.abs(dz) <= 1
                                || Math.abs(Math.abs(dx) - Math.abs(dz)) <= 1;
                        h.set(cx + dx, ry, cz + dz,
                                rib ? b(Blocks.DEEPSLATE_TILES) : b(Blocks.GLASS));
                    }
                }
            }
        }
        h.set(cx, y0 + 15, cz, b(Blocks.GLASS));
        h.set(cx, y0 + 16, cz, b(ModBlocks.DRAGON_LAMP.get()));
        // nidos
        this.nest(h, level, box, cx + 9, y0, cz + 6, rnd, random);
        this.nest(h, level, box, cx - 9, y0, cz + 6, rnd, random);
        this.nest(h, level, box, cx + 11, y0, cz - 3, rnd, random);
        this.nest(h, level, box, cx - 11, y0, cz - 3, rnd, random);
        this.nest(h, level, box, cx, y0, cz + 12, rnd, random);
        // altar central
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                h.set(cx + dx, y0 - 1, cz + dz, Math.abs(dx) == 2 || Math.abs(dz) == 2
                        ? b(Blocks.GILDED_BLACKSTONE) : b(Blocks.GOLD_BLOCK));
            }
        }
        h.set(cx, y0, cz, ModBlocks.egg(rnd.nextInt(8)).defaultBlockState());
        for (int[] c : new int[][]{{-3, 0}, {3, 0}, {0, -3}, {0, 3}}) {
            h.set(cx + c[0], y0, cz + c[1], b(ModBlocks.DRAGON_LAMP.get()));
        }
        // estanques
        for (int[] pool : new int[][]{{15, -13}, {-15, 13}}) {
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d <= 2.6D) {
                        h.set(cx + pool[0] + dx, y0 - 1, cz + pool[1] + dz, b(Blocks.WATER));
                        h.set(cx + pool[0] + dx, y0, cz + pool[1] + dz, BuildHelper.AIR);
                    } else if (d <= 3.8D) {
                        h.set(cx + pool[0] + dx, y0 - 1, cz + pool[1] + dz, b(Blocks.MOSSY_STONE_BRICKS));
                    }
                }
            }
        }
        // vegetacion
        for (int i = 0; i < 90; i++) {
            int dx = rnd.nextInt(37) - 18;
            int dz = rnd.nextInt(37) - 18;
            if (dx * dx + dz * dz > 17 * 17 || (Math.abs(dx) <= 4 && dz < -6 && dz > -16)) {
                continue;
            }
            BlockPos pos = new BlockPos(cx + dx, y0, cz + dz);
            if (!box.isInside(pos) || !h.get(pos.getX(), y0, pos.getZ()).isAir()
                    || h.get(pos.getX(), y0 - 1, pos.getZ()).isAir()) {
                continue;
            }
            float pick = rnd.nextFloat();
            Block plant = pick < 0.45F ? Blocks.GRASS
                    : (pick < 0.65F ? Blocks.FERN
                    : (pick < 0.82F ? Blocks.AZURE_BLUET
                    : (pick < 0.94F ? Blocks.OXEYE_DAISY : Blocks.AZALEA_LEAVES)));
            h.set(pos.getX(), y0, pos.getZ(), b(plant));
        }
        h.lootChest(cx + 4, y0, cz - 6, this.loot(), random);
        h.lootChest(cx - 4, y0, cz + 12, this.loot(), random);
        this.worshipper(level, box, cx - 4, y0, cz + 8, rnd);
        this.worshipper(level, box, cx + 4, y0, cz - 8, rnd);
        this.worshipper(level, box, cx, y0, cz + 3, rnd);
        DragonPortalBuilder.build(level, h, cx, y0, cz - 11, Direction.SOUTH);
    }

    private void nest(BuildHelper h, WorldGenLevel level, BoundingBox box, int px, int pz, int y0,
                      Random rnd, RandomSource random) {
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > 3.3D) {
                    continue;
                }
                h.set(px + dx, y0 - 1, pz + dz, d >= 2.3D ? b(Blocks.OBSIDIAN)
                        : (rnd.nextFloat() < 0.45F ? b(Blocks.GILDED_BLACKSTONE) : b(Blocks.BLACKSTONE)));
                h.set(px + dx, y0, pz + dz, BuildHelper.AIR);
                h.set(px + dx, y0 + 1, pz + dz, BuildHelper.AIR);
                if (d >= 2.7D) {
                    h.set(px + dx, y0, pz + dz, b(Blocks.CRYING_OBSIDIAN));
                }
            }
        }
        h.set(px, y0, pz, ModBlocks.egg(rnd.nextInt(8)).defaultBlockState());
        for (int[] c : new int[][]{{-2, -2}, {2, -2}, {-2, 2}, {2, 2}}) {
            h.set(px + c[0], y0, pz + c[1], b(ModBlocks.DRAGON_LAMP.get()));
        }
        h.lootChest(px + 3, y0, pz, this.loot(), random);
        this.worshipper(level, box, px - 3, y0, pz + 2, rnd);
    }
}
