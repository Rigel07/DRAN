package com.isladragoncitos.worldgen.massive;

import com.isladragoncitos.registry.ModStructures;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/** Estructuras masivas: castillo, cueva, santuario, aldea, puerta, observatorio y criadero (segun "kind"). */
public class MassiveStructure extends Structure {
    public static final Codec<MassiveStructure> CODEC = RecordCodecBuilder.create(instance -> instance
            .group(settingsCodec(instance), Codec.INT.fieldOf("kind").forGetter(structure -> structure.kind))
            .apply(instance, MassiveStructure::new));

    private final int kind;

    public MassiveStructure(Structure.StructureSettings settings, int kind) {
        super(settings);
        this.kind = kind;
    }

    @Override
    public StructureType<?> type() {
        return ModStructures.MASSIVE_TYPE.get();
    }

    private int height(Structure.GenerationContext context, int x, int z) {
        return context.chunkGenerator().getFirstOccupiedHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, context.heightAccessor(), context.randomState());
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        ChunkPos chunk = context.chunkPos();
        int x = chunk.getMiddleBlockX();
        int z = chunk.getMiddleBlockZ();
        int h = this.height(context, x, z);
        NoiseColumn column = context.chunkGenerator().getBaseColumn(x, z, context.heightAccessor(), context.randomState());
        boolean cave = this.kind == MassivePiece.CAVE;
        if (h < (cave ? 70 : 62) || h > 150 || !column.getBlock(h - 1).getFluidState().isEmpty()) {
            return Optional.empty();
        }
        if (!cave) {
            int spread = MassivePiece.halfSize(this.kind) - 4;
            int limit = switch (this.kind) {
                case MassivePiece.CASTLE, MassivePiece.GATE, MassivePiece.OBSERVATORY -> 8;
                case MassivePiece.HATCHERY -> 7;
                default -> 6;
            };
            int min = h;
            int max = h;
            int[][] offsets = {{spread, 0}, {-spread, 0}, {0, spread}, {0, -spread}};
            for (int[] offset : offsets) {
                int other = this.height(context, x + offset[0], z + offset[1]);
                min = Math.min(min, other);
                max = Math.max(max, other);
                if (!context.chunkGenerator().getBaseColumn(x + offset[0], z + offset[1], context.heightAccessor(), context.randomState())
                        .getBlock(other - 1).getFluidState().isEmpty()) {
                    return Optional.empty();
                }
            }
            if (max - min > limit) {
                return Optional.empty();
            }
        }
        long seed = context.random().nextLong();
        int baseY = h;
        return Optional.of(new Structure.GenerationStub(new BlockPos(x, baseY, z),
                builder -> builder.addPiece(new MassivePiece(this.kind, x, baseY, z, seed))));
    }
}
